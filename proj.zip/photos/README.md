# photos / الصور (اختياري · optional)

الرسوم التوضيحية داخل العرض صنعها الذكاء الاصطناعي. لو أردت صوراً حقيقية ضع JPG هنا بهذه الأسماء، أو اسحبها فوق الرسم داخل `slides.html`، واكتب المصدر والترخيص تحت الصورة (Unsplash / Pexels / Wikimedia Commons). لا تستخدم صور أشخاص دون إذنهم.

The illustrations in the deck are AI-made. For real photos, put JPGs here with these names, or drag them onto the illustration in `slides.html`, and credit the source/licence.

| file | search |
|---|---|
| `photos/p02.jpg` | deaf people using sign language conversation |
| `photos/p03.jpg` | hospital reception communication accessibility |
| `photos/p05.jpg` | live captions on phone meeting accessibility |
| `photos/p08.jpg` | doorbell flashing light alert deaf home |
| `photos/p09.jpg` | doctor patient clear communication clinic |
| `photos/p10.jpg` | classroom sign language lesson students |
| `photos/p11.jpg` | deaf employee workplace meeting captions |
| `photos/p14.jpg` | deaf and hearing team designing together accessibility |
