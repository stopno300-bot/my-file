#!/usr/bin/env python3
"""Bundle modules into dist/index.html (full) and dist/artifact.html (lite)."""
import re, pathlib
R = pathlib.Path(__file__).parent
MODS = [m for m in ['core.js', 'dict.js', 'signs.js', 'avatar.js', 'gestures.js', 'studio.js', 'i18n.js', 'app.js'] if (R / m).exists()]
FONTS = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=IBM+Plex+Sans+Arabic:wght@400;500;600&family=Readex+Pro:wght@500;600&display=swap'

def strip(src):
    src = re.sub(r'^import\s[\s\S]*?from\s+[\'"].*?[\'"];?[ \t]*$', '', src, flags=re.M)
    src = re.sub(r'^export\s*\{[\s\S]*?\};?[ \t]*$', '', src, flags=re.M)
    src = re.sub(r'^export\s+(default\s+)?', '', src, flags=re.M)
    return src.strip('\n')

js = '\n\n'.join(f'// ===== {m} =====\n' + strip((R / m).read_text(encoding='utf-8')) for m in MODS)
css = (R / 'style.css').read_text(encoding='utf-8')
body = (R / 'body.html').read_text(encoding='utf-8').strip('\n')
TF = '<script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js"></script>'
(R / 'dist').mkdir(exist_ok=True)

def page(art):
    flag = f'<script>const IN_ARTIFACT = {"true" if art else "false"};</script>'
    if art:
        return (f'<meta name="claude:viewport-fit-sides" content="cover">\n<link href="{FONTS}" rel="stylesheet">\n'
                f'<style>\n{css}\n</style>\n{body}\n{flag}\n<script>\n{js}\n</script>\n')
    return (f'<!doctype html>\n<html lang="ar" dir="rtl" data-theme="noir">\n<head>\n<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
            f'<title>مترجم الإشارة</title>\n<link href="{FONTS}" rel="stylesheet">\n<style>\n{css}\n</style>\n</head>\n<body>\n'
            f'{body}\n\n{TF}\n{flag}\n<script>\n{js}\n</script>\n</body>\n</html>\n')

(R / 'dist/index.html').write_text(page(False), encoding='utf-8')
(R / 'dist/artifact.html').write_text(page(True), encoding='utf-8')
print('built', {p.name: p.stat().st_size for p in (R / 'dist').iterdir()}, MODS)
