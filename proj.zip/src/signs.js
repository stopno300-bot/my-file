import { fingerStates } from './core.js';

/* مكتبة أشكال اليد: كل حرف يُعرَّف بحالة الأصابع، ومنها تُرسم اليد ويُتعرَّف عليها.
   الأشكال الافتراضية هنا تجريبية، وليست القاموس الرسمي للغة الإشارة العربية. */

export const D2R = Math.PI / 180;

/* [الحرف، الإبهام (out/in)، حالة الأصابع سبابة-وسطى-بنصر-خنصر: E ممدود، H منحنٍ، C مطوي] */
export const TABLE_AR = [
  ['ا', 'in', 'ECCC'], ['ب', 'in', 'EECC'], ['ت', 'in', 'EEEC'], ['ث', 'in', 'EEEE'],
  ['ج', 'out', 'ECCC'], ['ح', 'out', 'EECC'], ['خ', 'out', 'EEEC'], ['د', 'out', 'EEEE'],
  ['ذ', 'in', 'CCCC'], ['ر', 'out', 'CCCC'], ['ز', 'in', 'CCCE'], ['س', 'out', 'CCCE'],
  ['ش', 'in', 'CECC'], ['ص', 'in', 'CCEC'], ['ض', 'in', 'CEEC'], ['ط', 'in', 'CCEE'],
  ['ظ', 'in', 'CEEE'], ['ع', 'out', 'CECC'], ['غ', 'out', 'CCEC'], ['ف', 'out', 'CEEC'],
  ['ق', 'out', 'CCEE'], ['ك', 'out', 'CEEE'], ['ل', 'in', 'ECCE'], ['م', 'in', 'ECEC'],
  ['ن', 'in', 'EECE'], ['ه', 'in', 'ECEE'], ['و', 'in', 'CECE'], ['ي', 'out', 'ECCE'],
];

/* أشكال إنجليزية تجريبية: بعضها قريب من هجاء ASL (A B D I L S U V W Y) والباقي موزَّع للتجربة. */
export const TABLE_EN = [
  ['A', 'out', 'CCCC'], ['B', 'in', 'EEEE'], ['C', 'out', 'EEEE'], ['D', 'in', 'ECCC'],
  ['E', 'in', 'CECC'], ['F', 'in', 'CCEC'], ['G', 'out', 'EEEC'], ['H', 'in', 'CEEC'],
  ['I', 'in', 'CCCE'], ['J', 'in', 'CCEE'], ['K', 'in', 'CEEE'], ['L', 'out', 'ECCC'],
  ['M', 'in', 'ECCE'], ['N', 'in', 'ECEC'], ['O', 'in', 'EECE'], ['P', 'in', 'ECEE'],
  ['Q', 'out', 'CECC'], ['R', 'out', 'CCEC'], ['S', 'in', 'CCCC'], ['T', 'out', 'CEEC'],
  ['U', 'in', 'EECC'], ['V', 'out', 'EECC'], ['W', 'in', 'EEEC'], ['X', 'out', 'CCEE'],
  ['Y', 'out', 'CCCE'], ['Z', 'out', 'CEEE'],
];
export const TABLES = { ar: TABLE_AR, en: TABLE_EN };

export function defaultLibrary(set = 'ar') {
  const lib = {};
  for (const [ch, t, f] of TABLES[set] || TABLE_AR) lib[ch] = { t, f: f.split(''), rot: 0, custom: false };
  return lib;
}

/** يدمج التعديلات المحفوظة فوق الافتراضي. */
export function mergeLibrary(overrides, set = 'ar') {
  const lib = defaultLibrary(set);
  for (const [ch, e] of Object.entries(overrides || {})) {
    if (!lib[ch] || !e) continue;
    const f = Array.isArray(e.f) && e.f.length === 4 ? e.f.map((x) => (['E', 'H', 'C'].includes(x) ? x : 'C')) : lib[ch].f;
    lib[ch] = { t: e.t === 'out' ? 'out' : 'in', f, rot: Number(e.rot) || 0, custom: true };
  }
  return lib;
}

export const FINGER_VALUE = { E: 1, H: 0.5, C: 0 };

export function patternOf(entry) {
  return [entry.t === 'out' ? 1 : 0, ...entry.f.map((x) => FINGER_VALUE[x] ?? 0)];
}

/** يطابق حالة الأصابع الحالية مع المكتبة. conf بين 0 و1. */
export function matchLibrary(states, lib) {
  let best = null;
  let second = Infinity;
  for (const [label, entry] of Object.entries(lib)) {
    const p = patternOf(entry);
    let d = 0;
    for (let i = 0; i < 5; i++) d += Math.abs(states[i] - p[i]);
    if (!best || d < best.d) {
      second = best ? best.d : Infinity;
      best = { label, d };
    } else if (d < second) {
      second = d;
    }
  }
  if (!best) return { label: null, conf: 0 };
  let conf = Math.max(0, 1 - best.d / 2.5);
  if (second - best.d < 0.25) conf *= 0.7; // التباس بين شكلين متقاربين
  return { label: best.label, conf };
}

/* ---------- من الحالة إلى نقاط اليد (21 نقطة) ---------- */

export const MCP = [[-0.30, -0.95], [-0.05, -1.0], [0.20, -0.95], [0.42, -0.82]];
export const LEN = [[0.42, 0.27, 0.22], [0.46, 0.30, 0.23], [0.42, 0.28, 0.22], [0.33, 0.20, 0.18]];
export const SPLAY = [-5, 0, 4, 9];
export const CURL = { E: [0, 0, 0], H: [30, 65, 40], C: [80, 100, 40] };
export const THUMB = { out: { a: [-55, -45, -35], z: 0 }, in: { a: [30, 55, 75], z: 0.3 } };
export const THUMB_LEN = [0.34, 0.28, 0.24];

export function poseToPoints(entry) {
  const pts = new Array(21);
  pts[0] = [0, 0, 0];
  const T = THUMB[entry.t === 'out' ? 'out' : 'in'];
  let p = [-0.32, -0.28, 0];
  pts[1] = p;
  for (let k = 0; k < 3; k++) {
    const a = T.a[k] * D2R;
    p = [p[0] + Math.sin(a) * THUMB_LEN[k], p[1] - Math.cos(a) * THUMB_LEN[k], (T.z * (k + 1)) / 3];
    pts[2 + k] = p;
  }
  const extended = entry.f.filter((x) => x === 'E').length;
  const spread = extended >= 3 ? 6 : 0;
  for (let fi = 0; fi < 4; fi++) {
    const base = 5 + fi * 4;
    const m = MCP[fi];
    const phi = (SPLAY[fi] + spread * (fi - 1.5)) * D2R;
    const cur = CURL[entry.f[fi]] || CURL.E;
    let theta = 0;
    p = [m[0], m[1], 0];
    pts[base] = p;
    for (let k = 0; k < 3; k++) {
      theta += cur[k];
      const th = theta * D2R;
      const d = [Math.sin(phi) * Math.cos(th), -Math.cos(phi) * Math.cos(th), Math.sin(th)];
      p = [p[0] + d[0] * LEN[fi][k], p[1] + d[1] * LEN[fi][k], p[2] + d[2] * LEN[fi][k]];
      pts[base + 1 + k] = p;
    }
  }
  const r = (entry.rot || 0) * D2R;
  if (r) {
    const c = Math.cos(r);
    const s = Math.sin(r);
    return pts.map(([x, y, z]) => [x * c - y * s, x * s + y * c, z]);
  }
  return pts;
}

/* المتجهات المطبَّعة أصغر من نقاط الرسم الافتراضية، فنكبّرها لتتساوى أحجام الأيدي. */
export const REC_SCALE = 2.0;
export function vecToPoints(vec) {
  const pts = [];
  for (let i = 0; i < 21; i++) pts.push([vec[i * 3] * REC_SCALE, vec[i * 3 + 1] * REC_SCALE, vec[i * 3 + 2] * REC_SCALE]);
  return pts;
}

export function flatten(points) {
  return points.flat();
}

/* ---------- الرسم (SVG) ---------- */

export const FINGER_CHAINS = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]];
export const FINGER_W = [0.19, 0.17, 0.17, 0.16, 0.14];

export function handSVG(points, label = '') {
  // مقياس ثابت لكل الأيدي حتى تبقى بنفس الحجم، والمركز عند منتصف الكف.
  const cx = 0;
  const cy = -1.0;
  const s = 2.5;
  const k = 100 / s;
  const T = (p) => [(50 + (p[0] - cx) * k).toFixed(1), (50 + (p[1] - cy) * k).toFixed(1)];
  const line = 'var(--hand-line, #3b6a8c)';
  const fill = 'var(--hand-fill, #bfe0f3)';
  const ol = 0.05 * k;

  const palmIdx = [0, 1, 5, 9, 13, 17];
  const palmPts = palmIdx.map((i) => T(points[i]).join(',')).join(' ');
  const palmW = 0.12 * k;
  let out = `<polygon points="${palmPts}" style="fill:${line};stroke:${line}" stroke-width="${(palmW + 2 * ol).toFixed(1)}" stroke-linejoin="round"/>`;
  out += `<polygon points="${palmPts}" style="fill:${fill};stroke:${fill}" stroke-width="${palmW.toFixed(1)}" stroke-linejoin="round"/>`;

  const order = FINGER_CHAINS
    .map((chain, i) => ({ chain, i, z: chain.reduce((a, j) => a + points[j][2], 0) / chain.length }))
    .sort((a, b) => a.z - b.z);
  for (const { chain, i } of order) {
    const pl = chain.map((j) => T(points[j]).join(',')).join(' ');
    const w = FINGER_W[i] * k;
    const common = 'fill="none" stroke-linecap="round" stroke-linejoin="round"';
    out += `<polyline points="${pl}" ${common} style="stroke:${line}" stroke-width="${(w + 2 * ol).toFixed(1)}"/>`;
    out += `<polyline points="${pl}" ${common} style="stroke:${fill}" stroke-width="${w.toFixed(1)}"/>`;
  }
  const aria = label ? ` role="img" aria-label="${label}"` : ' aria-hidden="true"';
  return `<svg class="hand" viewBox="0 0 100 100"${aria}>${out}</svg>`;
}

export { fingerStates };

/* ---------- يد بقيم متصلة (للشخصية المتحركة) ----------
   v = [إبهام, سبابة, وسطى, بنصر, خنصر] كل قيمة من 0 (مطوي) إلى 1 (ممدود). */
const lerp = (a, b, t) => a + (b - a) * t;
const clamp01 = (x) => Math.max(0, Math.min(1, x));

export function poseFromValues(v) {
  const pts = new Array(21);
  pts[0] = [0, 0, 0];
  const tv = clamp01(v[0]);
  let p = [-0.32, -0.28, 0];
  pts[1] = p;
  for (let k = 0; k < 3; k++) {
    const a = lerp(THUMB.in.a[k], THUMB.out.a[k], tv) * D2R;
    const z = lerp(THUMB.in.z, THUMB.out.z, tv);
    p = [p[0] + Math.sin(a) * THUMB_LEN[k], p[1] - Math.cos(a) * THUMB_LEN[k], (z * (k + 1)) / 3];
    pts[2 + k] = p;
  }
  const ext = v.slice(1).reduce((s, x) => s + clamp01(x), 0);
  const spread = ext >= 3 ? 6 : 0;
  for (let fi = 0; fi < 4; fi++) {
    const base = 5 + fi * 4;
    const m = MCP[fi];
    const phi = (SPLAY[fi] + spread * (fi - 1.5)) * D2R;
    const c = 1 - clamp01(v[fi + 1]);
    let theta = 0;
    p = [m[0], m[1], 0];
    pts[base] = p;
    for (let k = 0; k < 3; k++) {
      theta += lerp(CURL.E[k], CURL.C[k], c);
      const th = theta * D2R;
      const d = [Math.sin(phi) * Math.cos(th), -Math.cos(phi) * Math.cos(th), Math.sin(th)];
      p = [p[0] + d[0] * LEN[fi][k], p[1] + d[1] * LEN[fi][k], p[2] + d[2] * LEN[fi][k]];
      pts[base + 1 + k] = p;
    }
  }
  return pts;
}
