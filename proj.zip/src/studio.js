import { createAvatar, PRESETS } from './avatar.js';
import { ALL_MOTIONS, GESTURES, EXPRESSIONS, CATEGORIES, planText, motionLabel } from './gestures.js';
import { patternOf, handSVG, poseToPoints } from './signs.js';
import { fingerStates, ARABIC_LETTERS, ENGLISH_LETTERS } from './core.js';

/* ============ اللغة (عربي / English) ============ */
let LANG = 'ar';
const EN = {}; // يملؤه i18n.js: المفتاح هو النص العربي
function setEN(map) { Object.assign(EN, map); }
function getLang() { return LANG; }
function T(s, ...a) {
  const r = LANG === 'en' && EN[s] !== undefined ? EN[s] : s;
  return a.length ? r.replace(/\{(\d+)\}/g, (m, i) => (a[Number(i)] ?? '')) : r;
}
function L(ar, en) { return LANG === 'en' ? en : ar; }

const _orig = new WeakMap();
const _origAttr = new WeakMap();
const ATTRS = ['aria-label', 'placeholder', 'title', 'alt'];
const collapse = (s) => s.replace(/\s+/g, ' ').trim();

function translateNode(node) {
  if (node.nodeType === 3) {
    if (!_orig.has(node)) {
      const c = collapse(node.nodeValue);
      if (!/[؀-ۿ]/.test(c)) return;
      _orig.set(node, { raw: node.nodeValue, key: c });
    }
    const o = _orig.get(node);
    if (!o) return;
    const tr = LANG === 'en' ? EN[o.key] : undefined;
    if (LANG === 'en' && tr !== undefined) {
      const lead = o.raw.match(/^\s*/)[0];
      const trail = o.raw.match(/\s*$/)[0];
      node.nodeValue = lead + tr + trail;
    } else node.nodeValue = o.raw;
    return;
  }
  if (node.nodeType !== 1) return;
  const tag = node.tagName;
  if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'SVG' || tag === 'svg') return;
  for (const a of ATTRS) {
    if (!node.hasAttribute(a)) continue;
    let m = _origAttr.get(node);
    if (!m) { m = {}; _origAttr.set(node, m); }
    if (!(a in m)) { const v = node.getAttribute(a); if (!/[؀-ۿ]/.test(v)) continue; m[a] = v; }
    if (a in m) {
      const tr = LANG === 'en' ? EN[collapse(m[a])] : undefined;
      node.setAttribute(a, tr !== undefined ? tr : m[a]);
    }
  }
  for (const ch of node.childNodes) translateNode(ch);
}

function applyLang(lang) {
  LANG = lang === 'en' ? 'en' : 'ar';
  const r = document.documentElement;
  r.lang = LANG;
  r.dir = LANG === 'en' ? 'ltr' : 'rtl';
  translateNode(document.body);
  document.title = T('مترجم الإشارة');
  const b = document.getElementById('langBtn');
  if (b) { b.textContent = LANG === 'en' ? 'العربية' : 'English'; b.lang = LANG === 'en' ? 'ar' : 'en'; }
}

/* ============ لمسات ممتعة ============ */
const FACTS = [
  { ar: 'يوجد أكثر من 70 مليون أصم في العالم بحسب الاتحاد العالمي للصم، ويستخدم كثير منهم لغة الإشارة.', en: 'There are more than 70 million deaf people worldwide according to the World Federation of the Deaf, and many of them use sign language.' },
  { ar: 'لغات الإشارة ليست لغة واحدة: يوجد أكثر من 300 لغة إشارة مختلفة في العالم.', en: 'Sign language is not one language: there are more than 300 different sign languages in the world.' },
  { ar: 'لغات الإشارة لها قواعدها الخاصة، وليست مجرد حروف مرسومة بالأيدي.', en: 'Sign languages have their own grammar. They are far more than letters drawn with the hands.' },
  { ar: 'تعابير الوجه وحركة الحاجبين جزء من القواعد في لغات الإشارة، فهي تُظهر السؤال والنفي والمشاعر.', en: 'Facial expressions and eyebrow movements are part of sign language grammar. They mark questions, negation and feelings.' },
  { ar: 'هجاء الأصابع يُستخدم عادةً للأسماء والكلمات التي ليس لها إشارة، ولا يُغني عن تعلّم الإشارات نفسها.', en: 'Fingerspelling is usually used for names and words that have no sign. It does not replace learning the signs themselves.' },
  { ar: 'يوم 23 سبتمبر هو اليوم الدولي للغات الإشارة، واحتُفل به لأول مرة عام 2018.', en: '23 September is the International Day of Sign Languages. It was first celebrated in 2018.' },
  { ar: 'هذا الموقع يعمل كله داخل متصفحك: صور الكاميرا لا تُرسل لأي مكان.', en: 'This whole site runs inside your browser. Camera images are never sent anywhere.' },
];
let factIdx = Math.floor(Math.random() * FACTS.length);
function showFact(next = false) {
  if (next) factIdx = (factIdx + 1) % FACTS.length;
  const f = FACTS[factIdx];
  const t = document.getElementById('factText');
  if (t) t.textContent = L(f.ar, f.en);
}

function confetti(n = 46) {
  if (document.documentElement.dataset.motion === 'reduce') return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const box = document.createElement('div');
  box.className = 'confetti';
  const cols = ['#14b8a6', '#e0b34a', '#14b8a6', '#eef4f3', '#14b8a6'];
  for (let i = 0; i < n; i++) {
    const p = document.createElement('i');
    p.style.left = `${Math.random() * 100}%`;
    p.style.background = cols[i % cols.length];
    p.style.animationDelay = `${Math.random() * 0.5}s`;
    p.style.transform = `rotate(${Math.random() * 360}deg)`;
    box.appendChild(p);
  }
  document.body.appendChild(box);
  setTimeout(() => box.remove(), 2800);
}

/* ============ الشخصية في تبويب الكتابة ============ */
let avatar = null;
const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
function reduceMotionOn() {
  return !!(prefs.motion || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches));
}
function ensureAvatar() {
  if (avatar) return avatar;
  avatar = createAvatar(el.avatarBox, { preset: prefs.preset, mirror: prefs.mirror, reduceMotion: reduceMotionOn(), label: T('الشخصية المتحركة') });
  return avatar;
}
function handValsOf(s) {
  if (s.entry) return patternOf(s.entry);
  if (s.vec) return fingerStates(s.vec).map((v) => Math.max(0, Math.min(1, v)));
  return [0.4, 0.4, 0.4, 0.4, 0.4];
}
let runId = 0;
function stepMs() { return Number(el.speedRange.value) * 100; }

async function performEntry(s, my) {
  const av = ensureAvatar();
  av.setReduceMotion(reduceMotionOn());
  const calm = reduceMotionOn();
  if (s.kind === 'g') {
    const m = ALL_MOTIONS[s.id];
    if (calm) { av.setFramePose(m.frames[Math.floor(m.frames.length / 2)]); await sleepMs(stepMs() * 1.2); }
    else { await av.play(m.frames, { speed: 1000 / stepMs() }); if (my === runId) await av.rest(300); }
  } else {
    const fr = [{ d: 320, R: { x: 112, y: 212, a: s.entry?.rot || 0, h: handValsOf(s) }, f: { ms: 0.35, hr: 0.1 } }];
    if (calm) { av.setFramePose(fr[0]); await sleepMs(stepMs()); }
    else { await av.play(fr, { speed: 1000 / stepMs() }); if (my === runId) await sleepMs(stepMs() * 0.55); }
  }
}

function showBig(i, active = true) {
  state.seq.forEach((s) => s.card.classList.remove('active'));
  const s = state.seq[i];
  if (!s) {
    el.bigSign.textContent = '';
    el.bigLetter.textContent = '—';
    el.bigCount.textContent = T('اكتب نصاً بالعربية أو الإنجليزية');
    return;
  }
  state.idx = i;
  if (s.kind === 'g') { el.bigSign.textContent = ''; el.bigLetter.textContent = motionLabel(s.id, LANG); }
  else { el.bigSign.innerHTML = s.svg; el.bigLetter.textContent = s.ch; }
  s.card.classList.add('active');
  el.bigCount.textContent = T('{0} من {1}', i + 1, state.seq.length);
  if (active) {
    visualAlert();
    try { s.card.scrollIntoView({ block: 'nearest', behavior: reduceMotionOn() ? 'auto' : 'smooth' }); } catch { /* تجاهل */ }
  }
}
function stopPlay(finished = false) {
  runId++;
  if (avatar) { avatar.stop(); if (state.playing || finished) avatar.rest(350); }
  state.playing = false;
  el.playBtn.textContent = T('تشغيل');
  if (finished) { state.idx = 0; showBig(0, false); el.bigCount.textContent = T('انتهى العرض. اضغط «تشغيل» لإعادته.'); }
}
async function startPlay() {
  renderWords();
  if (!state.seq.length) { toast(T('اكتب نصاً بالعربية أو الإنجليزية أولاً.')); return; }
  const my = ++runId;
  state.playing = true;
  el.playBtn.textContent = T('إيقاف');
  for (let i = state.idx >= state.seq.length - 1 ? 0 : state.idx; i < state.seq.length; i++) {
    if (my !== runId) return;
    showBig(i, true);
    await performEntry(state.seq[i], my);
    if (my !== runId) return;
    const nx = state.seq[i + 1];
    if (nx && nx.wi !== state.seq[i].wi) await sleepMs(stepMs() * 0.35);
  }
  if (my === runId) stopPlay(true);
}
async function playOne(i) {
  stopPlay();
  if (!state.seq.length) return;
  const my = ++runId;
  showBig(i, true);
  await performEntry(state.seq[i], my);
}
function setFocus(on) {
  el.bigStage.classList.toggle('focus', on);
  el.focusBtn.setAttribute('aria-pressed', String(on));
  el.focusBtn.textContent = on ? T('إغلاق شاشة العرض') : T('شاشة العرض');
}
function setView(v) {
  prefs.view = v === 'hands' ? 'hands' : 'avatar';
  el.bigStage.classList.toggle('view-hands', prefs.view === 'hands');
  el.bigStage.classList.toggle('view-avatar', prefs.view === 'avatar');
}
let avClicks = 0;
function avatarEasterEgg() {
  if (state.playing) return;
  avClicks++;
  const ids = Object.keys(GESTURES);
  const id = ids[Math.floor(Math.random() * ids.length)];
  const my = ++runId;
  ensureAvatar().play(ALL_MOTIONS[id].frames, { speed: 1.2 }).then(() => { if (my === runId) avatar.rest(300); });
  el.bigLetter.textContent = motionLabel(id, LANG);
  if (avClicks % 5 === 0) { confetti(36); toast(T('أنا سعيد برفقتك! 🎉')); }
}

/* ============ مكتبة الحركات ============ */
let gestCat = 'all';
const gestAvatars = [];
function renderGestures() {
  const cats = el.gestCats;
  cats.textContent = '';
  const mk = (id, label) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip'; b.textContent = label;
    b.setAttribute('aria-pressed', String(gestCat === id));
    b.addEventListener('click', () => { gestCat = id; renderGestures(); });
    cats.appendChild(b);
  };
  mk('all', T('الكل'));
  for (const [k, v] of Object.entries(CATEGORIES)) mk(k, L(v.ar, v.en));
  mk('expr', T('تعابير الوجه'));
  el.gestGrid.textContent = '';
  gestAvatars.splice(0).forEach((a) => a.destroy());
  const list = Object.entries(ALL_MOTIONS).filter(([id, m]) => (gestCat === 'all' ? true : gestCat === 'expr' ? id.startsWith('x_') : m.cat === gestCat));
  for (const [id, m] of list) {
    const card = document.createElement('div');
    card.className = 'gest-card' + (id.startsWith('x_') ? ' expr' : '');
    card.tabIndex = 0; card.setAttribute('role', 'button');
    card.setAttribute('aria-label', T('أدِّ الحركة: {0}', L(m.ar, m.en)));
    const box = document.createElement('div'); box.className = 'gbox';
    const name = document.createElement('div'); name.className = 'gname'; name.textContent = L(m.ar, m.en);
    const al = document.createElement('div'); al.className = 'gal';
    al.textContent = (m.al?.[LANG] || m.al?.ar || []).slice(0, 3).join('، ');
    card.append(box, name, al);
    el.gestGrid.appendChild(card);
    const av = createAvatar(box, { preset: prefs.preset, mirror: prefs.mirror, static: true, reduceMotion: reduceMotionOn(), label: L(m.ar, m.en) });
    const peak = m.frames[Math.floor(m.frames.length / 2)];
    av.setFramePose(peak);
    gestAvatars.push(av);
    const go = async () => {
      if (reduceMotionOn()) return;
      await av.play(m.frames, { speed: 1 });
      av.setFramePose(peak);
    };
    card.addEventListener('click', go);
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
  }
}
function setLibMode(m) {
  state.libMode = m;
  el.gestWrap.hidden = m !== 'gestures';
  el.lettersWrap.hidden = m === 'gestures';
  if (m === 'gestures') renderGestures(); else gestAvatars.splice(0).forEach((a) => a.destroy());
}

/* ============ لعبة التحدي ============ */
const game = { on: false, mode: 'gesture', round: 0, total: 10, score: 0, streak: 0, best: 0, answer: null, locked: false, av: null, rounds: 0 };
function shuf(a) { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; }
function gameStats() {
  el.gScore.textContent = String(game.score);
  el.gStreak.textContent = String(game.streak);
  el.gBest.textContent = String(game.best);
}
function loadBest() { try { game.best = Number(localStorage.getItem('sign.best.v1')) || 0; } catch { game.best = 0; } }
function saveBest() { try { localStorage.setItem('sign.best.v1', String(game.best)); } catch { /* تجاهل */ } }

function gameNewRound() {
  game.locked = false;
  game.round += 1;
  el.gameMsg.textContent = '';
  el.gameNext.hidden = true;
  el.gameReplay.hidden = false;
  el.gameQ.textContent = T('السؤال {0} من {1}', game.round, game.total);
  let pool;
  if (game.mode === 'gesture') pool = Object.keys(GESTURES).map((id) => ({ id, label: L(GESTURES[id].ar, GESTURES[id].en) }));
  else {
    const set = LANG === 'en' ? 'en' : 'ar';
    pool = (set === 'en' ? ENGLISH_LETTERS : ARABIC_LETTERS).map((c) => ({ id: c, label: c, set }));
  }
  const ans = pool[Math.floor(Math.random() * pool.length)];
  const opts = shuf([ans, ...shuf(pool.filter((p) => p.id !== ans.id)).slice(0, 3)]);
  game.answer = ans;
  el.gameOpts.textContent = '';
  for (const o of opts) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'btn'; b.textContent = o.label; b.dataset.id = o.id;
    if (game.mode === 'letter' && o.set === 'en') b.dir = 'ltr';
    b.addEventListener('click', () => gameAnswer(b));
    el.gameOpts.appendChild(b);
  }
  gamePresent();
}
function gamePresent() {
  const st = el.gameStage;
  if (game.mode === 'gesture') {
    if (!game.av) { st.textContent = ''; game.av = createAvatar(st, { preset: prefs.preset, mirror: prefs.mirror, reduceMotion: reduceMotionOn(), label: T('الحركة') }); }
    const m = ALL_MOTIONS[game.answer.id];
    if (reduceMotionOn()) game.av.setFramePose(m.frames[Math.floor(m.frames.length / 2)]);
    else game.av.play(m.frames, { speed: 0.9 }).then(() => game.av && game.av.rest(250));
  } else {
    if (game.av) { game.av.destroy(); game.av = null; }
    const entry = state.libs[game.answer.set][game.answer.id];
    st.innerHTML = `<div class="hand-big">${handSVG(poseToPoints(entry))}</div>`;
  }
}
function gameAnswer(btn) {
  if (game.locked) return;
  game.locked = true;
  const ok = btn.dataset.id === game.answer.id;
  el.gameOpts.querySelectorAll('button').forEach((b) => {
    if (b.dataset.id === game.answer.id) b.classList.add('right');
    else if (b === btn) b.classList.add('wrong');
    b.disabled = true;
  });
  if (ok) {
    game.streak += 1;
    game.score += 10 + Math.min(game.streak - 1, 5) * 2;
    el.gameMsg.textContent = game.streak >= 3 ? T('أحسنت! {0} إجابات متتالية', game.streak) : T('إجابة صحيحة!');
    if (game.streak % 3 === 0) confetti(30);
  } else {
    game.streak = 0;
    el.gameMsg.textContent = T('ليست هذه. الصحيح: {0}', game.answer.label);
  }
  gameStats();
  if (game.round >= game.total) {
    const newBest = game.score > game.best;
    if (newBest) { game.best = game.score; saveBest(); }
    gameStats();
    el.gameQ.textContent = T('انتهت الجولة! نتيجتك {0} نقطة.', game.score) + (newBest ? ' ' + T('رقم قياسي جديد!') : '');
    if (newBest || game.score >= 70) confetti(70);
    game.on = false;
    el.gameStart.hidden = false; el.gameStart.textContent = T('جولة جديدة');
    el.gameNext.hidden = true;
  } else el.gameNext.hidden = false;
}
function gameStart() {
  Object.assign(game, { on: true, round: 0, score: 0, streak: 0 });
  el.gameStart.hidden = true;
  gameStats();
  gameNewRound();
}
function initGame() {
  loadBest(); gameStats(); showFact();
  bindSeg(el.gameMode, (m) => { game.mode = m; game.on = false; el.gameStart.hidden = false; el.gameStart.textContent = T('ابدأ'); el.gameOpts.textContent = ''; el.gameNext.hidden = true; el.gameReplay.hidden = true; el.gameQ.textContent = T('اضغط «ابدأ» لتبدأ جولة من 10 أسئلة.'); el.gameStage.textContent = ''; game.av = null; });
  el.gameStart.addEventListener('click', gameStart);
  el.gameNext.addEventListener('click', gameNewRound);
  el.gameReplay.addEventListener('click', gamePresent);
  el.factBtn.addEventListener('click', () => showFact(true));
}
