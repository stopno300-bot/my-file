import { poseFromValues, FINGER_CHAINS, FINGER_W } from './signs.js';

/* الشخصية المتحركة: رسم SVG بمفاصل (كتفان، مرفقان، معصمان)، ووجه بتعابير، وحركة بالإطارات المفتاحية.
   الحركات المعرّفة هنا تجريبية لأغراض العرض، وليست قاموس لغة إشارة رسمي. */

export const AV = { W: 400, H: 500, SL: [128, 268], SR: [272, 268], L1: 88, L2: 82, K: 42 };

/* أشكال اليد الجاهزة: [إبهام، سبابة، وسطى، بنصر، خنصر] */
export const HS = {
  open: [1, 1, 1, 1, 1], flat: [0.2, 1, 1, 1, 1], fist: [0, 0, 0, 0, 0], point: [0, 1, 0, 0, 0],
  thumb: [1, 0, 0, 0, 0], peace: [0, 1, 1, 0, 0], love: [1, 1, 0, 0, 1], ok: [0.45, 0.55, 1, 1, 1],
  relax: [0.35, 0.4, 0.4, 0.45, 0.45], claw: [0.7, 0.55, 0.55, 0.55, 0.55], pinch: [0.5, 0.5, 0.15, 0.15, 0.15],
  c: [0.8, 0.6, 0.6, 0.6, 0.6], three: [1, 1, 1, 0, 0],
};

/* الوضع الافتراضي: x,y موضع المعصم، a اتجاه اليد (0 لأعلى، 90 لليمين، 180 لأسفل). */
export const REST = {
  R: { x: 122, y: 408, a: 188, h: HS.relax },
  L: { x: 278, y: 408, a: 172, h: HS.relax },
  f: { hr: 0, hn: 0, hx: 0, bL: 0, bR: 0, bt: 0, eo: 1, gx: 0, gy: 0, mo: 0, ms: 0.35 },
};

const clampN = (x, a, b) => Math.max(a, Math.min(b, x));

/** حلّ ذراع بمفصلين: يعيد المرفق والمعصم (بعد قصّ البعد الزائد). out=-1 للكتف الأيسر في الشاشة. */
export function solveArm(S, W, L1 = AV.L1, L2 = AV.L2, out = 1) {
  let dx = W[0] - S[0];
  let dy = W[1] - S[1];
  let d = Math.hypot(dx, dy) || 1e-6;
  const dMax = L1 + L2 - 0.5;
  const dMin = Math.abs(L1 - L2) + 1;
  const dd = clampN(d, dMin, dMax);
  dx = (dx / d) * dd; dy = (dy / d) * dd; d = dd;
  const ux = dx / d, uy = dy / d;
  const a = (d * d + L1 * L1 - L2 * L2) / (2 * d);
  const h = Math.sqrt(Math.max(0, L1 * L1 - a * a));
  const px = -uy, py = ux;
  const cands = [
    [S[0] + ux * a + px * h, S[1] + uy * a + py * h],
    [S[0] + ux * a - px * h, S[1] + uy * a - py * h],
  ];
  const score = (E) => E[1] + 0.6 * out * (E[0] - S[0]);
  const E = score(cands[0]) >= score(cands[1]) ? cands[0] : cands[1];
  return { E, W: [S[0] + dx, S[1] + dy] };
}

const lerpN = (a, b, t) => a + (b - a) * t;
const ease = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);

function cloneHand(h) { return { x: h.x, y: h.y, a: h.a, h: h.h.slice() }; }
export function clonePose(p) { return { R: cloneHand(p.R), L: cloneHand(p.L), f: { ...p.f } }; }

/** يدمج إطاراً جزئياً فوق الوضع الافتراضي. */
export function framePose(fr) {
  const p = clonePose(REST);
  for (const s of ['R', 'L']) {
    if (fr[s]) {
      const q = fr[s];
      p[s] = { x: q.x ?? p[s].x, y: q.y ?? p[s].y, a: q.a ?? p[s].a, h: (q.h || p[s].h).slice() };
    }
  }
  if (fr.f) Object.assign(p.f, fr.f);
  return p;
}

export function lerpPose(A, B, t) {
  const o = clonePose(A);
  for (const s of ['R', 'L']) {
    o[s].x = lerpN(A[s].x, B[s].x, t);
    o[s].y = lerpN(A[s].y, B[s].y, t);
    o[s].a = lerpN(A[s].a, B[s].a, t);
    o[s].h = A[s].h.map((v, i) => lerpN(v, B[s].h[i], t));
  }
  for (const k of Object.keys(A.f)) o.f[k] = lerpN(A.f[k], B.f[k], t);
  return o;
}

/** يقلب الوضع أفقياً (للأشخاص الذين يستخدمون اليد اليسرى كيد رئيسية). */
export function mirrorPose(p) {
  const m = (h) => ({ x: AV.W - h.x, y: h.y, a: -h.a, h: h.h.slice() });
  const o = { R: m(p.L), L: m(p.R), f: { ...p.f } };
  o.f.hx = -p.f.hx; o.f.gx = -p.f.gx;
  const t = o.f.bL; o.f.bL = o.f.bR; o.f.bR = t;
  return o;
}

export const PRESETS = {
  nour: { name: { ar: 'نور', en: 'Nour' }, style: 'long', skin: '#e9bb97', skinHi: '#f6d6ba', skinLo: '#c8946f', line: '#8a5636', hair: '#2a1c1a', hairHi: '#5a4038', blazer: '#2a3034', blazer2: '#1b1f22', inner: '#14b8a6', iris: '#5b3a22', lip: '#b4535c', cheek: '#e79a8e' },
  samer: { name: { ar: 'سامر', en: 'Samer' }, style: 'short', skin: '#c98e63', skinHi: '#dfa97f', skinLo: '#a8704a', line: '#6e4026', hair: '#1c1514', hairHi: '#44352f', blazer: '#2a3034', blazer2: '#1b1f22', inner: '#14b8a6', iris: '#3d2616', lip: '#9c4a4a', cheek: '#c97a69' },
  robo: { name: { ar: 'روبو', en: 'Robo' }, style: 'robot', skin: '#c9d6d9', skinHi: '#e8f1f2', skinLo: '#9fb2b6', line: '#55696e', hair: '#3b4549', hairHi: '#6c7a80', blazer: '#2a3034', blazer2: '#1b1f22', inner: '#e0b34a', iris: '#14b8a6', lip: '#2b6f69', cheek: '#14b8a6' },
};

const NS = 'http://www.w3.org/2000/svg';
let AV_UID = 0;
const svgEl = (tag, attrs = {}, parent) => {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  if (parent) parent.appendChild(e);
  return e;
};

function makeHand(parent) {
  const g = svgEl('g', {}, parent);
  const inner = svgEl('g', {}, g);
  const palmO = svgEl('polygon', { class: 'av-line', 'stroke-linejoin': 'round' }, inner);
  const palmF = svgEl('polygon', { class: 'av-skin', 'stroke-linejoin': 'round' }, inner);
  const order = [4, 3, 2, 1, 0];
  const fingers = {};
  for (const i of order) {
    fingers[i] = {
      o: svgEl('polyline', { class: 'av-line', style: 'fill:none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, inner),
      f: svgEl('polyline', { class: 'av-skin', style: 'fill:none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, inner),
    };
  }
  return { g, inner, palmO, palmF, fingers };
}

function updateHand(hd, vals, mirror) {
  const k = AV.K;
  const pts = poseFromValues(vals);
  const P = (i) => `${(pts[i][0] * k).toFixed(1)},${(pts[i][1] * k).toFixed(1)}`;
  const palm = [0, 1, 5, 9, 13, 17].map(P).join(' ');
  const ol = 0.05 * k;
  const palmW = 0.12 * k;
  hd.palmO.setAttribute('points', palm); hd.palmO.setAttribute('stroke-width', (palmW + 2 * ol).toFixed(1));
  hd.palmF.setAttribute('points', palm); hd.palmF.setAttribute('stroke-width', palmW.toFixed(1));
  FINGER_CHAINS.forEach((chain, i) => {
    const pl = chain.map(P).join(' ');
    const w = FINGER_W[i] * k;
    hd.fingers[i].o.setAttribute('points', pl); hd.fingers[i].o.setAttribute('stroke-width', (w + 2 * ol).toFixed(1));
    hd.fingers[i].f.setAttribute('points', pl); hd.fingers[i].f.setAttribute('stroke-width', w.toFixed(1));
  });
  hd.inner.setAttribute('transform', mirror ? 'scale(-1,1)' : '');
}

/**
 * ينشئ الشخصية داخل عنصر. يعيد واجهة: setPose, play, stop, setPreset, setMirror, setFace, destroy ...
 */
export function createAvatar(container, opts = {}) {
  let preset = PRESETS[opts.preset] || PRESETS.nour;
  let mirror = !!opts.mirror;
  let calm = !!opts.reduceMotion;
  container.innerHTML = '';
  const svg = svgEl('svg', { viewBox: `0 0 ${AV.W} ${AV.H}`, class: 'avatar-svg', role: 'img', 'aria-label': opts.label || 'avatar' });
  container.appendChild(svg);
  const uid = ++AV_UID;
  const defs = svgEl('defs', {}, svg);
  const grad = (tag, id, attrs, stops) => {
    const g = svgEl(tag, { id: `${id}${uid}`, ...attrs }, defs);
    stops.forEach(([o, c, op]) => svgEl('stop', { offset: o, 'stop-color': c, ...(op != null ? { 'stop-opacity': op } : {}) }, g));
  };
  grad('linearGradient', 'blz', { x1: 0, y1: 0, x2: 0, y2: 1 }, [[0, 'var(--av-blazer)'], [1, 'var(--av-blazer2)']]);
  grad('radialGradient', 'glow', { cx: 0.5, cy: 0.38, r: 0.6 }, [[0, 'var(--av-glow)', 0.5], [1, 'var(--av-glow)', 0]]);
  grad('radialGradient', 'sk', { cx: 0.48, cy: 0.4, r: 0.72 }, [[0, 'var(--av-skin-hi)'], [0.55, 'var(--av-skin)'], [1, 'var(--av-skin-lo)']]);
  grad('linearGradient', 'neck', { x1: 0, y1: 0, x2: 0, y2: 1 }, [[0, 'var(--av-skin-lo)'], [1, 'var(--av-skin)']]);
  grad('linearGradient', 'hair', { x1: 0, y1: 0, x2: 1, y2: 1 }, [[0, 'var(--av-hair-hi)'], [0.5, 'var(--av-hair)'], [1, 'var(--av-hair)']]);
  grad('linearGradient', 'hand', { gradientUnits: 'userSpaceOnUse', x1: 0, y1: -95, x2: 0, y2: 12 }, [[0, 'var(--av-skin-hi)'], [1, 'var(--av-skin)']]);

  svgEl('ellipse', { cx: 200, cy: 250, rx: 215, ry: 235, fill: `url(#glow${uid})` }, svg);
  const root = svgEl('g', {}, svg);
  const flipG = svgEl('g', {}, root);
  const body = svgEl('g', {}, flipG);

  const hairBack = svgEl('g', {}, body);
  svgEl('path', { d: 'M88 520 L92 345 Q96 280 150 262 L250 262 Q304 280 308 345 L312 520 Z', fill: `url(#blz${uid})` }, body);
  svgEl('rect', { x: 182, y: 188, width: 36, height: 80, rx: 14, fill: `url(#neck${uid})` }, body);
  svgEl('path', { d: 'M160 262 L200 340 L240 262 Z', fill: 'var(--av-inner)' }, body);
  svgEl('path', { d: 'M172 262 Q200 300 228 262 Z', fill: 'var(--av-skin)' }, body);
  svgEl('path', { d: 'M150 262 L196 344 L166 356 L134 300 Z', fill: 'rgba(255,255,255,.07)', stroke: 'rgba(255,255,255,.14)', 'stroke-width': 1.5 }, body);
  svgEl('path', { d: 'M250 262 L204 344 L234 356 L266 300 Z', fill: 'rgba(255,255,255,.07)', stroke: 'rgba(255,255,255,.14)', 'stroke-width': 1.5 }, body);
  svgEl('circle', { cx: 240, cy: 322, r: 5, fill: 'var(--av-gold)' }, body);
  svgEl('circle', { cx: 238.5, cy: 320.5, r: 1.8, fill: '#fff', opacity: 0.7 }, body);
  svgEl('ellipse', { cx: 200, cy: 219, rx: 34, ry: 9, fill: 'rgba(0,0,0,.14)' }, body);

  const armG = svgEl('g', {}, body);
  const mkArm = () => ({
    ou: svgEl('line', { 'stroke-linecap': 'round', stroke: 'rgba(0,0,0,.4)', 'stroke-width': 35 }, armG),
    ol: svgEl('line', { 'stroke-linecap': 'round', stroke: 'rgba(0,0,0,.4)', 'stroke-width': 31 }, armG),
    up: svgEl('line', { 'stroke-linecap': 'round', stroke: 'var(--av-blazer)', 'stroke-width': 30 }, armG),
    lo: svgEl('line', { 'stroke-linecap': 'round', stroke: 'var(--av-blazer)', 'stroke-width': 26 }, armG),
    jt: svgEl('circle', { r: 13, fill: 'var(--av-blazer)' }, armG),
    cuff: svgEl('line', { 'stroke-linecap': 'butt', stroke: 'var(--av-inner)', 'stroke-width': 21 }, armG),
  });
  const armR = mkArm();
  const armL = mkArm();
  const handR = makeHand(armG);
  const handL = makeHand(armG);

  const headG = svgEl('g', {}, body);
  const hairBackHead = svgEl('g', {}, headG);
  const faceG = svgEl('g', {}, headG);
  const earL = svgEl('ellipse', { cx: 142, cy: 152, rx: 9, ry: 15, fill: 'var(--av-skin)' }, faceG);
  const earR = svgEl('ellipse', { cx: 258, cy: 152, rx: 9, ry: 15, fill: 'var(--av-skin)' }, faceG);
  svgEl('ellipse', { cx: 143, cy: 153, rx: 4, ry: 8, fill: 'var(--av-skin-lo)', opacity: 0.5 }, faceG);
  svgEl('ellipse', { cx: 257, cy: 153, rx: 4, ry: 8, fill: 'var(--av-skin-lo)', opacity: 0.5 }, faceG);
  const headShape = svgEl('path', { d: 'M141 132 C141 80 168 68 200 68 C232 68 259 80 259 132 C259 172 238 210 200 214 C162 210 141 172 141 132 Z', fill: `url(#sk${uid})` }, faceG);
  svgEl('path', { d: 'M150 168 Q200 232 250 168 Q236 206 200 214 Q164 206 150 168 Z', fill: 'var(--av-skin-lo)', opacity: 0.18 }, faceG);
  const hairFront = svgEl('g', {}, faceG);
  const cheeks = [svgEl('ellipse', { cx: 164, cy: 172, rx: 12, ry: 7, fill: 'var(--av-cheek)', opacity: 0.4 }, faceG),
    svgEl('ellipse', { cx: 236, cy: 172, rx: 12, ry: 7, fill: 'var(--av-cheek)', opacity: 0.4 }, faceG)];
  svgEl('path', { d: 'M197 138 Q194 160 189 166 Q200 172 211 166 Q206 160 203 138 Z', fill: 'var(--av-skin-lo)', opacity: 0.32 }, faceG);
  svgEl('ellipse', { cx: 194, cy: 167, rx: 2.4, ry: 1.6, fill: 'rgba(60,25,15,.5)' }, faceG);
  svgEl('ellipse', { cx: 206, cy: 167, rx: 2.4, ry: 1.6, fill: 'rgba(60,25,15,.5)' }, faceG);
  let eyeN = 0;
  const mkEye = (cx, side) => {
    const g = svgEl('g', { transform: `translate(${cx},144)` }, faceG);
    svgEl('ellipse', { rx: 19, ry: 11, cy: -1, fill: 'var(--av-skin-lo)', opacity: 0.22 }, g);
    const white = svgEl('ellipse', { rx: 13, ry: 9, fill: '#fbfbf8' }, g);
    const cid = `ec${uid}_${eyeN++}`;
    const cp = svgEl('clipPath', { id: cid }, defs);
    const clipE = svgEl('ellipse', { rx: 13, ry: 9 }, cp);
    const ig = svgEl('g', { 'clip-path': `url(#${cid})` }, g);
    const iris = svgEl('circle', { r: 7.4, fill: 'var(--av-iris)' }, ig);
    const ring = svgEl('circle', { r: 7.4, fill: 'none', stroke: 'rgba(0,0,0,.45)', 'stroke-width': 1.4 }, ig);
    const pupil = svgEl('circle', { r: 3.2, fill: '#0b0b0b' }, ig);
    const shine = svgEl('circle', { r: 1.9, fill: '#fff' }, ig);
    const shade = svgEl('ellipse', { rx: 13, ry: 4, cy: -6, fill: 'rgba(0,0,0,.18)' }, ig);
    const lidU = svgEl('path', { fill: 'none', stroke: '#1d1210', 'stroke-width': 2.8, 'stroke-linecap': 'round' }, g);
    const lidL = svgEl('path', { fill: 'none', stroke: 'rgba(60,30,20,.35)', 'stroke-width': 1.2, 'stroke-linecap': 'round' }, g);
    const lash = svgEl('path', { fill: 'none', stroke: '#1d1210', 'stroke-width': 2, 'stroke-linecap': 'round', d: `M${side * 13},-1 l${side * 5},-3 M${side * 11},-4 l${side * 4},-5` }, g);
    return { g, white, clipE, iris, ring, pupil, shine, shade, lidU, lidL, lash, side };
  };
  const eyeL = mkEye(176, -1);
  const eyeR = mkEye(224, 1);
  const mkBrow = () => svgEl('path', { d: 'M-16 2 Q-2 -6 16 -1 Q-2 -2 -16 5 Z', fill: 'var(--av-hair)', stroke: 'var(--av-hair)', 'stroke-width': 2.5, 'stroke-linejoin': 'round' }, faceG);
  const browL = mkBrow();
  const browR = mkBrow();
  const mouthFill = svgEl('path', { fill: '#4a161d' }, faceG);
  const teeth = svgEl('path', { fill: '#f7f4ee' }, faceG);
  const lipLow = svgEl('path', { fill: 'none', stroke: 'var(--av-lip)', 'stroke-width': 6, 'stroke-linecap': 'round', opacity: 0.85 }, faceG);
  const mouthLine = svgEl('path', { fill: 'none', stroke: 'var(--av-lip-dk)', 'stroke-width': 3.4, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, faceG);

  const cssVars = () => {
    const s = svg.style;
    const P = preset;
    const m = { skin: P.skin, 'skin-hi': P.skinHi, 'skin-lo': P.skinLo, hair: P.hair, 'hair-hi': P.hairHi, blazer: P.blazer, blazer2: P.blazer2, inner: P.inner, iris: P.iris, cheek: P.cheek, lip: P.lip, 'lip-dk': P.line, gold: '#e0b34a', glow: 'var(--glow, #14b8a6)' };
    for (const [k, v] of Object.entries(m)) s.setProperty(`--av-${k}`, v);
    s.setProperty('--av-line', P.line);
  };
  const style = svgEl('style', {}, svg);
  style.textContent = `.av-skin{stroke:url(#hand${uid});fill:url(#hand${uid})}.av-line{stroke:var(--av-line);fill:var(--av-line)}`;

  function buildStyle() {
    hairBack.innerHTML = ''; hairBackHead.innerHTML = ''; hairFront.innerHTML = '';
    const sty = preset.style;
    const H = `url(#hair${uid})`;
    if (sty === 'long') {
      svgEl('path', { d: 'M136 136 Q128 58 200 54 Q272 58 264 136 L276 262 Q276 296 246 290 L246 196 L154 196 L154 290 Q124 296 124 262 Z', fill: H }, hairBackHead);
      svgEl('path', { d: 'M139 140 Q140 74 200 68 Q260 74 261 140 Q252 98 226 90 Q214 112 180 96 Q150 106 139 140 Z', fill: H }, hairFront);
      svgEl('path', { d: 'M168 80 Q200 70 236 84', fill: 'none', stroke: 'rgba(255,255,255,.1)', 'stroke-width': 3, 'stroke-linecap': 'round' }, hairFront);
      svgEl('circle', { cx: 142, cy: 170, r: 3.4, fill: 'var(--av-gold)' }, hairFront);
    } else if (sty === 'short') {
      svgEl('path', { d: 'M139 138 Q134 64 200 62 Q266 64 261 138 Q258 104 236 96 Q202 108 170 94 Q144 104 139 138 Z', fill: H }, hairFront);
      svgEl('path', { d: 'M166 78 Q202 66 238 82', fill: 'none', stroke: 'rgba(255,255,255,.18)', 'stroke-width': 3, 'stroke-linecap': 'round' }, hairFront);
    } else {
      svgEl('rect', { x: 196, y: 50, width: 8, height: 22, rx: 4, fill: 'var(--av-hair)' }, hairBackHead);
      svgEl('circle', { cx: 200, cy: 46, r: 9, fill: 'var(--av-gold)' }, hairBackHead);
      svgEl('rect', { x: 126, y: 126, width: 15, height: 40, rx: 7, fill: 'var(--av-hair)' }, hairBackHead);
      svgEl('rect', { x: 259, y: 126, width: 15, height: 40, rx: 7, fill: 'var(--av-hair)' }, hairBackHead);
      svgEl('path', { d: 'M150 100 Q200 78 250 100', fill: 'none', stroke: 'rgba(255,255,255,.35)', 'stroke-width': 4, 'stroke-linecap': 'round' }, hairFront);
    }
    cheeks.forEach((c) => c.setAttribute('opacity', sty === 'robot' ? 0.5 : 0.4));
  }

  let cur = clonePose(REST);
  let token = 0;
  let t0 = performance.now();
  let blink = 0;
  let nextBlink = t0 + 2200;

  function drawFace(f, time) {
    const breathe = calm ? 0 : Math.sin(time / 900) * 1.6;
    headG.setAttribute('transform', `translate(${(f.hx * 0.6).toFixed(1)},${(breathe + f.hn * 6).toFixed(1)}) rotate(${(f.hx * 3).toFixed(1)} 200 210)`);
    body.setAttribute('transform', `translate(0,${(-breathe * 0.4).toFixed(2)})`);
    const eo = clampN(f.eo * (1 - blink), 0.04, 1.3);
    for (const e of [eyeL, eyeR]) {
      const ry = 9 * eo;
      e.white.setAttribute('ry', ry.toFixed(2)); e.clipE.setAttribute('ry', ry.toFixed(2));
      const gx = f.gx * 4, gy = f.gy * 3;
      for (const q of [e.iris, e.ring, e.pupil]) { q.setAttribute('cx', gx); q.setAttribute('cy', gy); }
      e.shine.setAttribute('cx', gx + 2.4); e.shine.setAttribute('cy', gy - 2.6);
      e.shade.setAttribute('cy', -ry * 0.7);
      e.lidU.setAttribute('d', `M-13.5,0 Q0,${(-ry * 2.05).toFixed(2)} 13.5,0`);
      e.lidL.setAttribute('d', `M-11.5,1 Q0,${(ry * 1.7).toFixed(2)} 11.5,1`);
      e.lash.style.opacity = eo > 0.3 ? 1 : 0;
    }
    const by = 123 - f.hr * 9;
    browL.setAttribute('transform', `translate(176,${(by + f.bt * 2).toFixed(1)}) rotate(${(f.bL * 18).toFixed(1)})`);
    browR.setAttribute('transform', `translate(224,${(by + f.bt * 2).toFixed(1)}) scale(-1,1) rotate(${(f.bR * 18).toFixed(1)})`);
    const w = 21 + f.ms * 4 + f.mo * 2;
    const cy = 188 - f.ms * 7;
    const uy = 188 + f.ms * 9 - f.mo * 2;
    const ly = uy + f.mo * 30 + 2;
    const up = `M${200 - w},${cy} Q${200 - w / 2},${uy - 3} 200,${uy - 1} Q${200 + w / 2},${uy - 3} ${200 + w},${cy}`;
    mouthLine.setAttribute('d', up);
    lipLow.setAttribute('d', `M${200 - w * 0.78},${cy + 2} Q200,${Math.max(uy, ly) + 12} ${200 + w * 0.78},${cy + 2}`);
    if (f.mo > 0.06) {
      mouthFill.setAttribute('d', `${up} Q200,${ly + 10} ${200 - w},${cy} Z`);
      mouthFill.style.display = '';
      const tw = w * 0.7;
      const ty = cy + (uy - cy) * 0.5;
      teeth.setAttribute('d', `M${200 - tw},${ty + 1} Q200,${uy + 1} ${200 + tw},${ty + 1} L${200 + tw},${ty + 5} Q200,${uy + 5} ${200 - tw},${ty + 5} Z`);
      teeth.style.display = f.mo > 0.15 ? '' : 'none';
    } else { mouthFill.style.display = 'none'; teeth.style.display = 'none'; }
  }

  function drawArm(arm, hd, S, h, out, mir) {
    const { E, W } = solveArm(S, [h.x, h.y], AV.L1, AV.L2, out);
    arm.up.setAttribute('x1', S[0]); arm.up.setAttribute('y1', S[1]); arm.up.setAttribute('x2', E[0]); arm.up.setAttribute('y2', E[1]);
    arm.lo.setAttribute('x1', E[0]); arm.lo.setAttribute('y1', E[1]); arm.lo.setAttribute('x2', W[0]); arm.lo.setAttribute('y2', W[1]);
    arm.ou.setAttribute('x1', S[0]); arm.ou.setAttribute('y1', S[1]); arm.ou.setAttribute('x2', E[0]); arm.ou.setAttribute('y2', E[1]);
    arm.ol.setAttribute('x1', E[0]); arm.ol.setAttribute('y1', E[1]); arm.ol.setAttribute('x2', W[0]); arm.ol.setAttribute('y2', W[1]);
    arm.jt.setAttribute('cx', E[0]); arm.jt.setAttribute('cy', E[1]);
    const ang = (h.a * Math.PI) / 180;
    const cx = W[0] - Math.sin(ang) * 6, cy = W[1] + Math.cos(ang) * 6;
    arm.cuff.setAttribute('x1', W[0]); arm.cuff.setAttribute('y1', W[1]); arm.cuff.setAttribute('x2', cx); arm.cuff.setAttribute('y2', cy);
    hd.g.setAttribute('transform', `translate(${W[0].toFixed(1)},${W[1].toFixed(1)}) rotate(${h.a.toFixed(1)})`);
    updateHand(hd, h.h, mir);
  }

  function render(time = performance.now()) {
    drawArm(armR, handR, AV.SL, cur.R, -1, true);
    drawArm(armL, handL, AV.SR, cur.L, 1, false);
    drawFace(cur.f, time);
    flipG.setAttribute('transform', mirror ? `translate(${AV.W},0) scale(-1,1)` : '');
  }

  let raf = 0;
  let alive = true;
  function idleLoop(time) {
    if (!alive) return;
    if (!calm) {
      if (time > nextBlink && !blink) { blink = 1; nextBlink = time + 140; }
      else if (blink && time > nextBlink) { blink = 0; nextBlink = time + 2000 + Math.random() * 3000; }
    }
    if (!calm || !svg.dataset.still) render(time);
    raf = requestAnimationFrame(idleLoop);
  }

  buildStyle(); cssVars(); render();
  if (!opts.static) raf = requestAnimationFrame(idleLoop);

  function tweenTo(target, ms) {
    const my = ++token;
    const from = clonePose(cur);
    if (ms <= 0 || calm) { cur = clonePose(target); render(); return Promise.resolve(true); }
    return new Promise((res) => {
      const st = performance.now();
      const step = (now) => {
        if (my !== token || !alive) return res(false);
        const t = clampN((now - st) / ms, 0, 1);
        cur = lerpPose(from, target, ease(t));
        if (opts.static) render(now);
        if (t >= 1) return res(true);
        requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const api = {
    svg,
    get pose() { return cur; },
    setPose(p) { token++; cur = clonePose(p); render(); },
    setFramePose(fr) { api.setPose(framePose(fr)); },
    async play(frames, o = {}) {
      const speed = o.speed || 1;
      const my = ++token;
      for (const fr of frames) {
        if (my !== token) return false;
        const target = framePose(fr);
        const ok = await (async () => {
          const myT = token;
          const from = clonePose(cur);
          const ms = (fr.d ?? 400) / speed;
          if (ms <= 0 || calm) { cur = target; render(); return true; }
          return new Promise((res) => {
            const st = performance.now();
            const step = (now) => {
              if (myT !== token || !alive) return res(false);
              const t = clampN((now - st) / ms, 0, 1);
              cur = lerpPose(from, target, ease(t));
              if (opts.static) render(now);
              if (t >= 1) return res(true);
              requestAnimationFrame(step);
            };
            requestAnimationFrame(step);
          });
        })();
        if (!ok) return false;
        if (fr.hold) { await sleep(fr.hold / speed); if (my !== token) return false; }
      }
      return my === token;
    },
    stop() { token++; },
    async rest(ms = 450) { return tweenTo(clonePose(REST), ms); },
    setPreset(id) { preset = PRESETS[id] || preset; buildStyle(); cssVars(); render(); },
    setMirror(m) { mirror = !!m; render(); },
    setReduceMotion(v) { calm = !!v; },
    renderNow() { render(); },
    destroy() { alive = false; cancelAnimationFrame(raf); token++; },
  };
  return api;
}
