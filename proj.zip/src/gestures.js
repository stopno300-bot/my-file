import { HS } from './avatar.js';
import { normalizeArabic } from './core.js';

/* مكتبة الحركات والتعابير. كل حركة سلسلة إطارات مفتاحية (d مدة الانتقال بالمللي ثانية، hold توقف).
   الحركات من تصميمي أنا وهي تجريبية: ليست إشارات معتمدة في أي لغة إشارة.
   للحصول على إشارات صحيحة يلزم مترجم إشارة أو شخص أصم يراجعها، ويمكن تعديلها من هذه المكتبة. */

const F = {
  neutral: {},
  happy: { ms: 0.95, mo: 0.45, hr: 0.35, eo: 1.05, bL: -0.2, bR: -0.2 },
  sad: { ms: -0.9, mo: 0, hr: 0, bL: -1, bR: -1, eo: 0.8, hn: 0.7, gy: 0.7 },
  surprised: { ms: 0, mo: 0.95, hr: 1, eo: 1.3, bL: -0.2, bR: -0.2 },
  angry: { ms: -0.6, mo: 0.05, hr: -0.3, bL: 1, bR: 1, bt: 1, eo: 0.8 },
  confused: { ms: -0.2, mo: 0.1, hr: 0.4, bL: -0.9, bR: 0.7, hx: 0.9, eo: 1 },
  question: { ms: 0, mo: 0.12, hr: 1, bL: -0.3, bR: -0.3, hx: 0.6, eo: 1.1 },
  think: { ms: 0, mo: 0, hr: 0.2, bL: 0.4, bR: -0.2, hx: -0.5, gx: -0.8, gy: -0.8 },
};

const wave = (x, y, h, amp, n, face) => {
  const fr = [{ d: 380, R: { x, y, a: 0, h }, f: face }];
  for (let i = 0; i < n; i++) fr.push({ d: 230, R: { x, y, a: i % 2 ? -amp : amp, h }, f: face });
  fr.push({ d: 260, R: { x, y, a: 0, h }, f: face });
  return fr;
};
const circle = (cx, cy, r, a, h, n, f) => {
  const pts = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  const fr = [];
  for (let k = 0; k < n * 4; k++) { const [px, py] = pts[k % 4]; fr.push({ d: 260, R: { x: cx + px * r, y: cy + py * r, a, h }, f: f }); }
  return fr;
};

/* id: {ar, en, cat, al: {ar:[...], en:[...]}, frames} */
export const GESTURES = {
  hello: { ar: 'مرحبا', en: 'Hello', cat: 'greet', al: { ar: ['مرحبا', 'اهلا', 'السلام عليكم', 'هلا', 'اهلين'], en: ['hello', 'hi', 'hey', 'welcome'] },
    frames: wave(96, 178, HS.open, 18, 4, F.happy) },
  bye: { ar: 'مع السلامة', en: 'Goodbye', cat: 'greet', al: { ar: ['مع السلامه', 'وداعا', 'باي', 'الى اللقاء'], en: ['bye', 'goodbye', 'see you'] },
    frames: [{ d: 350, R: { x: 98, y: 190, a: 5, h: HS.flat }, f: F.happy }, { d: 200, R: { x: 98, y: 190, a: 5, h: HS.claw }, f: F.happy }, { d: 200, R: { x: 98, y: 190, a: 5, h: HS.flat }, f: F.happy },
      { d: 200, R: { x: 98, y: 190, a: 5, h: HS.claw }, f: F.happy }, { d: 200, R: { x: 98, y: 190, a: 5, h: HS.flat }, f: F.happy }] },
  thanks: { ar: 'شكرا', en: 'Thank you', cat: 'polite', al: { ar: ['شكرا', 'شكرا لك', 'يعطيك العافيه', 'مشكور'], en: ['thanks', 'thank you', 'thx'] },
    frames: [{ d: 400, R: { x: 168, y: 222, a: -20, h: HS.flat }, f: F.happy }, { d: 500, R: { x: 140, y: 270, a: -60, h: HS.flat }, f: F.happy, hold: 150 }] },
  please: { ar: 'من فضلك', en: 'Please', cat: 'polite', al: { ar: ['من فضلك', 'لو سمحت', 'رجاء', 'تفضل'], en: ['please', 'pls'] },
    frames: [{ d: 400, R: { x: 168, y: 306, a: 80, h: HS.flat }, f: F.happy }, ...circle(160, 306, 10, 80, HS.flat, 2, F.happy)] },
  sorry: { ar: 'آسف', en: 'Sorry', cat: 'polite', al: { ar: ['اسف', 'آسف', 'عذرا', 'سامحني', 'معذره'], en: ['sorry', 'apologies', 'excuse me'] },
    frames: [{ d: 400, R: { x: 168, y: 300, a: 85, h: HS.fist }, f: F.sad }, ...circle(160, 300, 9, 85, HS.fist, 2, F.sad)] },
  yes: { ar: 'نعم', en: 'Yes', cat: 'basic', al: { ar: ['نعم', 'ايوه', 'اه', 'اجل', 'صح', 'تمام'], en: ['yes', 'yeah', 'yep', 'right', 'correct'] },
    frames: [{ d: 350, R: { x: 106, y: 232, a: 0, h: HS.fist }, f: F.happy }, { d: 220, R: { x: 106, y: 232, a: 45, h: HS.fist }, f: { ...F.happy, hn: 1 } }, { d: 220, R: { x: 106, y: 232, a: 0, h: HS.fist }, f: F.happy },
      { d: 220, R: { x: 106, y: 232, a: 45, h: HS.fist }, f: { ...F.happy, hn: 1 } }, { d: 220, R: { x: 106, y: 232, a: 0, h: HS.fist }, f: F.happy }] },
  no: { ar: 'لا', en: 'No', cat: 'basic', al: { ar: ['لا', 'كلا', 'ابدا', 'مستحيل'], en: ['no', 'nope', 'never'] },
    frames: [{ d: 350, R: { x: 108, y: 238, a: 0, h: HS.point }, f: F.angry }, { d: 200, R: { x: 108, y: 238, a: 28, h: HS.point }, f: { ...F.angry, hx: 1 } }, { d: 200, R: { x: 108, y: 238, a: -28, h: HS.point }, f: { ...F.angry, hx: -1 } },
      { d: 200, R: { x: 108, y: 238, a: 28, h: HS.point }, f: { ...F.angry, hx: 1 } }, { d: 200, R: { x: 108, y: 238, a: 0, h: HS.point }, f: F.angry }] },
  good: { ar: 'جيد', en: 'Good', cat: 'basic', al: { ar: ['جيد', 'ممتاز', 'رائع', 'حلو', 'كويس', 'جميل'], en: ['good', 'great', 'nice', 'awesome', 'excellent', 'cool'] },
    frames: [{ d: 420, R: { x: 106, y: 228, a: 0, h: HS.thumb }, f: F.happy }, { d: 200, R: { x: 106, y: 214, a: 0, h: HS.thumb }, f: F.happy }, { d: 200, R: { x: 106, y: 228, a: 0, h: HS.thumb }, f: F.happy, hold: 250 }] },
  ok: { ar: 'تمام', en: 'OK', cat: 'basic', al: { ar: ['اوكي', 'اوك', 'ماشي'], en: ['ok', 'okay', 'alright'] },
    frames: [{ d: 420, R: { x: 106, y: 222, a: 0, h: HS.ok }, f: F.happy, hold: 700 }] },
  peace: { ar: 'سلام', en: 'Peace', cat: 'greet', al: { ar: ['سلام', 'بيس'], en: ['peace', 'victory'] },
    frames: [{ d: 420, R: { x: 106, y: 210, a: 0, h: HS.peace }, f: F.happy, hold: 800 }] },
  love: { ar: 'أحبك', en: 'Love', cat: 'feel', al: { ar: ['احبك', 'حب', 'بحبك', 'احب'], en: ['love', 'love you', 'i love you'] },
    frames: [{ d: 420, R: { x: 106, y: 216, a: 0, h: HS.love }, f: F.happy }, { d: 300, R: { x: 106, y: 208, a: 0, h: HS.love }, f: F.happy }, { d: 300, R: { x: 106, y: 216, a: 0, h: HS.love }, f: F.happy, hold: 400 }] },
  stop: { ar: 'قف', en: 'Stop', cat: 'basic', al: { ar: ['قف', 'توقف', 'انتظر', 'استنى'], en: ['stop', 'wait', 'halt'] },
    frames: [{ d: 320, R: { x: 108, y: 218, a: 0, h: HS.flat }, f: F.angry, hold: 800 }] },
  come: { ar: 'تعال', en: 'Come', cat: 'action', al: { ar: ['تعال', 'تعالى', 'تعالوا', 'اقترب'], en: ['come', 'come here'] },
    frames: [{ d: 380, R: { x: 98, y: 252, a: -4, h: HS.flat }, f: F.happy }, { d: 220, R: { x: 98, y: 252, a: -4, h: HS.claw }, f: F.happy }, { d: 220, R: { x: 98, y: 252, a: -4, h: HS.flat }, f: F.happy },
      { d: 220, R: { x: 98, y: 252, a: -4, h: HS.claw }, f: F.happy }, { d: 220, R: { x: 98, y: 252, a: -4, h: HS.flat }, f: F.happy }] },
  me: { ar: 'أنا', en: 'Me', cat: 'basic', al: { ar: ['انا', 'نفسي'], en: ['me', 'i', 'myself', 'i am', 'im'] },
    frames: [{ d: 400, R: { x: 138, y: 300, a: 80, h: HS.point }, f: F.neutral, hold: 600 }] },
  clap: { ar: 'تصفيق', en: 'Clap', cat: 'feel', al: { ar: ['تصفيق', 'مبروك', 'برافو', 'احسنت'], en: ['clap', 'congratulations', 'congrats', 'bravo'] },
    frames: [{ d: 350, R: { x: 150, y: 240, a: 15, h: HS.flat }, L: { x: 250, y: 240, a: -15, h: HS.flat }, f: F.happy },
      { d: 140, R: { x: 186, y: 236, a: 5, h: HS.flat }, L: { x: 214, y: 236, a: -5, h: HS.flat }, f: F.happy },
      { d: 160, R: { x: 150, y: 240, a: 15, h: HS.flat }, L: { x: 250, y: 240, a: -15, h: HS.flat }, f: F.happy },
      { d: 140, R: { x: 186, y: 236, a: 5, h: HS.flat }, L: { x: 214, y: 236, a: -5, h: HS.flat }, f: F.happy },
      { d: 160, R: { x: 150, y: 240, a: 15, h: HS.flat }, L: { x: 250, y: 240, a: -15, h: HS.flat }, f: F.happy },
      { d: 140, R: { x: 186, y: 236, a: 5, h: HS.flat }, L: { x: 214, y: 236, a: -5, h: HS.flat }, f: F.happy }] },
  help: { ar: 'ساعدني', en: 'Help', cat: 'action', al: { ar: ['ساعدني', 'مساعده', 'النجده', 'ساعد'], en: ['help', 'help me', 'assist'] },
    frames: [{ d: 420, R: { x: 196, y: 262, a: 0, h: HS.thumb }, L: { x: 226, y: 292, a: -85, h: HS.flat }, f: F.question },
      { d: 420, R: { x: 196, y: 226, a: 0, h: HS.thumb }, L: { x: 226, y: 256, a: -85, h: HS.flat }, f: F.question, hold: 300 }] },
  think: { ar: 'أفكر', en: 'Think', cat: 'action', al: { ar: ['افكر', 'تفكير', 'اظن', 'فكره'], en: ['think', 'thinking', 'idea', 'maybe'] },
    frames: [{ d: 420, R: { x: 150, y: 196, a: 6, h: HS.point }, f: F.think }, { d: 240, R: { x: 150, y: 190, a: 12, h: HS.point }, f: F.think }, { d: 240, R: { x: 150, y: 196, a: 6, h: HS.point }, f: F.think },
      { d: 240, R: { x: 150, y: 190, a: 12, h: HS.point }, f: F.think, hold: 300 }] },
  eat: { ar: 'أكل', en: 'Eat', cat: 'daily', al: { ar: ['اكل', 'آكل', 'طعام', 'جوعان', 'اكله'], en: ['eat', 'food', 'hungry', 'meal'] },
    frames: [{ d: 380, R: { x: 196, y: 262, a: 0, h: HS.pinch }, f: F.happy }, { d: 260, R: { x: 196, y: 244, a: 0, h: HS.pinch }, f: { ...F.happy, mo: 0.3 } },
      { d: 260, R: { x: 196, y: 262, a: 0, h: HS.pinch }, f: F.happy }, { d: 260, R: { x: 196, y: 244, a: 0, h: HS.pinch }, f: { ...F.happy, mo: 0.3 } }] },
  drink: { ar: 'شرب', en: 'Drink', cat: 'daily', al: { ar: ['شرب', 'اشرب', 'ماء', 'عطشان', 'مويه'], en: ['drink', 'water', 'thirsty'] },
    frames: [{ d: 380, R: { x: 178, y: 256, a: 10, h: HS.c }, f: F.neutral }, { d: 420, R: { x: 186, y: 244, a: 50, h: HS.c }, f: { ...F.neutral, mo: 0.25, hx: -0.3 } },
      { d: 300, R: { x: 178, y: 256, a: 10, h: HS.c }, f: F.neutral }] },
  sleep: { ar: 'نوم', en: 'Sleep', cat: 'daily', al: { ar: ['نوم', 'نام', 'نعسان', 'تصبح على خير', 'ارتاح'], en: ['sleep', 'tired', 'sleepy', 'goodnight', 'good night', 'rest'] },
    frames: [{ d: 600, R: { x: 130, y: 232, a: 0, h: HS.flat }, f: { eo: 0.08, hx: -1.6, ms: 0.15, hn: 0.4 }, hold: 900 }] },
  question: { ar: 'سؤال', en: 'Question', cat: 'basic', al: { ar: ['سؤال', 'لماذا', 'كيف', 'ماذا', 'متى', 'اين'], en: ['question', 'why', 'how', 'what', 'when', 'where', 'who'] },
    frames: [{ d: 450, R: { x: 96, y: 300, a: -25, h: HS.open }, L: { x: 304, y: 300, a: 25, h: HS.open }, f: F.question, hold: 700 }] },
};

/* تعابير الوجه فقط */
export const EXPRESSIONS = {
  happy: { ar: 'سعيد', en: 'Happy', al: { ar: ['سعيد', 'فرحان', 'مبسوط', 'فرح'], en: ['happy', 'glad', 'joy', 'smile'] }, frames: [{ d: 450, f: F.happy, hold: 900 }] },
  sad: { ar: 'حزين', en: 'Sad', al: { ar: ['حزين', 'زعلان', 'حزن'], en: ['sad', 'upset', 'unhappy'] }, frames: [{ d: 600, f: F.sad, hold: 1000 }] },
  surprised: { ar: 'متفاجئ', en: 'Surprised', al: { ar: ['متفاجئ', 'مفاجاه', 'واو'], en: ['surprised', 'wow', 'surprise'] }, frames: [{ d: 300, f: F.surprised, hold: 900 }] },
  angry: { ar: 'غاضب', en: 'Angry', al: { ar: ['غاضب', 'عصبي', 'غضب'], en: ['angry', 'mad', 'furious'] }, frames: [{ d: 400, f: F.angry, hold: 900 }] },
  confused: { ar: 'مرتبك', en: 'Confused', al: { ar: ['مرتبك', 'محتار', 'لا افهم'], en: ['confused', 'unsure', 'dont understand'] }, frames: [{ d: 450, f: F.confused, hold: 900 }] },
  asking: { ar: 'استفهام', en: 'Asking', al: { ar: [], en: [] }, frames: [{ d: 400, f: F.question, hold: 700 }] },
};

export const ALL_MOTIONS = { ...GESTURES, ...Object.fromEntries(Object.entries(EXPRESSIONS).map(([k, v]) => ['x_' + k, v])) };

export const CATEGORIES = {
  greet: { ar: 'تحيات', en: 'Greetings' }, polite: { ar: 'لباقة', en: 'Polite' }, basic: { ar: 'أساسيات', en: 'Basics' },
  feel: { ar: 'مشاعر', en: 'Feelings' }, action: { ar: 'أفعال', en: 'Actions' }, daily: { ar: 'يوميات', en: 'Daily' },
};

const norm = (s) => normalizeArabic(String(s).toLowerCase()).replace(/[’']/g, '').trim();

/** فهرس العبارات: يعيد قائمة مرتّبة بالأطول أولاً. */
export function buildAliasIndex(motions = ALL_MOTIONS) {
  const rows = [];
  for (const [id, m] of Object.entries(motions)) {
    for (const lang of ['ar', 'en']) {
      for (const a of m.al?.[lang] || []) {
        const toks = norm(a).split(/\s+/).filter(Boolean);
        if (toks.length) rows.push({ id, toks });
      }
    }
  }
  return rows.sort((x, y) => y.toks.length - x.toks.length);
}

const TOKEN_RE = /[\p{L}\p{N}']+|[?؟!.,،;:]/gu;

/**
 * يحوّل نصاً إلى خطة: عناصر {kind:'g', id, src} للحركات المعروفة و {kind:'t', text} للنص الذي يُهجّى حرفاً حرفاً.
 * علامة الاستفهام في آخر الجملة تضيف تعبير السؤال.
 */
export function planText(text, motions = ALL_MOTIONS, index = buildAliasIndex(motions)) {
  const raw = String(text || '');
  const question = /[?؟]\s*$/.test(raw.trim());
  const toks = (raw.match(TOKEN_RE) || []).filter((t) => /[\p{L}\p{N}]/u.test(t));
  const nt = toks.map(norm);
  const items = [];
  let buf = [];
  const flush = () => { if (buf.length) { items.push({ kind: 't', text: buf.join(' ') }); buf = []; } };
  for (let i = 0; i < toks.length;) {
    let hit = null;
    for (const row of index) {
      const n = row.toks.length;
      if (i + n <= toks.length && row.toks.every((t, j) => t === nt[i + j])) { hit = { row, n }; break; }
    }
    if (hit) { flush(); items.push({ kind: 'g', id: hit.row.id, src: toks.slice(i, i + hit.n).join(' ') }); i += hit.n; }
    else { buf.push(toks[i]); i++; }
  }
  flush();
  if (question) items.push({ kind: 'g', id: 'x_asking', src: '؟' });
  return { items, question };
}

export function motionLabel(id, lang) {
  const m = ALL_MOTIONS[id];
  return m ? m[lang === 'en' ? 'en' : 'ar'] : id;
}
