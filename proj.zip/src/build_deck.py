#!/usr/bin/env python3
import re, pathlib, html, sys
R = pathlib.Path(__file__).parent
sys.path.insert(0, str(R / 'deck'))
from slides_data import S, PH
def strip(s):
    s = re.sub(r'^import\s[\s\S]*?from\s+[\'"].*?[\'"];?[ \t]*$', '', s, flags=re.M)
    s = re.sub(r'^export\s*\{[\s\S]*?\};?[ \t]*$', '', s, flags=re.M)
    return re.sub(r'^export\s+(default\s+)?', '', s, flags=re.M)
MK = re.compile(r'\[\[((?:(?!\]\]).)*?)\|((?:(?!\]\]).)*?)\]\]', re.S)
def bi(s): return MK.sub(r'<span class="ar">\1</span><span class="en">\2</span>', s)
def pair(t): return f'<span class="ar">{html.escape(t[0])}</span><span class="en">{html.escape(t[1])}</span>'
secs = []
for i, s in enumerate(S, 1):
    h2 = f'<h2>{pair(s["title"])}</h2>' if s['title'] else ''
    notes = f'<aside class="notes"><b>#{i}</b> {pair(s["notes"])}</aside>'
    secs.append(f'<section class="slide" data-tag="{html.escape(bi(s["tag"]), quote=True)}">{h2}{s["body"]}{notes}</section>')
mods = '\n'.join(strip((R / m).read_text(encoding='utf-8')) for m in ['core.js', 'signs.js', 'avatar.js', 'gestures.js'])
tpl = (R / 'deck/deck.tpl.html').read_text(encoding='utf-8')
out = tpl.replace('/*SLIDES*/', bi('\n'.join(secs))).replace('/*MODULES*/', mods)
(R / 'dist').mkdir(exist_ok=True)
(R / 'dist/slides.html').write_text(out, encoding='utf-8')
# ملف الشرح للمتحدث + قائمة الصور
rows, photos = [], []
for i, s in enumerate(S, 1):
    t = s['title'] or ('ربط الذكاء الاصطناعي بحالات الأصم', 'Linking AI to deaf use cases')
    rows.append(f'<section><h2><span class="n">{i}</span> <span class="ar">{html.escape(t[0])}</span><span class="en">{html.escape(t[1])}</span></h2><div class="ar"><h4>ماذا أقول</h4><p>{html.escape(s["notes"][0])}</p></div><div class="en"><h4>What to say</h4><p>{html.escape(s["notes"][1])}</p></div></section>')
    for pid, q in re.findall(r'data-p="(p\d+)".*?<em>[^<]*</span>: ([^<]*)</em>', s['body'] + '', re.S) or []:
        photos.append((i, pid, q))
for m in re.finditer(r'data-p="(p\d+)"', ''.join(x['body'] for x in S)): pass
phot = [(0, p, q) for p, q in PH]
prow = ''.join(f'<tr><td>·</td><td><code>photos/{p}.jpg</code></td><td>{html.escape(q)}</td></tr>' for i, p, q in phot)
notes_html = f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ملف الشرح · Speaker script</title>
<style>:root{{--bg:#17191c;--ink:#eef4f3;--tq:#14b8a6;--gold:#e0b34a;--mut:#9fb3b0}}body{{margin:0;background:var(--bg);color:var(--ink);font:18px/1.8 "IBM Plex Sans Arabic",Inter,system-ui,sans-serif;padding:30px 20px}}main{{max-width:900px;margin:auto}}
h1{{font-size:30px;margin:0 0 4px}}h1+p{{color:var(--mut);margin:0 0 20px}}section{{border:1px solid rgba(20,184,166,.3);border-radius:16px;padding:14px 20px;margin:12px 0;background:rgba(255,255,255,.04);break-inside:avoid}}
h2{{font-size:21px;margin:0 0 6px;color:var(--tq)}}.n{{display:inline-block;background:var(--gold);color:#2b2000;border-radius:8px;padding:0 10px;margin-inline-end:6px}}h4{{margin:6px 0 0;color:var(--gold);font-size:15px}}p{{margin:2px 0}}
.bar{{position:sticky;top:0;background:var(--bg);padding:8px 0;display:flex;gap:8px}}button{{border:0;background:var(--tq);color:#04201d;font:600 15px inherit;border-radius:999px;padding:6px 16px;cursor:pointer}}
html[lang=en] .ar,html[lang=ar] .en{{display:none}}table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid rgba(255,255,255,.12);padding:6px 8px;text-align:start}}code{{direction:ltr;unicode-bidi:isolate;background:rgba(20,184,166,.16);padding:1px 6px;border-radius:6px}}
@media print{{body{{background:#fff;color:#000}}.bar{{display:none}}section{{border-color:#999;background:#fff}}h2{{color:#0a6f66}}}}</style></head><body><main>
<div class="bar"><button onclick="var h=document.documentElement;h.lang=h.lang=='ar'?'en':'ar';h.dir=h.lang=='ar'?'rtl':'ltr'">AR / EN</button><button onclick="print()">🖨</button></div>
<h1><span class="ar">ملف الشرح: ماذا أقول في كل سلايد</span><span class="en">Speaker script: what to say on each slide</span></h1><p><span class="ar">اقرأه بجانب العرض، أو اضغط N داخل العرض لتظهر الملاحظات على الشاشة.</span><span class="en">Read it next to the deck, or press N inside the deck to show notes on screen.</span></p>
{''.join(rows)}
<section><h2><span class="ar">اختياري: استبدل الرسوم بصور حقيقية</span><span class="en">Optional: replace the illustrations with real photos</span></h2><p><span class="ar">الرسوم التوضيحية داخل العرض صنعها الذكاء الاصطناعي. إن أردت صوراً حقيقية، ضع الصورة في مجلد photos بالاسم المذكور، أو اسحبها فوق مكان الصورة داخل العرض. استخدم صوراً بترخيص مجاني (مثل Unsplash أو Pexels أو Wikimedia Commons) واكتب المصدر تحت الصورة.</span><span class="en">The illustrations in the deck were made by AI. If you want real photos, put each photo in the photos folder with the name shown, or drag it onto the photo slot in the deck. Use freely-licensed photos (e.g. Unsplash, Pexels, Wikimedia Commons) and write the credit under the photo.</span></p>
<table><tr><th>#</th><th>file</th><th>search</th></tr>{prow}</table></section></main></body></html>'''
(R / 'dist/speaker-notes.html').write_text(notes_html, encoding='utf-8')
print('deck', len(S), 'slides;', len(phot), 'photo slots')
