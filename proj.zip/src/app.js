import { VEC_LEN, normalizeLandmarks, Smoother, Committer, splitData, augment, mulberry32, confusionMatrix, cleanLabel, samplesToCSV, samplesFromCSV, fingerStates, textToWords, scriptOf, suggestWords, ARABIC_LETTERS, ENGLISH_LETTERS } from './core.js';
import { AR_WORDS, EN_WORDS } from './dict.js';
import { mergeLibrary, defaultLibrary, matchLibrary, poseToPoints, vecToPoints, handSVG } from './signs.js';

/* IN_ARTIFACT تُعرَّف في ملف البناء: true عند عرض الصفحة داخل Claude (بدون كاميرا). */

const MP_VER = '0.10.14';
const MP_BASE = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MP_VER}`;
const HAND_MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

const KEY_SAMPLES = 'sign.samples.v1';
const KEY_LABELS = 'sign.labels.v1';
const KEY_LIB = 'sign.lib.v2';
const KEY_LIB_OLD = 'sign.lib.v1';
const KEY_PREFS = 'sign.prefs.v1';
const KEY_AI = 'sign.aikey.v1';
const MODEL_STORE = 'indexeddb://sign-model';
const TABS = ['write', 'translate', 'library', 'play', 'train', 'steps', 'ai'];
const CAM_TABS = ['translate', 'train'];

const HAND_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17],
];

const LETTERS = { ar: ARABIC_LETTERS, en: ENGLISH_LETTERS };
const FINGER_AR = ['السبابة', 'الوسطى', 'البنصر', 'الخنصر'];
const PHRASES = {
  ar: ['مرحبا', 'شكرا', 'نعم', 'لا', 'ساعدني', 'أين الحمام', 'أحتاج طبيبا', 'أنا أصم', 'من فضلك أعد ببطء'],
  en: ['Hello', 'Thank you', 'Yes', 'No', 'Help me', 'Where is the toilet', 'I need a doctor', 'I am deaf', 'Please repeat slowly'],
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const el = new Proxy({}, {
  get(target, key) {
    if (!(key in target)) target[key] = document.getElementById(String(key));
    return target[key];
  },
});

const state = {
  tab: 'write',
  set: 'ar', // لغة الهجاء المستخدمة في التعرّف
  libSet: 'ar',
  wizSet: 'ar',
  wizSelected: new Set(ARABIC_LETTERS),
  wiz: { on: false, list: [], idx: 0, per: 40 },
  landmarker: null,
  cameraOn: false,
  lastVideoTime: -1,
  lastHandAt: 0,
  samples: [],
  model: null,
  labels: [],
  recording: null,
  counting: false,
  countTimer: 0,
  training: false,
  words: [],
  cur: '',
  history: { loss: [], acc: [], valAcc: [] },
  libOverrides: { ar: {}, en: {} },
  libs: { ar: defaultLibrary('ar'), en: defaultLibrary('en') },
  editLetter: { ar: 'ا', en: 'A' },
  seq: [],
  idx: 0,
  playTimer: 0,
  playing: false,
  sample: null,
  aiAbort: null,
  aiText: '',
};
const prefs = { theme: 'noir', fs: 100, contrast: false, motion: false, flash: false, role: null, lang: 'ar', view: 'avatar', preset: 'nour', mirror: false };

const smoother = new Smoother(8, 0.6, 0.7);
const committer = new Committer(15);

/* ---------- أدوات صغيرة ---------- */

let toastTimer = 0;
function toast(msg) {
  el.toast.textContent = msg;
  el.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.toast.hidden = true; }, 3400);
}
function setStatus(msg, bad = false) {
  el.status.textContent = msg;
  el.status.classList.toggle('bad', bad);
}
function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}
function download(filename, blobParts, type) {
  const url = URL.createObjectURL(new Blob(blobParts, { type }));
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function store(key, value) { try { localStorage.setItem(key, value); return true; } catch { return false; } }
function load(key) { try { return localStorage.getItem(key); } catch { return null; } }

function visualAlert() {
  if (!prefs.flash) return;
  const f = el.flash;
  f.classList.remove('on');
  void f.offsetWidth;
  f.classList.add('on');
  setTimeout(() => f.classList.remove('on'), 950);
}

function bindSeg(root, onChange) {
  const buttons = [...root.querySelectorAll('button')];
  buttons.forEach((b) => b.addEventListener('click', () => {
    buttons.forEach((x) => x.setAttribute('aria-checked', String(x === b)));
    onChange(b.dataset.set);
  }));
  return (value) => buttons.forEach((x) => x.setAttribute('aria-checked', String(x.dataset.set === value)));
}

/* ---------- الإعدادات والإتاحة ---------- */

const THEME_AR = { noir: 'فحمي', calm: 'هادئ', light: 'فاتح', dark: 'داكن', auto: 'تلقائي' };
const ROLE_AR = { deaf: 'أصم أو ضعيف سمع', hearing: 'سامع', learner: 'متعلّم' };

function applyPrefs() {
  const r = document.documentElement;
  prefs.theme = 'noir'; /* مظهر واحد موحّد مع السلايدات: 60% فحمي، 30% تركواز، 10% ذهبي */
  if (prefs.theme === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', prefs.theme);
  r.style.fontSize = `${prefs.fs}%`;
  if (prefs.contrast) r.setAttribute('data-contrast', 'high'); else r.removeAttribute('data-contrast');
  if (prefs.motion) r.setAttribute('data-motion', 'reduce'); else r.removeAttribute('data-motion');
  el.themeLabel.textContent = T(THEME_AR[prefs.theme] || THEME_AR.noir);
  el.fsRange.value = String(prefs.fs);
  el.fsOut.textContent = `${prefs.fs}%`;
  el.contrastChk.checked = prefs.contrast;
  el.motionChk.checked = prefs.motion;
  el.flashChk.checked = prefs.flash;
  el.roleLabel.textContent = prefs.role ? T(ROLE_AR[prefs.role]) : T('غير محدد');
  el.mirrorChk.checked = !!prefs.mirror;
  if (state.tab === 'train') drawChart();
}
function loadPrefs() {
  try { Object.assign(prefs, JSON.parse(load(KEY_PREFS) || '{}')); } catch { /* تجاهل */ }
}
function savePrefs() { store(KEY_PREFS, JSON.stringify(prefs)); applyPrefs(); }

el.themeBtn.addEventListener('click', () => {
  const order = ['noir', 'calm', 'light', 'dark', 'auto'];
  prefs.theme = order[(order.indexOf(prefs.theme) + 1) % order.length];
  savePrefs();
});
el.a11yBtn.addEventListener('click', () => {
  const open = el.a11yMenu.hidden;
  el.a11yMenu.hidden = !open;
  el.a11yBtn.setAttribute('aria-expanded', String(open));
});
document.addEventListener('click', (e) => {
  if (el.a11yMenu.hidden) return;
  if (e.target.closest('#a11yMenu') || e.target.closest('#a11yBtn')) return;
  el.a11yMenu.hidden = true;
  el.a11yBtn.setAttribute('aria-expanded', 'false');
});
el.fsRange.addEventListener('input', () => { prefs.fs = Number(el.fsRange.value); savePrefs(); });
el.contrastChk.addEventListener('change', () => { prefs.contrast = el.contrastChk.checked; savePrefs(); });
el.motionChk.addEventListener('change', () => { prefs.motion = el.motionChk.checked; savePrefs(); });
el.flashChk.addEventListener('change', () => { prefs.flash = el.flashChk.checked; savePrefs(); if (prefs.flash) visualAlert(); });

/* ---------- الترحيب والمساعدة ---------- */

const ROLE_GUIDE = {
  deaf: [
    'افتح «إشارات إلى نص»، شغّل الكاميرا، وأشِر بحروف الهجاء داخل الإطار. يكتب الموقع حروفك وينطق الكلمات للطرف الآخر.',
    'عندما يكتب لك الشخص الآخر، افتح «كتابة إلى إشارات». زر «شاشة العرض» يعرض الحرف بحجم كبير.',
    'من «درّب النظام» سجّل إشاراتك أنت ليتعرّف عليها الموقع بدقة أعلى.',
    'فعّلنا لك «التنبيه البصري» ليومض الموقع عند كل حرف جديد، ويمكنك إيقافه من «إتاحة».',
  ],
  hearing: [
    'اكتب جملتك أو اختر عبارة جاهزة في «كتابة إلى إشارات»، ثم اضغط «تشغيل» وسلّم الشاشة للشخص الأصم.',
    'لتكون الجملة أسهل في القراءة، بسّطها من تبويب «الذكاء الاصطناعي» قبل العرض.',
    'في «إشارات إلى نص» ترى كلام الطرف الآخر مكتوباً ومنطوقاً بالعربية أو الإنجليزية.',
    'بدّل بين العربية والإنجليزية من أزرار اللغة في كل قسم.',
  ],
  learner: [
    'تصفّح «مكتبة الإشارات» لترى شكل كل حرف، وعدّل الأصابع إن أردت.',
    'جرّب «إشارات إلى نص» لترى هل يتعرّف الموقع على إشارتك أمام الكاميرا.',
    'سجّل شكل يدك الصحيح من «درّب النظام» ليرسمه الموقع لك في المكتبة.',
  ],
};
let pendingRole = null;

function openDialog(d) { if (typeof d.showModal === 'function') { try { d.showModal(); } catch { d.setAttribute('open', ''); } } else d.setAttribute('open', ''); }
function closeDialog(d) { if (typeof d.close === 'function') d.close(); else d.removeAttribute('open'); }

function showWelcome() {
  pendingRole = null;
  el.welStart.disabled = true;
  el.welSteps.hidden = true;
  $$('.role').forEach((b) => b.setAttribute('aria-pressed', 'false'));
  openDialog(el.welcome);
}
$$('.role').forEach((b) => b.addEventListener('click', () => {
  pendingRole = b.dataset.role;
  $$('.role').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
  el.welSteps.textContent = '';
  for (const s of ROLE_GUIDE[pendingRole]) {
    const li = document.createElement('li');
    li.textContent = T(s);
    el.welSteps.appendChild(li);
  }
  el.welSteps.hidden = false;
  el.welStart.disabled = false;
}));
el.welStart.addEventListener('click', () => {
  if (!pendingRole) return;
  prefs.role = pendingRole;
  if (pendingRole === 'deaf') { prefs.flash = true; prefs.fs = Math.max(prefs.fs, 110); }
  savePrefs();
  closeDialog(el.welcome);
  const first = pendingRole === 'deaf' ? (IN_ARTIFACT ? 'write' : 'translate') : pendingRole === 'learner' ? 'library' : 'write';
  setTab(first);
});
el.welSkip.addEventListener('click', () => { if (!prefs.role) { prefs.role = 'hearing'; } savePrefs(); closeDialog(el.welcome); });
el.roleBtn.addEventListener('click', () => { el.a11yMenu.hidden = true; showWelcome(); });
el.helpBtn.addEventListener('click', () => openDialog(el.helpDlg));
el.helpClose.addEventListener('click', () => closeDialog(el.helpDlg));

/* ---------- التخزين ---------- */

function loadSamples() {
  const t = load(KEY_SAMPLES);
  if (t) state.samples = samplesFromCSV(t);
}
function persistSamples() {
  if (!store(KEY_SAMPLES, samplesToCSV(state.samples))) toast(T('تعذّر الحفظ في المتصفح. صدّر العينات كملف CSV كي لا تضيع.'));
}
function countByLabel() {
  const m = new Map();
  for (const s of state.samples) m.set(s.label, (m.get(s.label) || 0) + 1);
  return m;
}
function rebuildLibs() {
  state.libs = { ar: mergeLibrary(state.libOverrides.ar, 'ar'), en: mergeLibrary(state.libOverrides.en, 'en') };
}
function loadLibrary() {
  try {
    const v2 = load(KEY_LIB);
    if (v2) {
      const o = JSON.parse(v2) || {};
      state.libOverrides = { ar: o.ar || {}, en: o.en || {} };
    } else {
      const v1 = load(KEY_LIB_OLD);
      if (v1) state.libOverrides = { ar: JSON.parse(v1) || {}, en: {} };
    }
  } catch { state.libOverrides = { ar: {}, en: {} }; }
  rebuildLibs();
}
function persistLibrary() {
  rebuildLibs();
  store(KEY_LIB, JSON.stringify(state.libOverrides));
}

/* ---------- التبويبات ---------- */

function setTab(name) {
  if (!TABS.includes(name)) name = 'write';
  state.tab = name;
  $$('.tab').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === name)));
  $$('.panel').forEach((p) => { p.hidden = p.id !== `panel-${name}`; });
  const cam = CAM_TABS.includes(name);
  el.layout.dataset.view = cam ? 'cam' : 'wide';
  if (name !== 'translate') el.wordOverlay.hidden = true;
  if (name !== 'write') { stopPlay(); setFocus(false); }
  if (name !== 'play' && game.av) { game.av.stop(); }
  smoother.reset();
  if (name === 'train') { drawChart(); renderWizChips(); renderSamples(); }
  if (name === 'library') { renderLibrary(); if (state.libMode === 'gestures') renderGestures(); }
  if (name === 'write') renderWords();
  if (name === 'translate') { renderSentence(); updateModelBadge(); }
  if (name === 'ai') refreshAIUI();
  try { history.replaceState(null, '', `#${name}`); } catch { /* تجاهل */ }
}
$$('.tab').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));
$$('[data-goto]').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.goto)));

/* ---------- رسم الإشارات ---------- */

function meanVec(label) {
  let n = 0;
  const sum = new Array(VEC_LEN).fill(0);
  for (const s of state.samples) {
    if (s.label !== label) continue;
    n += 1;
    for (let i = 0; i < VEC_LEN; i++) sum[i] += s.vec[i];
  }
  return n ? sum.map((v) => v / n) : null;
}
/** يرجع {svg, source} حيث source: rec (من تسجيلك) أو custom أو default. */
function signFor(letter, set) {
  const rec = meanVec(letter);
  if (rec) return { svg: handSVG(vecToPoints(rec), letter), source: 'rec', vec: rec, entry: (state.libs[set] || {})[letter] };
  const entry = state.libs[set] && state.libs[set][letter];
  if (!entry) return null;
  return { svg: handSVG(poseToPoints(entry), letter), source: entry.custom ? 'custom' : 'default', entry };
}
const SOURCE_AR = { rec: 'من تسجيلك', custom: 'معدَّل', default: 'افتراضي' };

/* ---------- كتابة إلى إشارات ---------- */

function renderPhrases() {
  el.phrases.textContent = '';
  for (const lang of ['ar', 'en']) {
    for (const p of PHRASES[lang]) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'chip'; b.textContent = p;
      if (lang === 'en') b.dir = 'ltr';
      b.addEventListener('click', () => { el.textInput.value = p; stopPlay(); state.idx = 0; renderWords(); });
      el.phrases.appendChild(b);
    }
  }
}

function renderWords() {
  const plan = planText(el.textInput.value);
  state.seq = [];
  el.wordsOut.textContent = '';
  el.planInfo.textContent = '';
  if (!plan.items.length) {
    const p = document.createElement('p');
    p.className = 'placeholder';
    p.textContent = T('اكتب نصاً لتظهر إشاراته هنا.');
    el.wordsOut.appendChild(p);
    showBig(0, false);
    return;
  }
  let wi = 0;
  let nG = 0;
  for (const it of plan.items) {
    if (it.kind === 'g') {
      const box = document.createElement('div');
      box.className = 'word';
      const card = document.createElement('div');
      card.className = 'sign-card gesture-card';
      const lab = document.createElement('span');
      lab.className = 'gesture-label';
      lab.textContent = motionLabel(it.id, getLang());
      card.appendChild(lab);
      box.appendChild(card);
      el.wordsOut.appendChild(box);
      state.seq.push({ kind: 'g', card, id: it.id, wi: wi++ });
      nG += 1;
      continue;
    }
    for (const w of textToWords(it.text)) {
      const box = document.createElement('div');
      box.className = 'word';
      if (w[0] && w[0].set === 'en') box.dir = 'ltr';
      for (const c of w) {
        const card = document.createElement('div');
        card.className = 'sign-card';
        const sign = c.sign ? signFor(c.ch, c.set) : null;
        if (sign) {
          card.innerHTML = sign.svg;
          const l = document.createElement('span');
          l.className = 'sign-letter';
          l.textContent = c.ch;
          card.appendChild(l);
          state.seq.push({ kind: 'l', card, ch: c.ch, set: c.set, wi, svg: sign.svg, entry: sign.entry, vec: sign.entry ? null : sign.vec });
        } else {
          card.classList.add('plain');
          card.textContent = c.ch;
          card.title = T('ليس له إشارة هجاء');
        }
        box.appendChild(card);
      }
      el.wordsOut.appendChild(box);
      wi += 1;
    }
  }
  if (nG) el.planInfo.textContent = T('تعرّفتُ على {0} من مكتبة الحركات، والباقي سيُهجّى حرفاً حرفاً.', nG);
  if (state.idx >= state.seq.length) state.idx = 0;
  if (!state.playing) showBig(state.idx, false);
}
el.textInput.addEventListener('input', () => { stopPlay(); state.idx = 0; renderWords(); });
el.playBtn.addEventListener('click', () => { if (state.playing) stopPlay(); else startPlay(); });
el.prevBtn.addEventListener('click', () => { if (state.seq.length) playOne((state.idx - 1 + state.seq.length) % state.seq.length); });
el.nextBtn.addEventListener('click', () => { if (state.seq.length) playOne((state.idx + 1) % state.seq.length); });
el.focusBtn.addEventListener('click', () => setFocus(!el.bigStage.classList.contains('focus')));
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && el.bigStage.classList.contains('focus')) setFocus(false); });
el.speedRange.addEventListener('input', () => { el.speedOut.textContent = T('{0} ثانية', (Number(el.speedRange.value) / 10).toFixed(1)); });
const setViewSeg = bindSeg(el.viewSeg, (v) => { setView(v); savePrefs(); });
const setPresetSeg = bindSeg(el.presetSeg, (v) => { prefs.preset = v; savePrefs(); ensureAvatar().setPreset(v); });
el.mirrorChk.addEventListener('change', () => { prefs.mirror = el.mirrorChk.checked; savePrefs(); ensureAvatar().setMirror(prefs.mirror); });
el.avatarBox.addEventListener('click', avatarEasterEgg);
const setLibModeSeg = bindSeg(el.libMode, (m) => setLibMode(m));

/* ---------- مكتبة الإشارات ---------- */

const setLibSeg = bindSeg(el.libSet, (s) => { state.libSet = s; renderLibrary(); });

function renderLibrary() {
  const set = state.libSet;
  setLibSeg(set);
  el.libGrid.textContent = '';
  for (const ch of LETTERS[set]) {
    const s = signFor(ch, set);
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'sign-card pick' + (ch === state.editLetter[set] ? ' active' : '');
    b.setAttribute('aria-label', T('تعديل إشارة حرف {0}', ch));
    b.innerHTML = s.svg;
    const l = document.createElement('span');
    l.className = 'sign-letter';
    l.textContent = ch;
    b.appendChild(l);
    if (s.source !== 'default') {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = T(SOURCE_AR[s.source]);
      b.appendChild(tag);
    }
    b.addEventListener('click', () => { state.editLetter[set] = ch; renderLibrary(); });
    el.libGrid.appendChild(b);
  }
  renderEditor();
}

function makeSelect(id, options, value, onChange) {
  const sel = document.createElement('select');
  sel.id = id;
  for (const [v, text] of options) {
    const o = document.createElement('option');
    o.value = v; o.textContent = text;
    if (v === value) o.selected = true;
    sel.appendChild(o);
  }
  sel.addEventListener('change', () => onChange(sel.value));
  return sel;
}
function fieldWrap(labelText, id, control) {
  const d = document.createElement('div');
  d.className = 'field';
  const l = document.createElement('label');
  l.htmlFor = id; l.textContent = labelText;
  d.append(l, control);
  return d;
}

function renderEditor() {
  const set = state.libSet;
  const ch = state.editLetter[set];
  const entry = state.libs[set][ch];
  const root = el.libEditor;
  root.textContent = '';
  if (!entry) return;
  const rec = meanVec(ch);

  const head = document.createElement('div');
  head.className = 'editor-head';
  const prev = document.createElement('div');
  prev.className = 'editor-preview';
  prev.innerHTML = signFor(ch, set).svg;
  const title = document.createElement('div');
  const h = document.createElement('h2');
  h.textContent = T('حرف {0}', ch);
  const sub = document.createElement('p');
  sub.className = 'muted small';
  sub.textContent = rec
    ? T('الرسم الحالي مأخوذ من تسجيلك. احذف عيّنات هذا الحرف من «درّب النظام» ليعود الرسم المعدَّل.')
    : T('عدّل الأصابع بالأسفل ويتحدّث الرسم فوراً.');
  title.append(h, sub);
  head.append(prev, title);
  root.appendChild(head);

  const update = (patch) => {
    const cur = state.libOverrides[set][ch] || { t: entry.t, f: [...entry.f], rot: entry.rot };
    state.libOverrides[set][ch] = { t: cur.t, f: [...cur.f], rot: cur.rot, ...patch };
    persistLibrary();
    renderLibrary();
  };

  const grid = document.createElement('div');
  grid.className = 'editor-fields';
  grid.appendChild(fieldWrap(T('الإبهام'), 'ed-thumb', makeSelect('ed-thumb',
    [['out', T('مفتوح بعيداً عن الكف')], ['in', T('مطوي على الكف')]], entry.t, (v) => update({ t: v }))));
  FINGER_AR.forEach((name, i) => {
    grid.appendChild(fieldWrap(T(name), `ed-f${i}`, makeSelect(`ed-f${i}`,
      [['E', T('ممدود')], ['H', T('منحنٍ قليلاً')], ['C', T('مطوي')]], entry.f[i], (v) => {
        const f = [...entry.f]; f[i] = v; update({ f });
      })));
  });
  const rot = document.createElement('input');
  rot.type = 'range'; rot.id = 'ed-rot'; rot.min = '-90'; rot.max = '90'; rot.step = '5'; rot.value = String(entry.rot || 0);
  rot.addEventListener('change', () => update({ rot: Number(rot.value) }));
  grid.appendChild(fieldWrap(T('ميلان اليد (للرسم فقط)'), 'ed-rot', rot));
  root.appendChild(grid);

  const row = document.createElement('div');
  row.className = 'row wrap';
  const reset = document.createElement('button');
  reset.type = 'button'; reset.className = 'btn'; reset.textContent = T('إعادة هذا الحرف للافتراضي');
  reset.addEventListener('click', () => { delete state.libOverrides[set][ch]; persistLibrary(); renderLibrary(); });
  row.appendChild(reset);
  root.appendChild(row);
}

el.libExportBtn.addEventListener('click', () => {
  download('sign-library.json', [JSON.stringify(state.libOverrides, null, 2)], 'application/json');
});
el.libImportBtn.addEventListener('click', () => el.libImportFile.click());
el.libImportFile.addEventListener('change', async () => {
  const f = el.libImportFile.files[0];
  el.libImportFile.value = '';
  if (!f) return;
  try {
    const obj = JSON.parse(await f.text());
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('bad');
    state.libOverrides = ('ar' in obj || 'en' in obj) ? { ar: obj.ar || {}, en: obj.en || {} } : { ar: obj, en: {} };
    persistLibrary();
    renderLibrary();
    toast(T('تم استيراد المكتبة.'));
  } catch { toast(T('الملف ليس مكتبة إشارات صالحة.')); }
});
el.libResetBtn.addEventListener('click', () => {
  if (el.libResetBtn.dataset.armed !== '1') {
    el.libResetBtn.dataset.armed = '1';
    el.libResetBtn.textContent = T('اضغط مرة ثانية للتأكيد');
    setTimeout(() => { el.libResetBtn.dataset.armed = ''; el.libResetBtn.textContent = T('إعادة المجموعة للافتراضي'); }, 3000);
    return;
  }
  el.libResetBtn.dataset.armed = '';
  el.libResetBtn.textContent = T('إعادة المجموعة للافتراضي');
  state.libOverrides[state.libSet] = {};
  persistLibrary();
  renderLibrary();
});

/* ---------- الكاميرا وتتبع اليد ---------- */

async function loadHandModel() {
  setStatus(T('جارٍ تحميل نموذج تتبع اليد...'));
  const vision = await import(`${MP_BASE}/vision_bundle.mjs`);
  const fileset = await vision.FilesetResolver.forVisionTasks(`${MP_BASE}/wasm`);
  const make = (delegate) => vision.HandLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: HAND_MODEL_URL, delegate },
    runningMode: 'VIDEO',
    numHands: 1,
  });
  try { return await make('GPU'); } catch { return await make('CPU'); }
}

async function startCamera() {
  el.startBtn.disabled = true;
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw Object.assign(new Error('no media'), { name: 'NoMedia' });
    if (!state.landmarker) state.landmarker = await loadHandModel();
    setStatus(T('جارٍ فتح الكاميرا...'));
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' }, audio: false,
    });
    el.video.srcObject = stream;
    await el.video.play();
    el.overlay.width = el.video.videoWidth;
    el.overlay.height = el.video.videoHeight;
    el.idle.hidden = true;
    state.cameraOn = true;
    setStatus(T('الكاميرا شغّالة. ضع يدك أمامها.'));
    requestAnimationFrame(loop);
  } catch (err) {
    console.error(err);
    el.startBtn.disabled = false;
    const denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
    const noCam = err && (err.name === 'NotFoundError' || err.name === 'NoMedia');
    setStatus(
      denied
        ? T('لم يُسمح بالكاميرا. اسمح بها من شريط العنوان أو من إعدادات الموقع، ثم اضغط تشغيل مرة ثانية.')
        : noCam
          ? T('لا توجد كاميرا متاحة، أو أن المتصفح لا يسمح بها هنا. جرّب Chrome أو Edge.')
          : T('تعذّر التشغيل. تأكد من الاتصال بالإنترنت (لتحميل نموذج اليد) ثم أعد المحاولة.'),
      true,
    );
  }
}
el.startBtn.addEventListener('click', startCamera);

function drawHand(lm) {
  const c = el.overlay;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  if (!lm) return;
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#5eead4';
  ctx.fillStyle = '#ffffff';
  for (const [a, b] of HAND_CONNECTIONS) {
    ctx.beginPath();
    ctx.moveTo(lm[a].x * c.width, lm[a].y * c.height);
    ctx.lineTo(lm[b].x * c.width, lm[b].y * c.height);
    ctx.stroke();
  }
  for (const p of lm) {
    ctx.beginPath();
    ctx.arc(p.x * c.width, p.y * c.height, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}

function loop() {
  if (!state.cameraOn) return;
  const v = el.video;
  const active = CAM_TABS.includes(state.tab);
  if (active && v.currentTime !== state.lastVideoTime && v.readyState >= 2) {
    state.lastVideoTime = v.currentTime;
    let lm = null;
    let hand = 'Right';
    try {
      const res = state.landmarker.detectForVideo(v, performance.now());
      if (res.landmarks && res.landmarks.length) {
        lm = res.landmarks[0];
        const h = res.handedness && res.handedness[0] && res.handedness[0][0];
        if (h) hand = h.categoryName;
      }
    } catch (e) { console.error(e); }
    drawHand(lm);
    const vec = lm ? normalizeLandmarks(lm, hand) : null;
    if (state.tab === 'translate') onTranslateFrame(vec);
    else onRecordFrame(vec);
  }
  requestAnimationFrame(loop);
}

/* ---------- إشارات إلى نص ---------- */

const setTSeg = bindSeg(el.tSet, (s) => { state.set = s; smoother.reset(); updateModelBadge(); });

function inSet(label, set) {
  if ([...label].length !== 1) return true; // إشارات الكلمات المدرَّبة تصلح لكل اللغات
  return set === 'ar' ? ARABIC_LETTERS.includes(label) : ENGLISH_LETTERS.includes(label);
}

function classify(vec) {
  if (state.model && typeof tf !== 'undefined') {
    const probs = tf.tidy(() => Array.from(state.model.predict(tf.tensor2d([vec])).dataSync()));
    let ids = state.labels.map((l, i) => i).filter((i) => inSet(state.labels[i], state.set));
    if (!ids.length) ids = state.labels.map((l, i) => i);
    const total = ids.reduce((a, i) => a + probs[i], 0) || 1;
    let best = ids[0];
    for (const i of ids) if (probs[i] > probs[best]) best = i;
    return { label: state.labels[best], conf: probs[best] / total };
  }
  return matchLibrary(fingerStates(vec), state.libs[state.set]);
}

function onTranslateFrame(vec) {
  const now = performance.now();
  if (vec) {
    state.lastHandAt = now;
    const r = classify(vec);
    smoother.push(r.label, r.conf);
  } else {
    smoother.push(null, 0);
    if (state.cur && now - state.lastHandAt > 2500) flushWord();
  }
  const s = smoother.get();
  const word = s ? s.label : null;
  el.nowWord.textContent = word || '—';
  const pct = s ? Math.round(s.conf * 100) : 0;
  el.nowConf.style.width = `${pct}%`;
  el.nowConfText.textContent = T('الثقة {0}%', pct);
  if (word) { el.wordOverlay.textContent = word; el.wordOverlay.hidden = false; }
  else { el.wordOverlay.hidden = true; }

  const committed = committer.update(word);
  if (committed) addSign(committed);
}

function sentenceText() { return [...state.words, state.cur].filter(Boolean).join(' '); }

function renderSentence() {
  el.sentence.textContent = '';
  if (!state.words.length && !state.cur) {
    const p = document.createElement('span');
    p.className = 'placeholder';
    p.textContent = T('ستظهر الكلمات هنا عند ثبات الإشارة.');
    el.sentence.appendChild(p);
  } else {
    for (const w of state.words) {
      const s = document.createElement('span');
      s.className = 'w'; s.textContent = w;
      if (scriptOf(w) === 'en') s.dir = 'ltr';
      el.sentence.appendChild(s);
    }
    if (state.cur) {
      const s = document.createElement('span');
      s.className = 'w cur'; s.textContent = state.cur;
      if (scriptOf(state.cur) === 'en') s.dir = 'ltr';
      el.sentence.appendChild(s);
    }
  }
  renderSuggest();
}

function speak(text) {
  if (!text || !('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  u.lang = scriptOf(text) === 'en' ? 'en-US' : 'ar-SA';
  const want = u.lang.slice(0, 2);
  const voice = speechSynthesis.getVoices().find((x) => x.lang && x.lang.toLowerCase().startsWith(want));
  if (voice) u.voice = voice;
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}

function pushWord(w, speakIt = true) {
  state.words.push(w);
  state.cur = '';
  renderSentence();
  visualAlert();
  if (speakIt && el.autoSpeak.checked) speak(w);
}
function flushWord() { if (state.cur) pushWord(state.cur); }
function addSign(label) {
  if ([...label].length === 1) {
    state.cur += label;
    renderSentence();
    visualAlert();
  } else {
    flushWord();
    pushWord(label);
  }
}

function renderSuggest() {
  el.suggest.textContent = '';
  if (!state.cur) return;
  const list = scriptOf(state.cur) === 'en' ? EN_WORDS : AR_WORDS;
  for (const w of suggestWords(state.cur, list, 4)) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip'; b.textContent = w;
    if (scriptOf(w) === 'en') b.dir = 'ltr';
    b.addEventListener('click', () => pushWord(w));
    el.suggest.appendChild(b);
  }
  if (aiAvailable()) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip ai'; b.textContent = T('صحّح بالذكاء الاصطناعي');
    b.addEventListener('click', aiFixCurrent);
    el.suggest.appendChild(b);
  }
}

el.spaceBtn.addEventListener('click', flushWord);
el.speakBtn.addEventListener('click', () => speak(sentenceText()));
el.undoBtn.addEventListener('click', () => {
  if (state.cur) state.cur = state.cur.slice(0, -1);
  else state.words.pop();
  renderSentence();
});
el.clearBtn.addEventListener('click', () => { state.words = []; state.cur = ''; renderSentence(); });

function applyTuning() {
  const conf = Number(el.confRange.value);
  const hold = Number(el.holdRange.value);
  smoother.minConf = conf / 100;
  committer.hold = hold;
  el.confOut.textContent = `${conf}%`;
  el.holdOut.textContent = T('{0} ثانية', (hold / 30).toFixed(1));
}
el.confRange.addEventListener('input', applyTuning);
el.holdRange.addEventListener('input', applyTuning);

function updateModelBadge() {
  setTSeg(state.set);
  if (state.model) {
    el.modelBadge.textContent = T('يعمل بنموذجك المدرَّب: {0} إشارة ({1})', state.labels.length, state.labels.join('، '));
    el.modelBadge.classList.add('ready');
  } else {
    el.modelBadge.textContent = T('يعمل بالأشكال الافتراضية من المكتبة. درّب النظام بإشاراتك لدقة أعلى.');
    el.modelBadge.classList.remove('ready');
  }
}

/* ---------- التسجيل ---------- */

function renderSamples() {
  const counts = countByLabel();
  el.samplesTable.textContent = '';
  for (const [label, n] of [...counts.entries()].sort((a, b) => a[0].localeCompare(b[0], 'ar'))) {
    const row = document.createElement('div');
    row.className = 'sample-row';
    const name = document.createElement('span');
    name.className = 'sample-name';
    name.textContent = label;
    const cnt = document.createElement('span');
    cnt.className = 'sample-count' + (n < 10 ? ' low' : '');
    cnt.textContent = n < 10 ? T('{0} (قليلة)', n) : String(n);
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'icon-btn';
    del.textContent = T('حذف');
    del.setAttribute('aria-label', T('حذف عينات {0}', label));
    del.addEventListener('click', () => {
      state.samples = state.samples.filter((s) => s.label !== label);
      persistSamples();
      renderSamples();
      renderWizChips();
    });
    row.append(name, cnt, del);
    el.samplesTable.appendChild(row);
  }
  el.totalCount.textContent = T('{0} عينة', state.samples.length);
}

/** يبدأ تسجيل label: عدّ تنازلي 3 ثوانٍ ثم target عينة. onDone يُستدعى فقط عند اكتمال العدد. */
function beginRecording(label, target, onDone) {
  state.counting = true;
  el.recBtn.disabled = true;
  el.recStopBtn.hidden = false;
  let n = 3;
  el.countdown.textContent = String(n);
  el.countdown.hidden = false;
  clearInterval(state.countTimer);
  state.countTimer = setInterval(() => {
    n -= 1;
    if (!state.counting) { clearInterval(state.countTimer); return; }
    if (n > 0) { el.countdown.textContent = String(n); return; }
    clearInterval(state.countTimer);
    el.countdown.hidden = true;
    state.counting = false;
    state.recording = { label, target, got: 0, last: 0, onDone };
    setStatus(T('جارٍ تسجيل «{0}»... حرّك يدك قليلاً حول الوضعية.', label));
  }, 1000);
}
function stopRecording(finished = false) {
  const r = state.recording;
  state.recording = null;
  state.counting = false;
  clearInterval(state.countTimer);
  el.countdown.hidden = true;
  el.recBtn.disabled = false;
  el.recStopBtn.hidden = true;
  el.recProgress.style.width = '0';
  if (r && r.got > 0) {
    persistSamples();
    renderSamples();
    if (!r.onDone) toast(finished ? T('تم تسجيل {0} عينة لـ «{1}».', r.got, r.label) : T('أُوقف التسجيل بعد {0} عينة.', r.got));
  }
  setStatus(T('الكاميرا شغّالة.'));
  if (finished && r && r.onDone) r.onDone();
}
function onRecordFrame(vec) {
  const r = state.recording;
  if (!r) return;
  const now = performance.now();
  if (!vec) { setStatus(T('لا أرى يدك. أدخلها في الإطار.'), true); return; }
  setStatus(T('جارٍ تسجيل «{0}»...', r.label));
  if (now - r.last < 70) return;
  r.last = now;
  state.samples.push({ label: r.label, vec });
  r.got += 1;
  const pct = Math.round((r.got / r.target) * 100);
  el.recProgress.style.width = `${pct}%`;
  if (state.wiz.on) el.wizBar.style.width = `${pct}%`;
  if (r.got >= r.target) stopRecording(true);
}
el.recBtn.addEventListener('click', () => {
  const label = cleanLabel(el.labelInput.value);
  if (!label) { toast(T('اكتب اسم الإشارة أولاً.')); el.labelInput.focus(); return; }
  if (!state.cameraOn) { toast(T('شغّل الكاميرا أولاً.')); return; }
  beginRecording(label, Math.min(300, Math.max(20, Number(el.targetInput.value) || 80)), null);
});
el.recStopBtn.addEventListener('click', () => { if (state.wiz.on) wizStop(); else stopRecording(false); });

el.exportBtn.addEventListener('click', () => {
  if (!state.samples.length) { toast(T('لا توجد عينات للتصدير.')); return; }
  download('sign-samples.csv', ['﻿', samplesToCSV(state.samples)], 'text/csv;charset=utf-8');
});
el.importBtn.addEventListener('click', () => el.importFile.click());
el.importFile.addEventListener('change', async () => {
  const f = el.importFile.files[0];
  el.importFile.value = '';
  if (!f) return;
  const added = samplesFromCSV(await f.text());
  if (!added.length) { toast(T('الملف لا يحتوي عينات صالحة (63 قيمة لكل صف).')); return; }
  state.samples.push(...added);
  persistSamples();
  renderSamples();
  toast(T('أُضيفت {0} عينة.', added.length));
});
el.wipeBtn.addEventListener('click', () => {
  if (!state.samples.length) return;
  if (el.wipeBtn.dataset.armed !== '1') {
    el.wipeBtn.dataset.armed = '1';
    el.wipeBtn.textContent = T('اضغط مرة ثانية للتأكيد');
    setTimeout(() => { el.wipeBtn.dataset.armed = ''; el.wipeBtn.textContent = T('حذف الكل'); }, 3000);
    return;
  }
  el.wipeBtn.dataset.armed = '';
  el.wipeBtn.textContent = T('حذف الكل');
  state.samples = [];
  persistSamples();
  renderSamples();
});

/* ---------- التدريب الموجّه ---------- */

const setWizSeg = bindSeg(el.wizSet, (s) => {
  state.wizSet = s;
  state.wizSelected = new Set(LETTERS[s]);
  renderWizChips();
});

function renderWizChips() {
  setWizSeg(state.wizSet);
  const counts = countByLabel();
  el.wizChips.textContent = '';
  for (const ch of LETTERS[state.wizSet]) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip';
    b.textContent = ch;
    const have = counts.get(ch) || 0;
    b.title = have ? T('{0} عينة مسجّلة', have) : T('غير مسجّل');
    b.setAttribute('aria-pressed', String(state.wizSelected.has(ch)));
    if (have >= 10) b.style.opacity = '0.75';
    b.addEventListener('click', () => {
      if (state.wizSelected.has(ch)) state.wizSelected.delete(ch); else state.wizSelected.add(ch);
      b.setAttribute('aria-pressed', String(state.wizSelected.has(ch)));
    });
    el.wizChips.appendChild(b);
  }
}
el.wizAll.addEventListener('click', () => { state.wizSelected = new Set(LETTERS[state.wizSet]); renderWizChips(); });
el.wizNone.addEventListener('click', () => { state.wizSelected = new Set(); renderWizChips(); });

function wizStart() {
  if (state.training) return;
  if (!state.cameraOn) { toast(T('شغّل الكاميرا أولاً من الأعلى.')); return; }
  const list = LETTERS[state.wizSet].filter((c) => state.wizSelected.has(c));
  if (!list.length) { toast(T('اختر حرفاً واحداً على الأقل.')); return; }
  const per = Math.min(200, Math.max(20, Number(el.wizPer.value) || 40));
  state.wiz = { on: true, list, idx: 0, per };
  // سجّل من جديد: امسح عينات الحروف المختارة لتجنّب خلطها بقديم
  state.samples = state.samples.filter((s) => !list.includes(s.label));
  el.wizStart.hidden = true;
  el.wizStop.hidden = false;
  el.wizCard.hidden = false;
  wizNext();
}
function wizNext() {
  const w = state.wiz;
  if (!w.on) return;
  if (w.idx >= w.list.length) { wizFinish(); return; }
  const letter = w.list[w.idx];
  const sign = signFor(letter, state.wizSet);
  el.wizSign.innerHTML = sign ? sign.svg : '';
  el.wizLetter.textContent = letter;
  el.wizMsg.textContent = T('جهّز يدك وانتظر العدّ التنازلي، ثم اعمل إشارة هذا الحرف.');
  el.wizOverall.textContent = T('{0} من {1}', w.idx + 1, w.list.length);
  el.wizBar.style.width = '0';
  beginRecording(letter, w.per, () => {
    w.idx += 1;
    el.wizMsg.textContent = T('تم. استرخِ لحظة...');
    visualAlert();
    setTimeout(wizNext, 1000);
  });
}
function wizStop() {
  state.wiz.on = false;
  stopRecording(false);
  el.wizStart.hidden = false;
  el.wizStop.hidden = true;
  el.wizCard.hidden = true;
  renderWizChips();
  renderSamples();
  toast(T('أُوقف التسجيل الموجّه. العينات المسجّلة محفوظة.'));
}
function wizFinish() {
  state.wiz.on = false;
  el.wizStart.hidden = false;
  el.wizStop.hidden = true;
  el.wizCard.hidden = true;
  persistSamples();
  renderSamples();
  renderWizChips();
  toast(T('اكتمل التسجيل. جارٍ تدريب النموذج...'));
  train();
}
el.wizStart.addEventListener('click', wizStart);
el.wizStop.addEventListener('click', wizStop);

/* ---------- التدريب والتقييم ---------- */

function drawChart() {
  const c = el.chart;
  if (!c) return;
  const dpr = window.devicePixelRatio || 1;
  const W = c.clientWidth || 600;
  const H = Math.round(W * 0.37);
  c.width = W * dpr; c.height = H * dpr;
  const ctx = c.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  const padL = 36, padR = 10, padT = 10, padB = 22;
  const pw = W - padL - padR, ph = H - padT - padB;
  const muted = cssVar('--muted');
  ctx.font = '11px sans-serif';
  ctx.fillStyle = muted; ctx.strokeStyle = 'rgba(128,150,180,0.28)'; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padT + (ph * i) / 4;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    ctx.textAlign = 'right';
    ctx.fillText(`${100 - i * 25}%`, padL - 6, y + 4);
  }
  const n = state.history.acc.length;
  if (!n) return;
  const maxLoss = Math.max(1, ...state.history.loss);
  const X = (i) => padL + (n === 1 ? 0 : (pw * i) / (n - 1));
  const series = [
    [state.history.acc, muted, (v) => v],
    [state.history.loss, cssVar('--warn'), (v) => Math.min(1, v / maxLoss)],
    [state.history.valAcc, cssVar('--accent'), (v) => v],
  ];
  ctx.lineWidth = 2;
  for (const [data, color, f] of series) {
    ctx.strokeStyle = color;
    ctx.beginPath();
    data.forEach((v, i) => {
      const y = padT + ph * (1 - f(v));
      if (i === 0) ctx.moveTo(X(i), y); else ctx.lineTo(X(i), y);
    });
    ctx.stroke();
  }
  ctx.fillStyle = muted; ctx.textAlign = 'center';
  ctx.fillText(T('دورة {0}', n), W - padR - 24, H - 6);
}

function renderMatrix(labels, m) {
  const t = el.matrix;
  t.textContent = '';
  const head = document.createElement('tr');
  head.appendChild(document.createElement('th'));
  for (const l of labels) { const th = document.createElement('th'); th.textContent = l; head.appendChild(th); }
  t.appendChild(head);
  m.forEach((row, i) => {
    const tr = document.createElement('tr');
    const th = document.createElement('th'); th.textContent = labels[i]; tr.appendChild(th);
    const total = row.reduce((a, b) => a + b, 0) || 1;
    row.forEach((v, j) => {
      const td = document.createElement('td');
      td.textContent = String(v);
      const share = v / total;
      const color = i === j ? 'var(--accent)' : 'var(--bad)';
      if (v > 0) td.style.background = `color-mix(in srgb, ${color} ${Math.round(share * 70)}%, transparent)`;
      tr.appendChild(td);
    });
    t.appendChild(tr);
  });
}

async function train() {
  if (state.training) return;
  if (typeof tf === 'undefined') { toast(T('مكتبة TensorFlow.js لم تُحمَّل. تأكد من الاتصال بالإنترنت وأعد تحميل الصفحة.')); return; }
  const counts = countByLabel();
  const labels = [...counts.keys()].filter((l) => counts.get(l) >= 10).sort((a, b) => a.localeCompare(b, 'ar'));
  if (labels.length < 2) {
    toast(T('تحتاج إشارتين على الأقل، وكل واحدة بها 10 عينات أو أكثر.'));
    return;
  }
  state.training = true;
  el.trainBtn.disabled = true;
  el.evalBox.hidden = true;
  state.history = { loss: [], acc: [], valAcc: [] };
  const epochs = Math.min(200, Math.max(10, Number(el.epochsInput.value) || 60));
  const idx = new Map(labels.map((l, i) => [l, i]));
  const data = state.samples.filter((s) => idx.has(s.label));
  const { train: tr, val } = splitData(data, 0.2, 42);
  const rng = mulberry32(7);
  const aug = [];
  for (const s of tr) {
    aug.push(s);
    for (let k = 0; k < 2; k++) aug.push({ label: s.label, vec: augment(s.vec, rng, 0.02) });
  }
  const toY = (arr) => tf.oneHot(tf.tensor1d(arr.map((s) => idx.get(s.label)), 'int32'), labels.length);
  const xs = tf.tensor2d(aug.map((s) => s.vec), [aug.length, VEC_LEN]);
  const ys = toY(aug);
  const vx = tf.tensor2d(val.map((s) => s.vec), [val.length, VEC_LEN]);
  const vy = toY(val);

  const model = tf.sequential();
  model.add(tf.layers.dense({ units: 128, activation: 'relu', inputShape: [VEC_LEN] }));
  model.add(tf.layers.dropout({ rate: 0.2 }));
  model.add(tf.layers.dense({ units: 64, activation: 'relu' }));
  model.add(tf.layers.dense({ units: labels.length, activation: 'softmax' }));
  model.compile({ optimizer: tf.train.adam(0.001), loss: 'categoricalCrossentropy', metrics: ['accuracy'] });

  el.trainStatus.textContent = T('يدرّب على {0} عينة ({1} بعد التنويع) ويقيّم على {2}.', tr.length, aug.length, val.length);
  try {
    await model.fit(xs, ys, {
      epochs, batchSize: 32, shuffle: true, validationData: [vx, vy],
      callbacks: {
        onEpochEnd: async (epoch, logs) => {
          state.history.loss.push(logs.loss);
          state.history.acc.push(logs.acc ?? logs.accuracy ?? 0);
          state.history.valAcc.push(logs.val_acc ?? logs.val_accuracy ?? 0);
          el.trainProgress.style.width = `${Math.round(((epoch + 1) / epochs) * 100)}%`;
          el.trainStatus.textContent =
            T('الدورة {0} من {1}، دقة التقييم {2}%', epoch + 1, epochs, Math.round(state.history.valAcc.at(-1) * 100));
          drawChart();
          await tf.nextFrame();
        },
      },
    });

    const predIdx = Array.from(tf.tidy(() => model.predict(vx).argMax(-1).dataSync()));
    const trueIdx = val.map((s) => idx.get(s.label));
    const m = confusionMatrix(trueIdx, predIdx, labels.length);
    const correct = trueIdx.filter((t, i) => t === predIdx[i]).length;
    el.evalSummary.textContent = T('الدقة على بيانات التقييم: {0}% ({1} من {2})', Math.round((correct / val.length) * 100), correct, val.length);
    renderMatrix(labels, m);
    el.evalBox.hidden = false;

    if (state.model) state.model.dispose();
    state.model = model;
    state.labels = labels;
    smoother.reset();
    try {
      await model.save(MODEL_STORE);
      store(KEY_LABELS, JSON.stringify(labels));
    } catch { toast(T('تعذّر حفظ النموذج في المتصفح. نزّله يدوياً.')); }
    updateModelBadge();
    el.downloadBtn.disabled = false;
    el.trainStatus.textContent = T('اكتمل التدريب. جرّب الآن من تبويب «إشارات إلى نص».');
    visualAlert();
  } catch (err) {
    console.error(err);
    el.trainStatus.textContent = T('حدث خطأ أثناء التدريب. افتح وحدة التحكم لمعرفة التفاصيل.');
  } finally {
    xs.dispose(); ys.dispose(); vx.dispose(); vy.dispose();
    state.training = false;
    el.trainBtn.disabled = false;
  }
}
el.trainBtn.addEventListener('click', train);
el.downloadBtn.addEventListener('click', async () => {
  if (!state.model) return;
  await state.model.save('downloads://sign-model');
  download('labels.json', [JSON.stringify(state.labels)], 'application/json');
});
window.addEventListener('resize', () => { if (state.tab === 'train') drawChart(); });

async function restoreModel() {
  try {
    const labels = JSON.parse(load(KEY_LABELS) || 'null');
    if (!labels) return;
    state.model = await tf.loadLayersModel(MODEL_STORE);
    state.labels = labels;
    el.downloadBtn.disabled = false;
    updateModelBadge();
  } catch { /* لا يوجد نموذج محفوظ */ }
}

/* ---------- الذكاء الاصطناعي ---------- */

const SITE_FACTS = 'الموقع اسمه «مترجم الإشارة». أقسامه: كتابة إلى إشارات (يحوّل نصاً عربياً أو إنجليزياً إلى رسومات أشكال اليد حرفاً حرفاً مع زر شاشة العرض)، إشارات إلى نص (كاميرا تتعرف على هجاء الأصابع وتنطق الكلمات)، مكتبة الإشارات (تعديل شكل كل حرف)، درّب النظام (تسجيل موجّه لإشارات المستخدم ثم تدريب نموذج داخل المتصفح)، والذكاء الاصطناعي. الرسومات الافتراضية تجريبية وليست قاموساً رسمياً للغة الإشارة. كل المعالجة داخل المتصفح.';
const AI_TASKS = {
  simplify: (t) => `أعد كتابة النص التالي بجمل قصيرة وبسيطة وواضحة، مناسبة لقارئ أصم تكون العربية لغته الثانية. حافظ على المعنى ولا تضف معلومات. اكتب النص فقط بدون مقدمة. إن كان النص بالإنجليزية فاكتبه بإنجليزية بسيطة.\n\nالنص:\n${t}`,
  toEn: (t) => `Translate the following text into clear, simple English. Output only the translation.\n\n${t}`,
  toAr: (t) => `ترجم النص التالي إلى العربية الواضحة المبسّطة. اكتب الترجمة فقط بدون مقدمة.\n\n${t}`,
  ask: (t) => `${SITE_FACTS}\nأجب عن سؤال المستخدم بإيجاز وبلغته، وبخطوات قصيرة إن لزم، ولا تذكر ميزات غير مذكورة أعلاه.\n\nالسؤال:\n${t}`,
  spell: (t) => `نظام تعرّف على هجاء الأصابع أنتج هذه الحروف وقد تحتوي أخطاء: «${t}». اقترح حتى 4 كلمات صحيحة محتملة (عربية أو إنجليزية بحسب الحروف) مفصولة بفاصلة في سطر واحد، بدون شرح. إن لم تجد فاكتب الحروف كما هي.`,
};
const AI_ERR = {
  not_granted: 'لم تسمح باستخدام Claude لهذه الصفحة.',
  rate_limited: 'طلبات كثيرة أو وصلت للحد المسموح. حاول بعد قليل.',
  sampling_disabled: 'Claude غير متاح لهذا الحساب.',
  session_expired: 'انتهت الجلسة. سجّل الدخول من جديد.',
  nokey: 'أضف مفتاح Anthropic API أولاً.',
  badkey: 'المفتاح غير صالح. تحقق منه وأعد المحاولة.',
};

function aiKey() { return load(KEY_AI) || ''; }
function aiAvailable() { return !!state.sample || !!aiKey(); }

async function initAI() {
  if (IN_ARTIFACT) {
    try { if (window.claude && window.claude.use) state.sample = await window.claude.use('sample'); } catch { state.sample = null; }
  }
  refreshAIUI();
  renderSuggest();
}
function refreshAIUI() {
  el.aiKeyBox.hidden = IN_ARTIFACT;
  if (state.sample) {
    el.aiNote.textContent = T('يعمل عبر حسابك في Claude. أول استخدام يطلب موافقتك.');
  } else if (IN_ARTIFACT) {
    el.aiNote.textContent = T('الذكاء الاصطناعي غير متاح في هذا العرض.');
  } else if (aiKey()) {
    el.aiNote.textContent = T('المفتاح محفوظ في متصفحك. النص الذي تكتبه فقط يُرسل إلى Anthropic، ويُحاسَب على حسابك.');
  } else {
    el.aiNote.textContent = T('لتفعيل هذا القسم أدخل مفتاح Anthropic API الخاص بك. لا يُرسل المفتاح لأي جهة غير Anthropic.');
  }
  $$('.task').forEach((b) => { b.disabled = !aiAvailable(); });
}

async function callAI(prompt, { onText, signal } = {}) {
  if (getLang() === 'en' && !prompt.startsWith('Translate')) prompt += '\n\n(The site interface is in English. Write your answer in English unless the task above asks for Arabic.)';
  if (state.sample) {
    const r = await state.sample(prompt, {
      modelTier: 'quick', signal,
      onText: onText ? (u) => onText(u.text) : undefined,
    });
    return r.text;
  }
  const key = aiKey();
  if (!key) throw { code: 'nokey' };
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST', signal,
    headers: {
      'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 700, messages: [{ role: 'user', content: prompt }] }),
  });
  if (!res.ok) throw { code: res.status === 401 ? 'badkey' : res.status === 429 ? 'rate_limited' : 'http' };
  const j = await res.json();
  const text = (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
  if (onText) onText(text);
  return text;
}
function aiErrorText(e) {
  if (e && e.name === 'AbortError') return null;
  if (e && e.code === 'cancelled') return null;
  return T(AI_ERR[e && e.code] || 'تعذّر الحصول على إجابة. حاول مرة أخرى.');
}

async function runAI(task) {
  const text = el.aiInput.value.trim();
  if (!text) { toast(T('اكتب نصاً أو سؤالاً أولاً.')); el.aiInput.focus(); return; }
  if (state.aiAbort) state.aiAbort.abort();
  const ctl = new AbortController();
  state.aiAbort = ctl;
  el.aiOut.textContent = T('جارٍ التفكير...');
  el.aiStop.hidden = false;
  el.aiToSigns.hidden = true;
  el.aiCopy.hidden = true;
  try {
    const out = await callAI(AI_TASKS[task](text), { signal: ctl.signal, onText: (t) => { el.aiOut.textContent = t; } });
    state.aiText = out;
    el.aiOut.textContent = out;
    el.aiOut.dir = scriptOf(out) === 'en' ? 'ltr' : 'rtl';
    el.aiToSigns.hidden = task === 'ask';
    el.aiCopy.hidden = false;
  } catch (e) {
    const msg = aiErrorText(e);
    el.aiOut.textContent = msg || '';
    if (e && e.text) el.aiOut.textContent = e.text;
  } finally {
    if (state.aiAbort === ctl) state.aiAbort = null;
    el.aiStop.hidden = true;
  }
}
$$('.task').forEach((b) => b.addEventListener('click', () => runAI(b.dataset.task)));
el.aiStop.addEventListener('click', () => { if (state.aiAbort) state.aiAbort.abort(); });
el.aiToSigns.addEventListener('click', () => {
  el.textInput.value = state.aiText.slice(0, 400);
  state.idx = 0;
  setTab('write');
});
el.aiCopy.addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(state.aiText); toast(T('تم النسخ.')); } catch { toast(T('تعذّر النسخ. حدّد النص وانسخه يدوياً.')); }
});
el.aiKeySave.addEventListener('click', () => {
  const k = el.aiKey.value.trim();
  if (!k) { toast(T('الصق المفتاح أولاً.')); return; }
  if (!store(KEY_AI, k)) { toast(T('تعذّر حفظ المفتاح في المتصفح.')); return; }
  el.aiKey.value = '';
  toast(T('تم حفظ المفتاح في متصفحك.'));
  refreshAIUI(); renderSuggest();
});
el.aiKeyClear.addEventListener('click', () => {
  try { localStorage.removeItem(KEY_AI); } catch { /* تجاهل */ }
  el.aiKey.value = '';
  toast(T('تم حذف المفتاح.'));
  refreshAIUI(); renderSuggest();
});

async function aiFixCurrent() {
  const letters = state.cur;
  if (!letters) return;
  el.suggest.textContent = '';
  const wait = document.createElement('span');
  wait.className = 'muted small'; wait.textContent = T('جارٍ التفكير...');
  el.suggest.appendChild(wait);
  try {
    const out = await callAI(AI_TASKS.spell(letters));
    el.suggest.textContent = '';
    const picks = out.split(/[،,\n]/).map((x) => x.replace(/[«»"'.]/g, '').trim()).filter(Boolean).slice(0, 4);
    for (const w of picks) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'chip ai'; b.textContent = w;
      if (scriptOf(w) === 'en') b.dir = 'ltr';
      b.addEventListener('click', () => pushWord(w));
      el.suggest.appendChild(b);
    }
    if (!picks.length) renderSuggest();
  } catch (e) {
    toast(aiErrorText(e) || T('أُلغي الطلب.'));
    renderSuggest();
  }
}

/* ---------- لغة الموقع ---------- */

function refreshAll() {
  applyPrefs();
  renderPhrases();
  renderWords();
  renderLibrary();
  renderSamples();
  renderSentence();
  renderWizChips();
  updateModelBadge();
  refreshAIUI();
  setFocus(el.bigStage.classList.contains('focus'));
  el.playBtn.textContent = state.playing ? T('إيقاف') : T('تشغيل');
  el.speedOut.textContent = T('{0} ثانية', (Number(el.speedRange.value) / 10).toFixed(1));
  if (state.libMode === 'gestures') renderGestures();
  if (!game.on) { el.gameQ.textContent = T('اضغط «ابدأ» لتبدأ جولة من 10 أسئلة.'); el.gameStart.textContent = T('ابدأ'); }
  showFact();
  if (IN_ARTIFACT) el.idleNote.textContent = T('الكاميرا غير متاحة داخل Claude.');
  if (state.tab === 'train') drawChart();
}
function applyLanguage() {
  applyLang(prefs.lang);
  refreshAll();
}
el.langBtn.addEventListener('click', () => { prefs.lang = getLang() === 'en' ? 'ar' : 'en'; savePrefs(); applyLanguage(); });

/* ---------- البداية ---------- */

if (IN_ARTIFACT) {
  document.body.classList.add('lite');
  el.idleNote.textContent = T('الكاميرا غير متاحة داخل Claude.');
}
loadPrefs();
if (!load(KEY_PREFS)) prefs.theme = 'noir';
loadSamples();
loadLibrary();
applyPrefs();
applyTuning();
setView(prefs.view);
setViewSeg(prefs.view);
setPresetSeg(prefs.preset);
initGame();
renderPhrases();
renderSamples();
renderSentence();
renderWords();
renderWizChips();
restoreModel();
initAI();
ensureAvatar();
if (prefs.lang === 'en') applyLanguage();
if ('speechSynthesis' in window) speechSynthesis.getVoices();
{
  const h = (location.hash || '').replace('#', '');
  const camOnly = ['translate', 'train'];
  const ok = TABS.includes(h) && !(IN_ARTIFACT && camOnly.includes(h));
  setTab(ok ? h : 'write');
  if (!prefs.role) showWelcome();
}
