/* قواميس صغيرة لاقتراح الكلمات أثناء الهجاء بالأصابع. تُطابَق بعد توحيد الهمزات. */
export const AR_WORDS = [
  'مرحبا', 'أهلا', 'شكرا', 'نعم', 'لا', 'عفوا', 'آسف', 'تفضل', 'سلام', 'مع السلامة',
  'ساعدني', 'مساعدة', 'أحتاج', 'أريد', 'أحب', 'أين', 'كيف', 'ماذا', 'متى', 'لماذا', 'من', 'هل',
  'أنا', 'أنت', 'هو', 'هي', 'نحن', 'هم', 'اسم', 'عمر', 'عمل', 'مال', 'سوق', 'طريق',
  'ماء', 'طعام', 'خبز', 'شاي', 'قهوة', 'حليب', 'لحم', 'دجاج', 'سمك', 'فاكهة', 'تفاح', 'موز', 'برتقال',
  'بيت', 'مدرسة', 'جامعة', 'مستشفى', 'طبيب', 'دواء', 'ألم', 'مريض', 'صحة', 'شرطة', 'طوارئ',
  'صديق', 'عائلة', 'أم', 'أب', 'أخ', 'أخت', 'ابن', 'بنت', 'معلم', 'طالب',
  'سيارة', 'حافلة', 'قطار', 'مطار', 'فندق', 'مطعم', 'حمام', 'مسجد', 'كتاب', 'هاتف',
  'صباح', 'مساء', 'ليل', 'نهار', 'اليوم', 'غدا', 'أمس', 'الآن', 'قريبا',
  'جيد', 'سيء', 'كبير', 'صغير', 'سريع', 'بطيء', 'حار', 'بارد', 'جميل', 'سعيد', 'حزين', 'تعبان', 'جائع', 'عطشان',
  'أصم', 'إشارة', 'لغة', 'فهمت', 'أعد', 'ببطء', 'اكتب', 'انتظر', 'تعال', 'اذهب',
];

export const EN_WORDS = [
  'hello', 'hi', 'thanks', 'thank', 'please', 'yes', 'no', 'sorry', 'excuse', 'goodbye', 'welcome',
  'help', 'need', 'want', 'like', 'love', 'where', 'what', 'when', 'why', 'who', 'how', 'which',
  'name', 'work', 'money', 'market', 'road', 'water', 'food', 'bread', 'tea', 'coffee', 'milk', 'meat', 'chicken', 'fish', 'fruit', 'apple', 'banana', 'orange',
  'home', 'house', 'school', 'university', 'hospital', 'doctor', 'medicine', 'pain', 'sick', 'health', 'police', 'emergency',
  'friend', 'family', 'mother', 'father', 'brother', 'sister', 'son', 'daughter', 'teacher', 'student',
  'car', 'bus', 'train', 'airport', 'hotel', 'restaurant', 'toilet', 'mosque', 'book', 'phone',
  'morning', 'evening', 'night', 'day', 'today', 'tomorrow', 'yesterday', 'now', 'soon',
  'good', 'bad', 'big', 'small', 'fast', 'slow', 'hot', 'cold', 'beautiful', 'happy', 'sad', 'tired', 'hungry', 'thirsty',
  'deaf', 'sign', 'language', 'understand', 'repeat', 'slowly', 'write', 'wait', 'come', 'go',
];
