// core.js — منطق صرف بدون كاميرا ولا واجهة، حتى يمكن اختباره بسهولة.

export const NUM_POINTS = 21;
export const VEC_LEN = NUM_POINTS * 3; // 63 قيمة لكل عينة

/**
 * تطبيع النقاط: نسبةً للمعصم ثم تغيير الحجم.
 * lm: مصفوفة من 21 نقطة {x, y, z}
 * handedness: 'Left' أو 'Right'. اليد اليسرى تُعكس أفقياً حتى تتشابه اليدان.
 */
export function normalizeLandmarks(lm, handedness = 'Right') {
  const w = lm[0];
  const mirror = handedness === 'Left' ? -1 : 1;
  const pts = lm.map((p) => [(p.x - w.x) * mirror, p.y - w.y, p.z - w.z]);
  let scale = 0;
  for (const p of pts) scale = Math.max(scale, Math.hypot(p[0], p[1], p[2]));
  if (scale < 1e-6) scale = 1;
  const out = [];
  for (const p of pts) out.push(p[0] / scale, p[1] / scale, p[2] / scale);
  return out;
}

/** تنعيم النتيجة على عدة فريمات: تصويت الأغلبية مع متوسط الثقة. */
export class Smoother {
  constructor(size = 8, minShare = 0.6, minConf = 0.7) {
    this.size = size;
    this.minShare = minShare;
    this.minConf = minConf;
    this.buf = [];
  }
  push(label, conf = 0) {
    this.buf.push({ label, conf });
    while (this.buf.length > this.size) this.buf.shift();
  }
  reset() {
    this.buf = [];
  }
  get() {
    if (this.buf.length < Math.ceil(this.size / 2)) return null;
    const stats = new Map();
    for (const e of this.buf) {
      if (e.label === null) continue;
      const s = stats.get(e.label) || { n: 0, sum: 0 };
      s.n += 1;
      s.sum += e.conf;
      stats.set(e.label, s);
    }
    let best = null;
    for (const [label, s] of stats) {
      if (!best || s.n > best.n) best = { label, n: s.n, conf: s.sum / s.n };
    }
    if (!best) return null;
    if (best.n / this.buf.length < this.minShare) return null;
    if (best.conf < this.minConf) return null;
    return { label: best.label, conf: best.conf };
  }
}

/**
 * يقرّر متى تُضاف الكلمة للجملة: بعد ثباتها `hold` فريم.
 * تكرار نفس الإشارة يحتاج إنزال اليد أولاً.
 */
export class Committer {
  constructor(hold = 15, releaseFrames = 6) {
    this.hold = hold;
    this.releaseFrames = releaseFrames;
    this.cur = null;
    this.count = 0;
    this.nullCount = 0;
    this.armed = true;
    this.last = null;
  }
  update(label) {
    if (label === null || label === undefined) {
      this.nullCount += 1;
      if (this.nullCount >= this.releaseFrames) {
        this.armed = true;
        this.cur = null;
        this.count = 0;
      }
      return null;
    }
    this.nullCount = 0;
    if (label !== this.cur) {
      this.cur = label;
      this.count = 1;
    } else {
      this.count += 1;
    }
    if (this.count === this.hold && (this.armed || label !== this.last)) {
      this.last = label;
      this.armed = false;
      return label;
    }
    return null;
  }
}

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle(arr, rng) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/** تقسيم تدريب/تحقق لكل إشارة على حدة. */
export function splitData(samples, valFraction = 0.2, seed = 42) {
  const rng = mulberry32(seed);
  const groups = new Map();
  for (const s of samples) {
    if (!groups.has(s.label)) groups.set(s.label, []);
    groups.get(s.label).push(s);
  }
  const train = [];
  const val = [];
  for (const items of groups.values()) {
    shuffle(items, rng);
    const nVal = Math.max(1, Math.round(items.length * valFraction));
    val.push(...items.slice(0, nVal));
    train.push(...items.slice(nVal));
  }
  return { train: shuffle(train, rng), val };
}

/** ضجيج بسيط لزيادة تنوّع بيانات التدريب. */
export function augment(vec, rng, sigma = 0.02) {
  return vec.map((v) => {
    const u1 = Math.max(rng(), 1e-9);
    const u2 = rng();
    const g = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return v + g * sigma;
  });
}

export function confusionMatrix(trueIdx, predIdx, n) {
  const m = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < trueIdx.length; i++) m[trueIdx[i]][predIdx[i]] += 1;
  return m;
}

export function cleanLabel(s) {
  return String(s).replace(/[\r\n,"]/g, ' ').replace(/\s+/g, ' ').trim();
}

export function samplesToCSV(samples) {
  const head = ['label'];
  for (let i = 0; i < NUM_POINTS; i++) head.push(`x${i}`, `y${i}`, `z${i}`);
  const rows = [head.join(',')];
  for (const s of samples) {
    rows.push([cleanLabel(s.label), ...s.vec.map((v) => v.toFixed(5))].join(','));
  }
  return rows.join('\n');
}

export function samplesFromCSV(text) {
  const out = [];
  const lines = text.replace(/^﻿/, '').split(/\r?\n/);
  for (const line of lines) {
    if (!line.trim()) continue;
    const cells = line.split(',');
    if (cells[0].trim() === 'label') continue;
    const label = cleanLabel(cells[0]);
    const vec = cells.slice(1).map(Number);
    if (!label || vec.length !== VEC_LEN || vec.some((v) => !Number.isFinite(v))) continue;
    out.push({ label, vec });
  }
  return out;
}

/* ---------- حالة الأصابع (للتعرّف بدون تدريب) ---------- */

function _P(v, i) { return [v[i * 3], v[i * 3 + 1], v[i * 3 + 2]]; }
function _dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]); }
function _ang(a, b, c) {
  const u = [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const w = [c[0] - b[0], c[1] - b[1], c[2] - b[2]];
  const n = Math.hypot(...u) * Math.hypot(...w);
  if (n < 1e-9) return 180;
  const d = (u[0] * w[0] + u[1] * w[1] + u[2] * w[2]) / n;
  return (Math.acos(Math.max(-1, Math.min(1, d))) * 180) / Math.PI;
}
function _clamp01(x) { return Math.max(0, Math.min(1, x)); }

const _FINGER_CHAINS = [[5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]];

/** [إبهام، سبابة، وسطى، بنصر، خنصر] كل قيمة بين 0 (مطوي) و1 (ممدود). */
export function fingerStates(v) {
  const out = [];
  const palm = _dist(_P(v, 5), _P(v, 17)) || 1e-6;
  const r = _dist(_P(v, 4), _P(v, 9)) / palm;
  out.push(_clamp01((r - THUMB_R_MIN) / (THUMB_R_MAX - THUMB_R_MIN)));
  for (const [m, p, d, t] of _FINGER_CHAINS) {
    const a1 = _ang(_P(v, m), _P(v, p), _P(v, d));
    const a2 = _ang(_P(v, p), _P(v, d), _P(v, t));
    out.push(_clamp01((0.6 * a1 + 0.4 * a2 - 100) / 60));
  }
  return out;
}
export const THUMB_R_MIN = 0.8;
export const THUMB_R_MAX = 1.1;

/* ---------- نص عربي إلى حروف ---------- */

export const ARABIC_LETTERS = [...'ابتثجحخدذرزسشصضطظعغفقكلمنهوي'];
const _FOLD = { 'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ة': 'ه', 'ى': 'ي', 'ؤ': 'و', 'ئ': 'ي' };

export function normalizeArabic(text) {
  return String(text)
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[أإآٱةىؤئ]/g, (c) => _FOLD[c])
    .replace(/ء/g, '');
}

export const ENGLISH_LETTERS = [...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'];

/** يرجع مصفوفة كلمات، كل كلمة مصفوفة من {ch, sign, set}. sign=true إن كان الحرف له إشارة (عربي أو لاتيني). */
export function textToWords(text) {
  return normalizeArabic(text)
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => [...w].map((c) => {
      if (ARABIC_LETTERS.includes(c)) return { ch: c, sign: true, set: 'ar' };
      if (/[A-Za-z]/.test(c)) return { ch: c.toUpperCase(), sign: true, set: 'en' };
      return { ch: c, sign: false, set: null };
    }));
}

/** 'en' إن كان النص لاتينياً، وإلا 'ar'. */
export function scriptOf(s) {
  return /[A-Za-z]/.test(s) && !/[\u0600-\u06FF]/.test(s) ? 'en' : 'ar';
}

/** اقتراح كلمات تبدأ بالحروف الحالية. أول اقتراح هو الأقدم في القاموس (الأشيع). */
export function suggestWords(prefix, list, n = 4) {
  if (!prefix) return [];
  const isEn = scriptOf(prefix) === 'en';
  const key = (w) => (isEn ? w.toLowerCase() : normalizeArabic(w));
  const p = key(prefix);
  const out = [];
  for (const w of list) {
    if (key(w).startsWith(p)) out.push(w);
    if (out.length >= n) break;
  }
  return out;
}
