# مترجم الإشارة · Sign Translator

موقع يعمل كله داخل المتصفح: يترجم من لغة الإشارة (هجاء الأصابع) إلى نص وصوت بالكاميرا، ومن النص إلى شخصية متحركة تؤدّي الحركات والتعابير. بالعربية والإنجليزية.
A browser-only site: camera fingerspelling → text/speech, and text → an animated character that performs gestures and expressions. Arabic and English UI.

## الملفات · Files
| ملف | الوصف |
|---|---|
| `index.html` | الموقع كاملاً (افتحه في Chrome أو Edge) · the complete site |
| `speaker-notes.html` | ملف الشرح لكل سلايد · speaker script |
| `photos/` | اختياري: صور حقيقية بدل الرسوم · optional real photos |
| `slides.html` | عرض من 30 شريحة يشرح كل شيء · 30-slide explainer deck |
| `src/` | المصادر: `core.js signs.js avatar.js gestures.js studio.js i18n.js app.js body.html style.css build.py` |

## التشغيل · Run
- افتح `index.html` في Chrome/Edge. للكاميرا يفضّل https أو localhost (مثل GitHub Pages).
- على GitHub: Settings → Pages → Deploy from a branch، فيعمل الموقع بدل عرضه كنص.
- البناء من المصادر: `python3 build.py` ثم `python3 build_deck.py` · tests: `node --test`.

## تنبيه · Notice
الأشكال والحركات الافتراضية **تجريبية** وليست قاموس لغة إشارة رسمياً؛ يجب مراجعتها مع مترجم إشارة أو شخص أصم.
Default shapes and gestures are **experimental**, not an official sign-language dictionary.

## الخصوصية · Privacy
الفيديو يُعالَج داخل المتصفح ولا يُرسل لأي مكان. ميزة الذكاء الاصطناعي (اختيارية) ترسل النص المكتوب فقط.
