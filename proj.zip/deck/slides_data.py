# -*- coding: utf-8 -*-
# كل شريحة: tag, title (ar|en), body (html مع [[ar|en]]), notes (ar|en), photo (id, query) اختياري
PH = []
def P(pid, q):
    PH.append((pid, q))
    return f'''<figure class="photo" data-p="{pid}" title="[[انقر لاستبدالها بصورة حقيقية|Click to replace with a real photo]]"><img src="photos/{pid}.jpg" alt=""><div class="sc" data-scene="{pid}"></div><figcaption contenteditable spellcheck="false">[[رسم توضيحي بالذكاء الاصطناعي (Claude)|Illustration made with AI (Claude)]]</figcaption></figure>'''

S = []
def add(tag, title, body, notes, cls=''):
    S.append(dict(tag=tag, title=title, body=body, notes=notes, cls=cls))

add('[[البداية|Start]]', None, '''
 <div class="body"><div class="col fade" style="flex:1.4">
  <div class="chip gold">[[الذكاء الاصطناعي × حالات الأصم|AI × deaf use cases]]</div>
  <h1 style="font-size:64px;margin:12px 0">[[ربط الذكاء الاصطناعي بحالات الأصم|Linking AI to deaf use cases]]</h1>
  <ul style="font-size:26px"><li>[[أين يفيد، وأين يخطئ، وكيف بنينا «مترجم الإشارة» كمثال عملي|Where it helps, where it fails, and how we built "Sign Translator" as a working example]]</li></ul>
  <p class="note">[[30 شريحة · عربي / English · اضغط N لعرض ملاحظات المتحدث|30 slides · Arabic / English · press N for speaker notes]]</p></div>
  <div class="col" style="flex:.8"><div class="av" id="av1"></div></div></div>''',
 ('مرحباً بكم. موضوعنا اليوم: كيف نربط الذكاء الاصطناعي بحالات حقيقية يعيشها الأصم، لا كشعار بل كأدوات صغيرة نافعة. وسنرى مثالاً بنيناه: موقع «مترجم الإشارة». الشخصية التي ترونها تؤدي حركة تحية حيّة من داخل الموقع.',
  'Welcome. Today we link AI to real situations in a deaf person\'s life, not as a slogan but as small useful tools. We will end with a working example we built: Sign Translator. The character you see is performing a live greeting from inside the site.'))

add('[[الأرقام|The numbers]]', ('لماذا يهم الموضوع؟','Why this matters'), '''
 <div class="body"><div class="col" style="flex:1.5"><div class="row fade">
  <div class="card"><div class="stat">430M</div><p>[[شخص يحتاج تأهيلاً بسبب فقدان سمع مُعيق (أكثر من 5% من سكان العالم)|people need rehabilitation for disabling hearing loss (over 5% of the world)]]</p></div>
  <div class="card"><div class="stat">1 / 10</div><p>[[التوقع بحلول 2050: أكثر من 700 مليون شخص|Projected by 2050: over 700 million people]]</p></div></div>
  <div class="row fade" style="margin-top:14px"><div class="card"><div class="stat">70M+</div><p>[[أصم في العالم بحسب الاتحاد العالمي للصم|deaf people, per the World Federation of the Deaf]]</p></div>
  <div class="card"><div class="stat">300+</div><p>[[لغة إشارة مختلفة، وليست لغة واحدة|different sign languages, not one]]</p></div></div>
  <p class="note">[[المصادر: منظمة الصحة العالمية (WHO) · الاتحاد العالمي للصم · الأمم المتحدة.|Sources: WHO · World Federation of the Deaf · United Nations.]]</p></div>
  <div class="col" style="flex:.9">''' + P('p02','deaf people using sign language conversation') + '</div></div>',
 ('هذه أرقام منظمة الصحة العالمية: نحو 430 مليون شخص لديهم فقدان سمع مُعيق، ويتوقع أن يصلوا إلى أكثر من 700 مليون بحلول 2050. ومنهم عدد كبير يستخدم لغة إشارة، والاتحاد العالمي للصم يقدّر الصم بأكثر من 70 مليوناً، وعندهم أكثر من 300 لغة إشارة. أي أن الحاجة كبيرة وليست حالة نادرة.',
  'These are WHO figures: about 430 million people have disabling hearing loss, projected to pass 700 million by 2050. Many deaf people use sign language; the World Federation of the Deaf estimates over 70 million deaf people and 300+ sign languages. The need is large, not marginal.'))

add('[[الحاجز|The gap]]', ('أين يظهر حاجز التواصل؟','Where the communication gap shows up'), '''
 <div class="body"><div class="col fade" style="flex:1.3;display:grid;grid-template-columns:1fr 1fr;gap:14px">
  <div class="card"><h3>[[المستشفى|Clinic]]</h3><p>[[شرح الأعراض والموافقات الطبية|Explaining symptoms, medical consent]]</p></div>
  <div class="card"><h3>[[المدرسة|School]]</h3><p>[[محاضرة بلا ترجمة أو تفريغ نصي|Lectures without interpretation or captions]]</p></div>
  <div class="card"><h3>[[العمل|Work]]</h3><p>[[اجتماعات سريعة وحوارات جانبية|Fast meetings, side conversations]]</p></div>
  <div class="card"><h3>[[الطوارئ|Emergency]]</h3><p>[[إنذار أو جرس أو نداء لا يُسمع|An alarm, bell or call that cannot be heard]]</p></div>
  <div class="card" style="grid-column:1/3"><h3>[[الخدمات العامة|Public services]]</h3><p>[[شبابيك، مكالمات، تطبيقات صوتية فقط|Counters, phone calls, voice-only apps]]</p></div></div>
  <div class="col" style="flex:.9">''' + P('p03','hospital reception communication accessibility') + '</div></div>',
 ('الحاجز لا يظهر في كل مكان بنفس الشكل. في المستشفى المشكلة دقة المعلومة، في المدرسة الوصول للمحتوى، في العمل السرعة، وفي الطوارئ ما لا يُسمع أصلاً. لذلك لا يوجد «حل ذكاء اصطناعي واحد»، بل أدوات مختلفة لكل حالة.',
  'The gap looks different everywhere: in clinics it is accuracy, in school access to content, at work speed, and in emergencies what simply cannot be heard. So there is no single AI fix, but different tools for different cases.'))

add('[[الخريطة|Map]]', ('ماذا نعني بربط الذكاء الاصطناعي بالحالات؟','What "linking AI to cases" means'), '''
 <div class="body" style="flex-direction:column;align-items:stretch;gap:12px"><div class="flow rtlflow fade" style="justify-content:center;flex-wrap:wrap">
  <div class="node acc"><b>[[قدرة ذكاء اصطناعي|AI capability]]</b><span>[[ماذا يستطيع؟|what can it do?]]</span></div><div class="arr"></div>
  <div class="node"><b>[[حالة حقيقية|Real case]]</b><span>[[من يحتاجه ومتى؟|who needs it, when?]]</span></div><div class="arr"></div>
  <div class="node"><b>[[ضمانات|Safeguards]]</b><span>[[إنسان، مراجعة، خصوصية|human, review, privacy]]</span></div><div class="arr"></div>
  <div class="node gold"><b>[[قياس|Measure]]</b><span>[[هل نفع فعلاً؟|did it really help?]]</span></div></div>
  <div class="row fade"><div class="card"><h3>[[تفريغ الكلام|Speech → text]]</h3><p>[[للأصم القارئ|for deaf readers]]</p></div><div class="card"><h3>[[رؤية الحاسوب|Computer vision]]</h3><p>[[قراءة اليد والإشارة|reading hands and signs]]</p></div><div class="card"><h3>[[التوليد|Generation]]</h3><p>[[شخصية تؤدي الإشارة|a character that signs]]</p></div><div class="card"><h3>[[تصنيف الأصوات|Sound AI]]</h3><p>[[تنبيهات بصرية واهتزاز|visual / vibration alerts]]</p></div><div class="card"><h3>[[اللغة|Language models]]</h3><p>[[تبسيط وترجمة|simplify and translate]]</p></div></div></div>''',
 ('الربط ليس أن نضع ذكاءً اصطناعياً في كل شيء. نبدأ بقدرة محددة، نربطها بحالة حقيقية، نضع لها ضمانات مثل المراجعة البشرية والخصوصية، ثم نقيس هل نفعت فعلاً. وهناك خمس قدرات رئيسية سنمرّ على حالاتها.',
  'Linking is not putting AI everywhere. We start from a specific capability, tie it to a real case, add safeguards such as human review and privacy, then measure whether it helped. There are five main capabilities, and we will walk through their cases.'))

add('[[حالة 1|Case 1]]', ('الحالة 1: تفريغ الكلام إلى نص فوري','Case 1: live speech-to-text captions'), '''
 <div class="body"><div class="col fade" style="flex:1.3"><ul><li>[[التعرّف على الكلام يحوّل صوت المتحدث إلى تعليق نصي أثناء الاجتماع أو المحاضرة|Speech recognition turns a speaker's voice into captions during a meeting or lecture]]</li><li>[[يفيد من يقرأ اللغة المكتوبة بسهولة|Helps people who read the written language comfortably]]</li><li class="warnli">[[يتعثر مع اللهجات والضجيج والأسماء|Struggles with dialects, noise and names]]</li><li>[[الحل: عرض النص مع إمكانية التصحيح، وترجمان بشري للمواقف الحرجة|Fix: show text that can be corrected, and a human interpreter for critical moments]]</li></ul></div>
  <div class="col" style="flex:.9">''' + P('p05','live captions on phone meeting accessibility') + '</div></div>',
 ('أوضح حالة ربط: الميكروفون يسمع والشاشة تكتب. تنفع كثيراً لمن يقرأ بسهولة، لكنها تضعف مع اللهجات العربية والضجيج وأسماء الأعلام. لذلك نعرض النص بشكل قابل للتصحيح، ونُبقي مترجماً بشرياً في المواقف المهمة.',
  'The clearest link: the microphone listens and the screen writes. It helps people who read comfortably, but weakens with Arabic dialects, noise and proper names. So show correctable text and keep a human interpreter for important moments.'))

add('[[حالة 2|Case 2]]', ('الحالة 2: من الإشارة إلى نص وصوت','Case 2: sign → text and speech'), '''
 <div class="body"><div class="col fade" style="flex:1.2"><ul><li>[[الكاميرا + تتبع اليد (21 نقطة) + مصنّف يتعرف على الإشارة|Camera + hand tracking (21 points) + a classifier recognises the sign]]</li><li>[[ينطق الجملة للسامع، فلا يحتاج الأصم لكتابة كل شيء|Speaks the sentence aloud so the deaf person need not type everything]]</li><li class="warnli">[[التعرّف الكامل بالإشارات المتحركة ما زال بحثاً علمياً|Full recognition of moving signs is still research]]</li><li>[[موقعنا يتعرف اليوم على هجاء الأصابع وإشارات يدرّبها المستخدم|Our site today: fingerspelling and signs the user trains]]</li></ul></div>
  <div class="col" style="flex:1"><div class="av" id="avlm" style="aspect-ratio:1"><svg id="lm" viewBox="-100 -230 200 250"></svg></div></div></div>''',
 ('هذا الاتجاه الأصعب. نستخدم الكاميرا ونموذج تتبع اليد ثم مصنفاً صغيراً. ما نقدر عليه اليوم بصدق هو هجاء الأصابع وإشارات يدرّبها المستخدم بنفسه. التعرف الكامل على لغة الإشارة بقواعدها وحركات الوجه ما زال مجالاً بحثياً.',
  'This is the harder direction: camera, a hand-tracking model, then a small classifier. Honestly, today we can do fingerspelling and signs the user trains themselves. Full recognition of sign language with its grammar and facial movements is still active research.'))

add('[[حالة 3|Case 3]]', ('الحالة 3: من النص إلى شخصية تؤدي الإشارة','Case 3: text → a signing character'), '''
 <div class="body"><div class="col" style="flex:.7"><div class="av" id="av7"></div></div><div class="col fade" style="flex:1.3"><ul><li>[[السامع يكتب، والشخصية تؤدي حركة وتعبير وجه أو تهجّي الكلمة|The hearing person types; the character performs a gesture and expression or spells the word]]</li><li>[[مفيدة للعبارات الجاهزة والتعلّم والمعلومات القصيرة|Good for ready phrases, learning and short announcements]]</li><li class="warnli">[[الاتحاد العالمي للصم ومترجمو الإشارة (WFD/WASLI) يحذّرون: الأفاتار ليس بديلاً عن المترجم البشري|WFD/WASLI warn: avatars are not a replacement for human signers]]</li></ul></div></div>''',
 ('هنا الشخصية تؤدي ما تكتبه. ملاحظة مهمة: بيان مشترك للاتحاد العالمي للصم والرابطة العالمية لمترجمي لغة الإشارة يحذّر من استخدام الأفاتار بديلاً عن المترجم البشري، لأن لغات الإشارة لغات كاملة لا تُترجم كلمة بكلمة. لذلك نقدّمها أداة مساعدة للعبارات القصيرة والتعلّم.',
  'Here the character performs what you type. Important: a joint WFD and WASLI statement warns against using avatars as a replacement for human interpreters, because sign languages are full languages and cannot be translated word for word. So we present it as a helper for short phrases and learning.'))

add('[[حالة 4|Case 4]]', ('الحالة 4: وعي بالأصوات المحيطة','Case 4: sound awareness'), '''
 <div class="body"><div class="col fade" style="flex:1.3"><ul><li>[[نموذج يصنّف الصوت: جرس، إنذار حريق، بكاء طفل، بوق سيارة|A model classifies sound: doorbell, fire alarm, baby cry, car horn]]</li><li>[[ينبّه بوميض أو اهتزاز على الهاتف أو الساعة|Alerts with a flash or vibration on a phone or watch]]</li><li>[[يعمل محلياً دون إرسال الصوت للإنترنت إن أمكن|Can run on-device without sending audio online]]</li><li class="warnli">[[لا يُعتمد عليه وحده في السلامة (إنذار حريق مرخّص يبقى ضرورياً)|Not to be the only safety measure (a certified fire alarm is still needed)]]</li></ul></div>
  <div class="col" style="flex:.9">''' + P('p08','doorbell flashing light alert deaf home') + '</div></div>',
 ('كثير من المخاطر اليومية صوتية: الجرس والإنذار وبكاء الطفل. تصنيف الأصوات يحوّلها إلى وميض أو اهتزاز. هذه من أنجح الحالات لأنها لا تحتاج لغة، لكنها لا تُغني عن أجهزة السلامة المرخّصة.',
  'Many daily alerts are sounds: bells, alarms, a baby crying. Sound classification turns them into a flash or vibration. It is one of the most successful cases because it needs no language, but it does not replace certified safety devices.'))

add('[[حالة 5|Case 5]]', ('الحالة 5: الصحة والطوارئ','Case 5: health and emergencies'), '''
 <div class="body"><div class="col fade" style="flex:1.3"><ul><li>[[بطاقات عبارات جاهزة: «أنا أصم»، «أحتاج طبيباً»، «أين الحمام؟»|Ready phrase cards: "I am deaf", "I need a doctor", "Where is the toilet?"]]</li><li>[[تبسيط تعليمات الدواء بنص قصير واضح|Simplify medicine instructions into short clear text]]</li><li class="warnli">[[الموافقة الطبية والتشخيص يحتاجان مترجماً مؤهلاً، لا آلة|Consent and diagnosis need a qualified interpreter, not a machine]]</li></ul></div>
  <div class="col" style="flex:.9">''' + P('p09','doctor patient clear communication clinic') + '</div></div>',
 ('الصحة مجال حساس. الذكاء الاصطناعي يساعد في الأشياء الصغيرة: عبارات جاهزة وتبسيط النصوص. أما شرح التشخيص وأخذ الموافقة فخطأ فيه مكلف، فيلزم مترجم مؤهل. موقعنا يحوي هذه العبارات الجاهزة فعلاً.',
  'Health is sensitive. AI helps with small things: ready phrases and simplified text. Explaining a diagnosis or taking consent has costly errors, so a qualified interpreter is required. Our site already includes these ready phrases.'))

add('[[حالة 6|Case 6]]', ('الحالة 6: التعليم','Case 6: education'), '''
 <div class="body"><div class="col fade" style="flex:1.3"><ul><li>[[ألعاب تعلّم الهجاء والإشارات بالتجربة والتكرار|Games that teach fingerspelling and signs through practice]]</li><li>[[تعليق نصي للمحاضرات، وتلخيص بلغة مبسطة|Captions for lectures and simplified summaries]]</li><li>[[تدريب شخصي: الطالب يسجّل إشاراته ويرى هل تُعرف|Personal training: the learner records signs and sees whether they are recognised]]</li><li class="warnli">[[المحتوى يُراجع مع معلم إشارة أصم|Content should be reviewed with a deaf sign teacher]]</li></ul></div>
  <div class="col" style="flex:.9">''' + P('p10','classroom sign language lesson students') + '</div></div>',
 ('في التعليم يفيد الذكاء الاصطناعي في الممارسة: لعبة، تغذية راجعة فورية، وتلخيص مبسط. موقعنا فيه لعبة «خمّن الحركة» وتدريب شخصي بالكاميرا. والمحتوى الأفضل يراجعه معلم أصم.',
  'In education AI helps with practice: a game, instant feedback and simplified summaries. Our site has a "guess the gesture" game and personal camera training. The best content is reviewed by a deaf teacher.'))

add('[[حالة 7|Case 7]]', ('الحالة 7: العمل وخدمة العملاء','Case 7: work and customer service'), '''
 <div class="body"><div class="col fade" style="flex:1.3"><ul><li>[[تعليق نصي للاجتماعات وملخصات بعدها|Captions in meetings and summaries after]]</li><li>[[دردشة بدل المكالمة الهاتفية، ومساعد يجيب على الأسئلة الشائعة|Chat instead of phone calls and an assistant for common questions]]</li><li>[[الذكاء الاصطناعي يساعد، والترجمة بالفيديو مع مترجم بشري تبقى للحالات المعقدة|AI assists; video relay with a human interpreter stays for complex cases]]</li></ul></div>
  <div class="col" style="flex:.9">''' + P('p11','deaf employee workplace meeting captions') + '</div></div>',
 ('في العمل نريد المشاركة بلا استئذان. التعليق النصي والملخصات ودردشة خدمة العملاء كلها تقلّل الاعتماد على الهاتف. وفي الحالات المعقدة يبقى مترجم بشري عبر الفيديو.',
  'At work we want participation without asking permission. Captions, summaries and customer chat reduce reliance on the phone. In complex cases a human interpreter by video remains.'))

add('[[حالة 8|Case 8]]', ('الحالة 8: تبسيط اللغة المكتوبة','Case 8: simplifying written language'), '''
 <div class="body"><div class="col fade" style="flex:1.2"><ul><li>[[كثير من الصم لغتهم الأولى لغة الإشارة، والعربية المكتوبة لغة ثانية|For many deaf people sign language is the first language and written Arabic the second]]</li><li>[[نموذج لغوي يبسّط الجملة ويحافظ على المعنى|A language model simplifies a sentence and keeps the meaning]]</li><li>[[موقعنا: زر «بسّط للقراءة السهلة» في تبويب الذكاء الاصطناعي|Our site: the "Simplify" button in the AI tab]]</li></ul></div>
  <div class="col" style="flex:1"><div class="card"><p>[[قبل|Before]]</p><div style="font-size:20px">[[يُرجى التكرّم بالمبادرة إلى مراجعة المستشفى.|You are kindly requested to proceed to the hospital for review.]]</div><div class="arr" style="margin:12px auto;transform:rotate(90deg)"></div><p>[[بعد|After]]</p><div style="font-size:24px;color:var(--gold)">[[اذهب إلى المستشفى.|Go to the hospital.]]</div></div></div></div>''',
 ('نقطة قلّما تُذكر: كثير من الصم يقرؤون العربية لكنها ليست لغتهم الأولى، فالجمل المعقدة تتعبهم. نموذج لغوي يبسّط الجملة، وهذا موجود في موقعنا. ومع ذلك نراجع النص حتى لا يتغير المعنى.',
  'A rarely mentioned point: many deaf people read Arabic, but it is not their first language, so complex sentences are tiring. A language model can simplify them, and our site has this. We still review the result so the meaning does not change.'))

add('[[المصفوفة|Matrix]]', ('الحالات مقابل قدرات الذكاء الاصطناعي','Cases vs AI capabilities'), '''
 <div class="body"><div class="col fade"><table class="mx"><tr><th>[[الحالة|Case]]</th><th>[[القدرة|Capability]]</th><th>[[في موقعنا|In our site]]</th></tr>
 <tr><td>[[تعليق فوري|Live captions]]</td><td>[[تفريغ الكلام|Speech-to-text]]</td><td class="no">[[غير مبنية|not built]]</td></tr>
 <tr><td>[[إشارة ← نص|Sign → text]]</td><td>[[رؤية + تصنيف|Vision + classifier]]</td><td class="part">[[جزئي: هجاء|partial: spelling]]</td></tr>
 <tr><td>[[نص ← إشارة|Text → sign]]</td><td>[[شخصية متحركة|Animated character]]</td><td class="yes">[[مبنية (تجريبية)|built (experimental)]]</td></tr>
 <tr><td>[[وعي بالأصوات|Sound awareness]]</td><td>[[تصنيف الصوت|Sound AI]]</td><td class="no">[[غير مبنية|not built]]</td></tr>
 <tr><td>[[عبارات صحية|Health phrases]]</td><td>[[قوالب + نطق|Templates + speech]]</td><td class="yes">[[مبنية|built]]</td></tr>
 <tr><td>[[تعليم|Education]]</td><td>[[لعبة + تدريب|Game + training]]</td><td class="yes">[[مبنية|built]]</td></tr>
 <tr><td>[[تبسيط اللغة|Simplify language]]</td><td>[[نموذج لغوي|Language model]]</td><td class="yes">[[مبنية|built]]</td></tr></table></div></div>''',
 ('هذه الصورة الصادقة لما أنجزناه. ما بنيناه فعلاً: نص إلى إشارة، عبارات صحية، تعليم، وتبسيط اللغة. وجزئياً: إشارة إلى نص. وما لم نبنه: التعليق الفوري وتصنيف الأصوات. نذكرها حتى لا نبالغ.',
  'An honest picture of what we did. Built: text to sign, health phrases, education, language simplification. Partial: sign to text. Not built: live captions and sound classification. We say so to avoid overclaiming.'))

add('[[المبادئ|Principles]]', ('مبادئ التصميم مع الصم لا لهم','Designing with deaf people, not for them'), '''
 <div class="body"><div class="col fade card tq" style="flex:1"><h3>[[نلتزم|We commit to]]</h3><ul style="font-size:22px"><li>[[«لا شيء عنّا بدوننا»: إشراك صم في التصميم والاختبار|"Nothing about us without us": deaf people in design and testing]]</li><li>[[وضوح الدقة والحدود لكل ميزة|Clear accuracy and limits for each feature]]</li><li>[[بديل بشري متاح دائماً|A human option always available]]</li><li>[[موافقة على أي بيانات تُجمع، وبقاؤها على جهاز المستخدم|Consent for any data, kept on the user's device]]</li></ul></div>
  <div class="col" style="flex:.8">''' + P('p14','deaf and hearing team designing together accessibility') + '</div></div>',
 ('المبدأ الذي يحكم كل شيء: لا شيء عنا بدوننا. أي أداة تُبنى للصم بلا مشاركتهم غالباً تخطئ الهدف. نلتزم بإشراكهم، بإعلان الحدود، وببديل بشري، وبإبقاء البيانات عند صاحبها.',
  'The principle that governs everything: nothing about us without us. Tools built for deaf people without them usually miss. We commit to involving them, stating limits, keeping a human option, and keeping data with its owner.'))

add('[[المخاطر|Risks]]', ('المخاطر والتحديات','Risks and challenges'), '''
 <div class="body"><div class="col fade" style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
  <div class="card"><h3>[[ندرة البيانات|Scarce data]]</h3><p>[[بيانات لغة الإشارة العربية قليلة مقارنة باللغات المنطوقة|Arabic sign data is small compared with spoken languages]]</p></div>
  <div class="card"><h3>[[اللهجات والتنوع|Dialects and variety]]</h3><p>[[تختلف الإشارات من بلد وجماعة لأخرى|Signs differ between countries and communities]]</p></div>
  <div class="card"><h3>[[كلفة الخطأ|Cost of errors]]</h3><p>[[خطأ في موقف طبي أو قانوني خطير|A mistake in a medical or legal setting is serious]]</p></div>
  <div class="card"><h3>[[الخصوصية|Privacy]]</h3><p>[[الفيديو يكشف الوجه واليدين: يُعالَج محلياً|Video reveals face and hands: process locally]]</p></div>
  <div class="card" style="grid-column:1/3"><h3>[[التحيّز والإضاءة|Bias and lighting]]</h3><p>[[قد تضعف الدقة مع لون بشرة أو إضاءة أو خلفية مختلفة|Accuracy may drop with different skin tones, lighting or backgrounds]]</p></div></div></div>''',
 ('هذه التحديات حقيقية. البيانات قليلة، والإشارات تختلف، والخطأ في موقف طبي مكلف، والفيديو حساس، وقد يتأثر الأداء بلون البشرة والإضاءة. لذلك نعالج الفيديو محلياً ونطلب من المستخدم أن يدرّب النظام بإشاراته.',
  'These challenges are real: little data, varied signs, costly errors, sensitive video, and performance that can vary with skin tone and lighting. So we process video locally and let users train the system on their own signs.'))

add('[[موقعنا|Our site]]', ('مثالنا العملي: «مترجم الإشارة»','Our working example: Sign Translator'), '''
 <div class="body" style="flex-direction:column;gap:20px"><div style="width:100%"><div class="chip">[[إشارة ← نص وصوت|Sign → text and speech]]</div>
  <div class="flow" style="justify-content:center;margin-top:8px"><div class="node"><b>[[الكاميرا|Camera]]</b></div><div class="arr"></div><div class="node"><b>[[نقاط اليد|Landmarks]]</b><span>MediaPipe</span></div><div class="arr"></div><div class="node"><b>[[تطبيع|Normalize]]</b></div><div class="arr"></div><div class="node acc"><b>[[تصنيف|Classify]]</b><span>library / TF.js</span></div><div class="arr"></div><div class="node"><b>[[نص + صوت|Text + voice]]</b></div></div></div>
  <div style="width:100%"><div class="chip gold">[[نص ← شخصية|Text → character]]</div>
  <div class="flow" style="justify-content:center;margin-top:8px"><div class="node"><b>[[كتابة|Typing]]</b></div><div class="arr"></div><div class="node"><b>[[تحليل|Parse]]</b><span>planText</span></div><div class="arr"></div><div class="node acc"><b>[[مكتبة|Library]]</b></div><div class="arr"></div><div class="node"><b>[[شخصية SVG|SVG character]]</b></div></div></div>
  <p class="note fade">[[كله داخل المتصفح، لا يغادر الفيديو جهازك.|All in the browser; video never leaves your device.]]</p></div>''',
 ('الآن ننتقل إلى المثال. اتجاهان: من الإشارة إلى نص وصوت، ومن النص إلى شخصية. كل شيء يعمل داخل المتصفح، والفيديو لا يغادر الجهاز، وهذا شرط خصوصية أساسي.',
  'Now to the example. Two directions: sign to text and speech, and text to a character. Everything runs in the browser and video never leaves the device, a core privacy requirement.'))

add('[[أدوات الذكاء الاصطناعي|AI tools]]', ('أدوات الذكاء الاصطناعي المستخدمة','AI tools we used'), '''
 <div class="body fade" style="flex-wrap:wrap;align-content:center"><div class="card" style="flex:1 1 45%"><h3>Claude (Anthropic)</h3><p>[[كتب الكود وصمّم الشخصية والحركات والواجهة والاختبارات وهذا العرض.|Wrote the code, designed the character, gestures, UI, tests and this deck.]]</p></div>
 <div class="card" style="flex:1 1 45%"><h3>MediaPipe HandLandmarker</h3><p>[[نموذج جاهز لتتبع 21 نقطة في اليد.|Ready model tracking 21 hand points.]]</p></div>
 <div class="card" style="flex:1 1 45%"><h3>TensorFlow.js</h3><p>[[شبكة صغيرة يدرّبها المستخدم على إشاراته.|A small network the user trains on their own signs.]]</p></div>
 <div class="card" style="flex:1 1 45%"><h3>[[مساعد Claude داخل الموقع|Claude inside the site]]</h3><p>[[يبسّط ويترجم ويجيب ويصحّح الهجاء.|Simplifies, translates, answers and fixes spelling.]]</p></div>
 <div class="card" style="flex:1 1 45%"><h3>Web Speech API</h3><p>[[نطق عربي وإنجليزي من المتصفح.|Arabic and English speech from the browser.]]</p></div></div>''',
 ('خمس أدوات: Claude الذي بنى المشروع، MediaPipe لتتبع اليد، TensorFlow.js للتدريب في المتصفح، مساعد Claude داخل الموقع للتبسيط والترجمة، وواجهة النطق في المتصفح. لاحظوا أن بعضها ذكاء اصطناعي ثقيل وبعضها بسيط، ونختار على قدر الحاجة.',
  'Five tools: Claude that built the project, MediaPipe for hand tracking, TensorFlow.js for in-browser training, the Claude assistant inside the site for simplifying and translating, and the browser speech API. Some are heavy AI, some light; we pick by need.'))

add('[[تتبع اليد|Hand tracking]]', ('21 نقطة لكل يد، ثم تطبيع','21 landmarks per hand, then normalisation'), '''
 <div class="body"><div class="col fade"><ul><li>[[كل نقطة x وy وz: 63 رقماً لكل عينة|Each point x, y, z: 63 numbers per sample]]</li><li>[[نطرح المعصم ← نقسم على أكبر مسافة ← نعكس اليسرى|Subtract wrist → divide by max distance → mirror the left hand]]</li><li>[[فتصبح الإشارة مستقلة عن موضع اليد وقربها|So a sign no longer depends on hand position or distance]]</li></ul></div>
 <div class="col"><div class="row" id="fs" style="align-items:flex-end"></div><p class="note" style="text-align:center">[[حالة كل إصبع بين 0 (مطوي) و1 (ممدود)|Each finger from 0 (curled) to 1 (extended)]]</p></div></div>''',
 ('النموذج يعطينا 21 نقطة. نطبّعها حتى لا يهم أين وضعتَ يدك أو كم تبعد عن الكاميرا. ثم نحسب حالة كل إصبع من زوايا المفاصل، فتصبح للحرف «بصمة» من خمس قيم.',
  'The model gives 21 points. We normalise so it does not matter where your hand is or how far from the camera. Then we compute each finger\'s state from joint angles, giving each letter a five-value fingerprint.'))

add('[[التدريب|Training]]', ('التدريب داخل المتصفح','Training in the browser'), '''
 <div class="body" style="flex-direction:column;gap:14px"><div class="flow" style="justify-content:center"><div class="node"><b>[[تسجيل|Record]]</b><span>40+</span></div><div class="arr"></div><div class="node"><b>[[تنويع|Augment]]</b><span>noise ×2</span></div><div class="arr"></div><div class="node"><b>[[تقسيم|Split]]</b><span>80/20</span></div><div class="arr"></div><div class="node acc"><b>[[تدريب|Train]]</b><span>60 epochs</span></div><div class="arr"></div><div class="node"><b>[[تقييم|Evaluate]]</b></div></div>
 <div style="display:flex;gap:30px;align-items:center;justify-content:center"><svg viewBox="0 0 520 280" id="nn" style="width:520px;height:280px;flex:none"></svg><ul class="fade" style="width:460px;flex:none;font-size:23px"><li><span class="mono">63 → 128 → 64 → N</span></li><li><span class="mono">Dropout 0.2 · Softmax</span></li><li><span class="mono">Adam · lr 0.001 · batch 32</span></li></ul></div></div>''',
 ('المستخدم يسجّل عينات لكل حرف، نضيف ضجيجاً صغيراً لتنويعها، نقسم 80 للتدريب و20 للتقييم، ثم تتدرب شبكة صغيرة داخل المتصفح. لا يُرسل شيء لخادم. وبعد التدريب تظهر الدقة الحقيقية على جهازه هو.',
  'The user records samples per letter, we add small noise for variety, split 80/20, then a small network trains in the browser. Nothing goes to a server. After training the real accuracy appears on their own device.'))

add('[[الثقة|Confidence]]', ('الثقة: متى نصدّق التوقع؟','Confidence: when to believe a prediction'), '''
 <div class="body" style="flex-direction:column;align-items:stretch;gap:16px"><div class="card"><div style="display:flex;justify-content:space-between;font-size:19px"><span>[[الثقة الحالية|Current confidence]]</span><span style="color:var(--gold)">[[الحد الأدنى 70%|Minimum 70%]]</span></div><div class="meterbox" style="margin-top:8px"><div class="meterfill"></div><div class="thr"></div></div></div>
 <div class="row fade"><div class="card"><h3>Smoother</h3><p>[[متوسط آخر 8 إطارات يمنع الوميض|Average of the last 8 frames stops flicker]]</p></div><div class="card"><h3>Committer</h3><p>[[تثبيت نصف ثانية قبل إضافة الحرف|Hold half a second before adding a letter]]</p></div><div class="card"><h3>[[الالتباس|Ambiguity]]</h3><p>[[إن تشابه شكلان تقل الثقة|Similar shapes lower confidence]]</p></div></div>
 <div class="warn">[[الثقة رقم يقدّره النموذج، وليست ضماناً. لذلك نعرضها للمستخدم ونتيح له رفع الحد.|Confidence is the model's own estimate, not a guarantee. So we show it and let users raise the threshold.]]</div></div>''',
 ('«الثقة» رقم يقدّره النموذج لتوقعه. لا نقبل أي حرف تحت 70 بالمئة، ونعتمد المتوسط على عدة إطارات حتى لا يومض الحرف، وننتظر نصف ثانية قبل الإضافة. وننبّه: الثقة تقدير لا ضمان، ولهذا يستطيع المستخدم تعديلها.',
  '"Confidence" is the model\'s estimate for its prediction. We accept nothing below 70%, average over several frames to stop flicker, and wait half a second before committing. We stress: confidence is an estimate, not a guarantee, so users can adjust it.'))

add('[[الهجاء|Spelling]]', ('مكتبة الهجاء: 28 + 26 حرفاً','Fingerspelling: 28 + 26 letters'), '''
 <div class="body" style="flex-direction:column;align-items:stretch;gap:12px"><div class="grid hgrid" id="alpha"></div><div class="warn">[[الأشكال الافتراضية موزعة للتجربة فقط وليست القاموس الرسمي. يمكن تعديلها أو تسجيل الصحيح بالكاميرا.|Default shapes are assigned for demonstration only and are not the official dictionary. Edit them or record the correct ones with the camera.]]</div></div>''',
 ('كل حرف يُعرَّف بحالة الإبهام وأربعة أصابع. الأشكال الافتراضية وُزعت للتجربة فقط وليست القاموس الرسمي للغة الإشارة العربية، ويمكن للمستخدم تصحيحها أو تسجيل الصحيح.',
  'Each letter is defined by thumb state and four fingers. The default shapes were assigned for demonstration only and are not the official Arabic Sign Language dictionary; users can correct them or record the right ones.'))

add('[[النص إلى إشارة|Text → sign]]', ('كيف يفهم الموقع جملتك؟','How the site reads your sentence'), '''
 <div class="body" style="flex-direction:column;gap:16px"><div class="card" style="font-size:26px;text-align:center">[[شكرا، أنا أحتاج ماء؟|Thanks, I need water?]]</div>
 <div class="flow rtlflow" style="justify-content:center;flex-wrap:wrap"><div class="chip tqc">thanks</div><div class="chip tqc">me</div><div class="chip gold">[[أحتاج ← هجاء|"need" → spelled]]</div><div class="chip tqc">drink</div><div class="chip">[[؟ ← تعبير السؤال|? → question face]]</div></div>
 <ul class="fade" style="font-size:21px"><li>[[نوحّد الحروف ثم نبحث عن أطول عبارة مطابقة أولاً|Normalise letters, then match the longest phrase first]]</li><li>[[ما ليس في المكتبة يُهجّى حرفاً حرفاً|Anything unknown is fingerspelled]]</li></ul></div>''',
 ('المحلل يوحّد الحروف ثم يبحث عن أطول عبارة موجودة في مكتبة الحركات. الكلمة المعروفة تؤدّيها الشخصية بحركة، وغير المعروفة تُهجّى، وعلامة الاستفهام تضيف تعبير السؤال.',
  'The parser normalises letters then finds the longest phrase in the gesture library. Known words are performed as gestures, unknown ones are spelled, and a question mark adds a question expression.'))

add('[[الشخصية|Character]]', ('الشخصية: مفاصل حقيقية وحركة عكسية','The character: real joints and inverse kinematics'), '''
 <div class="body"><div class="col" style="flex:.6"><div class="av" id="av20"></div></div><div class="col fade" style="flex:1.3"><ul style="font-size:21px"><li>[[رسم SVG بطبقات وتظليل: بدلة، وجه، عيون، شعر، أيدٍ|Layered, shaded SVG: blazer, face, eyes, hair, hands]]</li><li>[[ذراعان من عظمتين (88 و82 وحدة)|Two-bone arms (88 and 82 units)]]</li><li><code>a = (d² + L1² − L2²) / 2d</code> · <code>h = √(L1² − a²)</code></li><li>[[نحدد المعصم فيجد الكود المرفق الأخفض والأبعد عن الجسم|We set the wrist; code finds the lower, outward elbow]]</li><li>[[طرفة عين وتنفس تلقائيان وثلاث شخصيات|Auto blinking, breathing, three presets]]</li></ul></div></div>''',
 ('الشخصية رسم SVG بطبقات. للذراع عظمتان، وكل ما نحدده موضع المعصم، والكود يحسب موضع المرفق بمعادلة هندسية بسيطة. أضفنا تظليلاً وعيوناً وشعراً لتبدو أقرب للواقع، وهي بالطبع ليست صورة حقيقية.',
  'The character is a layered SVG. Each arm has two bones; we set the wrist and the code computes the elbow with simple geometry. We added shading, eyes and hair to look closer to real, though it is of course not a photograph.'))

add('[[الوجه|Face]]', ('الوجه: التعابير جزء من القواعد','The face: expressions are part of grammar'), '''
 <div class="body" style="flex-direction:column;gap:12px"><div class="row" id="faces"></div><p class="note" style="text-align:center">[[11 معاملاً: حاجبان، عينان، نظرة، فم، ميلان الرأس... تُمزج بسلاسة.|11 parameters: brows, eyes, gaze, mouth, head tilt… blended smoothly.]]</p></div>''',
 ('في لغات الإشارة تعبير الوجه جزء من القواعد: يغيّر الجملة من خبر إلى سؤال ويُظهر النفي والمشاعر. لذلك بنينا الوجه بإحدى عشر معاملاً يمكن مزجها.',
  'In sign languages facial expression is part of grammar: it turns a statement into a question and shows negation and feeling. So we built the face with eleven blendable parameters.'))

add('[[الحركات|Gestures]]', ('مكتبة الحركات: 21 حركة و6 تعابير','Gesture library: 21 gestures + 6 expressions'), '''
 <div class="body" style="flex-direction:column;gap:10px"><div class="row" id="gests" style="width:100%"></div>
 <div class="warn">[[هذه الحركات من تصميمي وهي تجريبية للعرض، وليست إشارات معتمدة. اعرضها على مترجم إشارة أو شخص أصم قبل أي استخدام حقيقي.|These gestures are my own design and experimental, not approved signs. Show them to an interpreter or deaf signer before any real use.]]</div></div>''',
 ('كل حركة سلسلة إطارات مفتاحية: موضع المعصم، اتجاه اليد، خمس قيم للأصابع، ووجه. هي من تصميمي لأغراض العرض، وأكرر: ليست إشارات معتمدة. للاستخدام الحقيقي يلزم مراجعتها مع مترجم إشارة أو شخص أصم.',
  'Each gesture is a chain of keyframes: wrist position, hand direction, five finger values and a face. They are my own design for demonstration, and again: not approved signs. For real use they need review with an interpreter or deaf signer.'))

_extra = dict(tag='[[إنسان + آلة|Human + AI]]', title=('متى الآلة ومتى الإنسان؟','When the machine, when the human?'), body='''
 <div class="body"><div class="col fade card tq"><h3>[[الذكاء الاصطناعي يكفي|AI is enough for]]</h3><ul style="font-size:22px"><li>[[عبارات قصيرة وروتينية|Short routine phrases]]</li><li>[[تنبيهات الأصوات|Sound alerts]]</li><li>[[تعلّم وتدريب شخصي|Learning and practice]]</li><li>[[تبسيط نص قبل القراءة|Simplifying text before reading]]</li></ul></div>
 <div class="col fade card" style="border-color:var(--gold)"><h3 style="color:var(--gold)">[[يلزم إنسان مؤهل|A qualified human is needed for]]</h3><ul style="font-size:22px"><li>[[طب وقانون وموافقات|Medical, legal, consent]]</li><li>[[محاكم وتعليم رسمي|Courts and formal education]]</li><li>[[حوار طويل ومعقد|Long, complex conversation]]</li><li>[[ما فيه حساسية ثقافية أو عاطفية|Cultural or emotional nuance]]</li></ul></div></div>''',
 notes=('القاعدة العملية: كلما ارتفعت كلفة الخطأ احتجنا إنساناً مؤهلاً. الذكاء الاصطناعي ممتاز للروتين والتعلم والتنبيهات، لكنه لا يحل محل المترجم في الطب والقانون والمواقف المعقدة.',
 'A practical rule: the higher the cost of an error, the more a qualified human is needed. AI is great for routine, learning and alerts, but does not replace the interpreter in medicine, law and complex situations.'))
add(**_extra)
S.insert(14, S.pop())


def node(n, ar, en, cls=''):
    return f'<div class="node {cls}"><b>{n}. [[{ar}|{en}]]</b></div>'
_steps = [('حدّد الحالة','Define the case','مع أصم'),('اختر نوع الذكاء','Pick the AI type',''),('جهّز البيانات','Prepare data','بموافقة'),('درّب النموذج','Train the model',''),
          ('قِس الثقة','Measure confidence',''),('نص وصوت','Text + speech',''),('نص إلى إشارة','Text to sign',''),('إنسان في الحلقة','Human in the loop','')]
_n = ''.join(f'<div class="node {"gold" if i in (0,7) else ("acc" if i in (3,) else "")}"><b>{i+1}</b><span>[[{a}|{e}]]</span></div>' for i,(a,e,_) in enumerate(_steps))
add('[[الخطوات|Steps]]', ('ثماني خطوات لربط الذكاء الاصطناعي بحالة أصم','Eight steps to link AI to a deaf use case'), f'''
 <div class="body" style="flex-direction:column;align-items:stretch;gap:16px"><div class="grid fade" style="grid-template-columns:repeat(4,1fr);gap:12px">{_n}</div>
 <div class="row fade"><div class="card tq"><h3>[[البداية والنهاية إنسانية|Starts and ends with people]]</h3><p>[[تبدأ من حاجة أصم حقيقية (1) وتنتهي بمراجعة إنسان مؤهل (8)، والذكاء الاصطناعي في الوسط.|It starts from a real deaf need (1) and ends with a qualified human review (8), with the AI in between.]]</p></div>
 <div class="card"><h3>[[كل خطوة لها مقابل في موقعنا|Every step exists in our site]]</h3><p>[[تبويب «خطوات الربط» في الموقع يربط كل خطوة بصفحة يمكن تجربتها.|The "AI steps" tab in the site links each step to a page you can try.]]</p></div></div></div>''',
 ('هذه الخطوات الثماني هي خلاصة العمل. نبدأ بتحديد الحالة مع شخص أصم، ثم نختار نوع الذكاء الاصطناعي المناسب، ونجهز البيانات بموافقة، وندرب النموذج، ونقيس ثقته، ونحول النتيجة إلى نص وصوت أو إلى إشارة، وننتهي بإنسان مؤهل يراجع. لاحظوا أن الذكاء الاصطناعي في الوسط فقط، والبداية والنهاية للإنسان.',
  'These eight steps are the summary. We start by defining the case with a deaf person, choose the right kind of AI, prepare data with consent, train the model, measure its confidence, turn the result into text, speech or sign, and end with a qualified human reviewing. Notice the AI sits in the middle only; the start and the end belong to people.'))
_st = S.pop()

add('[[أنواع الذكاء|AI types]]', ('أي نوع من الذكاء الاصطناعي لأي مهمة؟','Which kind of AI for which task?'), '''
 <div class="body"><div class="col"><table class="mx fade"><tr><th>[[المهمة|Task]]</th><th>[[نوع الذكاء الاصطناعي|AI type]]</th><th>[[مثال|Example]]</th></tr>
 <tr><td>[[قراءة اليد|Reading the hand]]</td><td>[[رؤية حاسوبية|Computer vision]]</td><td>MediaPipe</td></tr>
 <tr><td>[[تصنيف الحرف أو الكلمة|Classifying letters/words]]</td><td>[[شبكة عصبية|Neural network]]</td><td>TensorFlow.js</td></tr>
 <tr><td>[[تفريغ الكلام|Speech to text]]</td><td>[[التعرف على الكلام|Speech recognition]]</td><td>Web Speech API</td></tr>
 <tr><td>[[تبسيط النص والترجمة|Simplify and translate text]]</td><td>[[نموذج لغوي|Large language model]]</td><td>Claude</td></tr>
 <tr><td>[[تحريك شخصية|Animating a character]]</td><td>[[توليد حركة|Motion generation]]</td><td>[[حركة عكسية + إطارات|IK + keyframes]]</td></tr></table>
 <p class="note">[[الجدول تبسيط تعليمي؛ الاختيار الفعلي يعتمد على الحالة والبيانات.|The table is an educational simplification; real choices depend on the case and data.]]</p></div></div>''',
 ('كل مهمة تحتاج نوعاً مختلفاً. قراءة اليد رؤية حاسوبية، وتصنيف الحرف شبكة عصبية، وتفريغ الكلام تعرف على الصوت، وتبسيط النص نموذج لغوي، وتحريك الشخصية حركة عكسية وإطارات مفتاحية. لا يوجد ذكاء اصطناعي واحد يفعل كل شيء.',
  'Each task needs a different kind. Reading the hand is computer vision, classifying a letter is a neural network, captions are speech recognition, simplifying text is a language model, and animating the character is inverse kinematics with keyframes. No single AI does everything.'))
_ty = S.pop()

add('[[التقييم|Evaluation]]', ('كيف نقيس نجاح الذكاء الاصطناعي مع الصم؟','How do we measure AI success with deaf users?'), '''
 <div class="body" style="flex-direction:column;align-items:stretch;gap:14px"><div class="row fade">
 <div class="card"><div class="stat">[[الدقة|Accuracy]]</div><p>[[نسبة الإشارات المقروءة صحيحاً على أشخاص لم يظهروا في التدريب|Share of signs read correctly on people not seen in training]]</p></div>
 <div class="card"><div class="stat">WER</div><p>[[معدل أخطاء الكلمات في التعليق النصي|Word error rate of the captions]]</p></div>
 <div class="card"><div class="stat">[[السرعة|Speed]]</div><p>[[تأخير أقل من ثانية ليبقى الحوار طبيعياً|Under a second so conversation feels natural]]</p></div></div>
 <div class="row fade"><div class="card tq"><h3>[[رضا المستخدم الأصم|Deaf user satisfaction]]</h3><p>[[أهم مقياس: هل ساعده فعلاً؟ يُقاس بتجربة وأسئلة مع أصم.|The most important measure: did it truly help? Measured by trials and interviews with deaf people.]]</p></div>
 <div class="card"><h3>[[العدالة|Fairness]]</h3><p>[[اختبار على لون بشرة وإضاءة ولهجات وأحجام أيدٍ مختلفة|Test across skin tones, lighting, dialects and hand sizes]]</p></div></div>
 <div class="warn">[[دقة عالية في المختبر لا تعني نجاحاً في الحياة الواقعية.|High lab accuracy does not mean success in real life.]]</div></div>''',
 ('النجاح ليس رقماً واحداً. نقيس الدقة على أشخاص جدد، ومعدل أخطاء الكلمات للتعليق، والسرعة. لكن أهم مقياس هو رضا المستخدم الأصم نفسه. ونختبر العدالة عبر ألوان البشرة والإضاءة واللهجات. ونتذكر: الدقة العالية في المختبر لا تضمن النجاح في الواقع.',
  'Success is not one number. We measure accuracy on new people, word error rate for captions, and speed. But the most important measure is the deaf user\'s own satisfaction. We test fairness across skin tones, lighting and dialects. And remember: high lab accuracy does not guarantee real-world success.'))
_ev = S.pop()

add('[[الخلاصة|Summary]]', ('الخلاصة','Summary'), '''
 <div class="body"><div class="col fade card tq"><h3>[[ما الذي يفعله الذكاء الاصطناعي|What AI does well]]</h3><ul style="font-size:21px"><li>[[يحوّل الكلام إلى نص فوراً|Turns speech into text instantly]]</li><li>[[يقرأ حركة اليد ويحوّلها لنص وصوت|Reads hand movement into text and speech]]</li><li>[[يبسّط اللغة ويترجمها|Simplifies and translates language]]</li><li>[[يؤدي الإشارة عبر شخصية للتعلم|Performs signs through a character for learning]]</li></ul></div>
 <div class="col fade card" style="border-color:var(--gold)"><h3 style="color:var(--gold)">[[وما يبقى للإنسان|What stays with people]]</h3><ul style="font-size:21px"><li>[[القرار في المواقف الحرجة|Decisions in critical situations]]</li><li>[[مراجعة اللغة والثقافة|Language and cultural review]]</li><li>[[مشاركة الصم في التصميم|Deaf people in the design]]</li></ul><p class="note" style="margin-top:14px">[[المصادر: WHO · WFD · الأمم المتحدة · بيان WFD/WASLI حول الأفاتار.|Sources: WHO · WFD · United Nations · WFD/WASLI statement on avatars.]]</p>
 <div class="chip gold" style="margin-top:10px;font-size:22px">[[شكراً لكم 🤟|Thank you 🤟]]</div></div></div>''',
 ('نختم: الذكاء الاصطناعي يفيد في التفريغ الفوري، وقراءة الإشارة، وتبسيط اللغة، وتعليم الإشارة. ويبقى للإنسان القرار في المواقف الحرجة، ومراجعة اللغة والثقافة، وأن يكون الأصم شريكاً في التصميم. شكراً لكم، وأرحب بأسئلتكم.',
  'To close: AI helps with instant captions, reading sign, simplifying language and teaching sign. People keep decisions in critical situations, language and cultural review, and deaf people as partners in design. Thank you, and I welcome your questions.'))
_cl = S.pop()
# ترتيب: الخطوات بعد الخريطة، الأنواع بعدها، التقييم بعد «الثقة»، الخلاصة في النهاية
_i = next(i for i,x in enumerate(S) if x['tag'].startswith('[[الخريطة'))
S[_i+1:_i+1] = [_st, _ty]
_j = next(i for i,x in enumerate(S) if x['tag'].startswith('[[الثقة'))
S.insert(_j+1, _ev)
S.append(_cl)
